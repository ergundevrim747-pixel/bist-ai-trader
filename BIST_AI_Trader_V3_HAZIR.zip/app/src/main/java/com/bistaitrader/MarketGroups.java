package com.bistaitrader;

import java.util.*;

public final class MarketGroups {
    private MarketGroups() {}

    // BIST 30 için 2026 Q3 dönemine uygun gömülü sembol snapshot'ı.
    public static final Set<String> BIST30 = set("AEFES AKBNK ASELS ASTOR BIMAS DSTKF EKGYO ENKAI EREGL FROTO GARAN GUBRF ISCTR KCHOL KRDMD MGROS PETKM PGSUS SAHOL SASA SISE TAVHL TCELL THYAO TOASO TRALT TTKOM TUPRS VAKBN YKBNK");

    // Uygulamada hızlı tarama için gömülü geniş BIST50 snapshot'ı.
    public static final Set<String> BIST50 = set("AEFES AKBNK AKSA AKSEN ALARK ASELS ASTOR BIMAS BRSAN CCOLA CIMSA DOAS DOHOL EKGYO ENJSA ENKAI EREGL FROTO GARAN GUBRF HALKB HEKTS ISCTR KCHOL KRDMD MGROS MAVI MPARK ODAS OYAKC PETKM PGSUS RALYH SAHOL SARKY SASA SISE SKBNK SOKM TAVHL TCELL TKFEN TOASO TSKB TTKOM TTRAK TUPRS ULKER VAKBN YKBNK");

    // 18/09/2026 itibarıyla güncellenen üçüncü taraf BIST100 snapshot'larından derlenen gömülü liste.
    // Endeks üyelikleri Borsa İstanbul tarafından periyodik olarak gözden geçirilir.
    public static final Set<String> BIST100 = set("AEFES AKBNK AKSA AKSEN ALARK ALBRK ANSGR ARCLK ASELS ASTOR AGESA BERA BIMAS BIOEN BRSAN BRYAT BSOKE BTCIM CCOLA CANTE CIMSA CVKMD DAPGM DCTTR DEVA DGNMO DOAS DOHOL DOCO DSTKF EFOR EKGYO ENJSA ENKAI ENERY EREGL ESEN EUPWR FENER FROTO GARAN GESAN GLRMK GUBRF GRSEL GRTHO HALKB HEKTS IEYHO ISCTR ISMEN KCHOL KLRHO KRDMD KUYAS MAGEN MAVI MIATK MGROS MPARK ODAS ODINE OYAKC OBAMS PASEU PAHOL PATEK PETKM PGSUS PSGYO QUA RALYH REEDR SAHOL SARKY SASA SISE SKBNK SOKM TAVHL TCELL TKFEN TOASO TSKB TTKOM TUPRS TURSG TUKAS ULKER VAKBN VESTL YKBNK ZOREN TTRAK AKCNS GSDHO ISGYO CLEBI KORDS THYAO");

    public static boolean matches(String category, Stock s) {
        if (category == null || category.equals("Tümü") || category.equals("BIST 500")) return true;
        if (category.equals("Takip")) return false;
        if (category.equals("BIST 30")) return BIST30.contains(s.symbol);
        if (category.equals("BIST 50")) return BIST50.contains(s.symbol);
        if (category.equals("BIST 100")) return BIST100.contains(s.symbol);
        return true;
    }

    private static Set<String> set(String raw){
        return Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(raw.trim().split("\\s+"))));
    }
}
