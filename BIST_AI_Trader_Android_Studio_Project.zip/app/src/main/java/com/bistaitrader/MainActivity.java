package com.bistaitrader;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, signal, price, rsi, trend, score, cash, equity, pnl, positions;
    Spinner symbol;
    HashMap<String,Double> prices=new HashMap<>();
    HashMap<String,Integer> qty=new HashMap<>();
    double cashValue=100000;

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.rgb(238,242,255));t.setTextSize(sp);t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(37,99,235));return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b); build(); scan();}

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(11,16,32));
        TextView head=tv("📈 BIST AI Trader",22);head.setPadding(dp(16),dp(18),dp(16),dp(2));root.addView(head);
        root.addView(tv("MVP • AL/SAT sinyali + sanal işlem",12));
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(12),dp(12),dp(30));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout tabs=new LinearLayout(this);
        Button a=btn("Tarama"),p=btn("Portföy"),s=btn("Ayarlar");
        tabs.addView(a,new LinearLayout.LayoutParams(0,dp(52),1));tabs.addView(p,new LinearLayout.LayoutParams(0,dp(52),1));tabs.addView(s,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(tabs);setContentView(root);
        a.setOnClickListener(v->scan());p.setOnClickListener(v->portfolio());s.setOnClickListener(v->settings());
    }
    void clear(){content.removeAllViews();}
    void scan(){
        clear(); LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackgroundColor(Color.rgb(18,26,43));
        symbol=new Spinner(this);String[] ss={"THYAO","ASELS","AKBNK","SAHOL","TUPRS","BIMAS"};symbol.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ss));
        card.addView(symbol); Button b=btn("TARA");card.addView(b);content.addView(card);
        title=tv("THYAO — Teknik görünüm",20);content.addView(title);signal=tv("BEKLE",18);content.addView(signal);
        price=tv("",17);rsi=tv("",15);trend=tv("",15);score=tv("",15);content.addView(price);content.addView(rsi);content.addView(trend);content.addView(score);
        TextView n=tv("📰 Haber analizi\nCanlı haber kaynağı sonraki sürümde bağlanacaktır.\n\nBu MVP gerçek emir göndermez; yalnızca sanal işlem yapar.",14);content.addView(n);
        b.setOnClickListener(v->scanData());
        symbol.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int x,long l){scanData();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
    }
    void scanData(){
        String s=symbol.getSelectedItem().toString();double pr=prices.containsKey(s)?prices.get(s):base(s);
        int sc=score(s);String sig=sc>=70?"AL":sc<=35?"SAT":"BEKLE";
        title.setText(s+" — Teknik görünüm");price.setText("Fiyat: "+String.format(Locale.US,"%.2f",pr)+" ₺");rsi.setText("RSI(14): "+String.format(Locale.US,"%.1f",rsi(s)));trend.setText("Trend: "+(sc>=60?"Yükseliş":sc<=40?"Düşüş":"Yatay"));score.setText("AI skor: "+sc+"/100\nSinyal: "+sig);
        signal.setText(sig);signal.setTextColor(sig.equals("AL")?Color.GREEN:sig.equals("SAT")?Color.RED:Color.YELLOW);
    }
    double base(String s){double v=s.equals("THYAO")?318.5:s.equals("ASELS")?182.4:s.equals("AKBNK")?68.2:s.equals("SAHOL")?121.3:s.equals("TUPRS")?171.8:532;prices.put(s,v);return v;}
    int score(String s){return s.equals("ASELS")?76:s.equals("TUPRS")?68:s.equals("THYAO")?54:s.equals("BIMAS")?51:s.equals("AKBNK")?48:34;}
    double rsi(String s){return s.equals("ASELS")?61.8:s.equals("TUPRS")?57.3:s.equals("THYAO")?52.4:s.equals("BIMAS")?44.2:s.equals("AKBNK")?47.1:39.6;}

    void portfolio(){
        clear();cash=tv("",18);equity=tv("",18);pnl=tv("",18);positions=tv("",15);
        content.addView(tv("💰 Sanal Portföy",22));content.addView(cash);content.addView(equity);content.addView(pnl);
        Spinner sp=new Spinner(this);String[] ss={"THYAO","ASELS","AKBNK","SAHOL","TUPRS","BIMAS"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ss));content.addView(sp);
        EditText q=new EditText(this);q.setHint("Adet");q.setInputType(2);q.setText("10");content.addView(q);
        Button buy=btn("Sanal AL"),sell=btn("Sanal SAT");content.addView(buy);content.addView(sell);content.addView(positions);render();
        buy.setOnClickListener(v->{trade(sp.getSelectedItem().toString(),Integer.parseInt(q.getText().toString()),true);});
        sell.setOnClickListener(v->{trade(sp.getSelectedItem().toString(),Integer.parseInt(q.getText().toString()),false);});
    }
    void trade(String s,int q,boolean buy){
        double cost=base(s)*q;int old=qty.containsKey(s)?qty.get(s):0;
        if(buy&&cost<=cashValue){cashValue-=cost;qty.put(s,old+q);}
        else if(!buy&&old>=q){cashValue+=cost;qty.put(s,old-q);}
        render();
    }
    void render(){if(cash==null)return;double val=cashValue;StringBuilder z=new StringBuilder("Pozisyonlar:\n");for(String s:qty.keySet()){int q=qty.get(s);val+=base(s)*q;if(q>0)z.append(s+" — "+q+" adet\n");}cash.setText("Nakit: "+String.format(Locale.US,"%.2f",cashValue)+" ₺");equity.setText("Toplam: "+String.format(Locale.US,"%.2f",val)+" ₺");pnl.setText("K/Z: "+String.format(Locale.US,"%.2f",val-100000)+" ₺");positions.setText(z.toString());}
    void settings(){clear();content.addView(tv("⚙️ Ayarlar",22));content.addView(tv("Risk / stop-loss ayarları sonraki sürümde etkinleştirilecek.",15));content.addView(tv("Gerçek para işlemleri: KAPALI",15));}
}