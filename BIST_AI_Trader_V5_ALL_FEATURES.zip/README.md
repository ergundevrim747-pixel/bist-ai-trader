# BIST AI Trader v5.0 – All Features

Bu sürüm V4.5 tabanının analiz, risk, sanal portföy ve öğrenme katmanlarını tek mimaride birleştirir. Anlık veri sağlayıcısı bu sürümde öncelik değildir; veri katmanı ileride ForInvest/Foreks, Matriks, dxFeed veya iTick adaptörü ile değiştirilebilir.

## İçerik
- Otomatik hisse kataloğu ve endeks üyeliği senkronizasyonu
- BIST 30 / 50 / 100 / 500 ayrı sayfaları ve her sayfada düşük/orta/yüksek risk alt grupları
- AL / BEKLE / SAT giriş kararı ile TradingView-tarzı teknik durumun ayrı tutulması
- 7 koşullu checklist: RSI, MACD, EMA20>EMA50, Hacim, Trend, Destek, Momentum
- 5/7 sadece aday eşiğidir; piyasa, göreli güç, volatilite, giriş, stop ve R/R kapıları final kararı doğrular
- Kısa / orta / uzun vade horizon analizi
- Giriş aralığı, zarar durdur, T1, T2 ve trailing stop
- Günlük OHLCV mum/çizgi grafik, karşılaştırma ve backtest
- Sanal portföy: maliyet, kâr/zarar, tepe fiyat, geri çekilme, teknik stop, kâr koruma, teknik zayıflama ve güçlü bozulma
- Yaklaşık 5 dakikalık portföy alarm servisi; otomatik emir göndermez
- Bildirim izni için Android 13+ runtime request
- Model öğrenmesi ile sanal portföy tamamen ayrı
- Her uygulama üretimli kararın bağımsız kararı kaydedilir; kullanıcı o hisseyi almış olmak zorunda değildir
- Sonuçlandırılmış AL tahminleri stop/T1/T2 zaman çizgisiyle etiketlenir ve öğrenme havuzuna girer
- Öğrenme günlük değerlendirilir; profil/ağırlık değişimi 300+ etiketli örnek ve en az 7 günlük güvenlik penceresiyle sınırlıdır

## Önemli Android sınırlaması
5 dakikalık arka plan kontrolü best-effort'tur. Android, arka plan çalışmasını erteleyebilir veya foreground service süre sınırlarına tabi tutabilir. Uygulama açıkken veri yenileme ve portföy değerlendirmesi normal çalışma döngüsüyle yapılır.

## Veri yaklaşımı
Varsayılan geçmiş veri akışı İş Yatırım/Yahoo fallback'tir. Anlık veri kullanılmıyorsa uygulama eski veriyi canlıymış gibi göstermemelidir. Gelecekte veri sağlayıcı yalnızca DataService/adaptör katmanında değiştirilmelidir.
