package com.bistaitrader;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements DataService.Listener, NewsService.Listener {
    private final int BG=Color.rgb(8,17,31), SURFACE=Color.rgb(15,27,45), SURFACE2=Color.rgb(20,36,58), LINE=Color.rgb(34,51,77), TEXT=Color.rgb(244,247,251), MUTED=Color.rgb(145,164,186), BLUE=Color.rgb(79,140,255), GREEN=Color.rgb(48,209,88), YELLOW=Color.rgb(255,204,0), RED=Color.rgb(255,69,58);
    private LinearLayout root, content, listHost, nav;
    private TextView title, status, count;
    private EditText search;
    private String filter="Tümü";
    private String sort="Sinyal";
    private final ArrayList<Stock> all=new ArrayList<>(); private Stock current;
    private DataService data; private NewsService news; private PortfolioStore portfolio;
    private LinearLayout detailNewsList;
    private StockAdapter adapter; private Handler timer=new Handler(Looper.getMainLooper()); private Runnable refreshTask;
    private boolean live=false;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,float sp,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(c);t.setFontFeatureSettings("kern");return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),LINE);return g;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(14),dp(14),dp(14));l.setBackground(bg(SURFACE,18));return l;}
    Button chip(String text,boolean selected){Button b=new Button(this);b.setText(text);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(selected?Color.BLACK:TEXT);b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(0);b.setMinimumHeight(dp(34));b.setBackground(bg(selected?BLUE:SURFACE2,18));return b;}
    Button action(String text,int color){Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(color==YELLOW?Color.BLACK:Color.WHITE);b.setTypeface(null,Typeface.BOLD);b.setBackground(bg(color,14));return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);portfolio=new PortfolioStore(this);data=new DataService(this,this);news=new NewsService(this,this); buildShell(); showDashboard(); startRefresh();}
    @Override protected void onResume(){super.onResume(); if(refreshTask!=null)timer.post(refreshTask);}
    @Override protected void onPause(){super.onPause();timer.removeCallbacksAndMessages(null);}

    void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(16),dp(12),dp(16),dp(8));bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);TextView t=tv("BIST AI TRADER",19,TEXT);t.setTypeface(null,Typeface.BOLD);TextView s=tv("Piyasa taraması • sanal işlem",11,MUTED);brand.addView(t);brand.addView(s);
        status=tv("● DEMO",11,YELLOW);status.setGravity(Gravity.RIGHT);bar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));bar.addView(status,new LinearLayout.LayoutParams(dp(85),-2));root.addView(bar);
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(4),dp(12),dp(30));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(dp(8),dp(6),dp(8),dp(6));nav.setBackgroundColor(SURFACE);Button home=navBtn("⌂  Ana");Button market=navBtn("▦  Piyasa");Button fav=navBtn("☆  Takip");Button pf=navBtn("₺  Portföy");Button set=navBtn("⚙  Ayar");nav.addView(home);nav.addView(market);nav.addView(fav);nav.addView(pf);nav.addView(set);root.addView(nav,new LinearLayout.LayoutParams(-1,dp(58)));
        home.setOnClickListener(v->showDashboard());market.setOnClickListener(v->showMarket());fav.setOnClickListener(v->showWatchlist());pf.setOnClickListener(v->showPortfolio());set.setOnClickListener(v->showSettings());setContentView(root);
    }
    Button navBtn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setTextColor(TEXT);b.setBackgroundColor(Color.TRANSPARENT);b.setMinHeight(0);b.setMinimumHeight(0);return b;}

    void showDashboard(){
        if(filter.equals("Takip")) filter="Tümü";
        clear();
        content.addView(tv("Piyasa",25,TEXT));content.addView(tv("Anlık izleme, sinyal motoru ve risk katmanı • 500 hisselik başlangıç kataloğu",12,MUTED)); spacer(10);
        LinearLayout idx=new LinearLayout(this);idx.setOrientation(LinearLayout.HORIZONTAL);
        idx.addView(indexCard("BIST 100","XU100"),new LinearLayout.LayoutParams(0,dp(86),1));spaceH(idx,8);idx.addView(indexCard("BIST 30","XU030"),new LinearLayout.LayoutParams(0,dp(86),1));spaceH(idx,8);idx.addView(indexCard("BIST 500","XU500"),new LinearLayout.LayoutParams(0,dp(86),1));content.addView(idx);spacer(12);
        LinearLayout c=card();c.addView(tv("AI Tarama Merkezi",16,TEXT));c.addView(tv("Tüm katalog • AL / SAT / BEKLE • risk filtresi",11,MUTED));
        LinearLayout chips=new LinearLayout(this);chips.setPadding(0,dp(10),0,0);String[] fs={"Tümü","Düşük Risk","Orta Risk","Yüksek Risk"};for(String f:fs){Button bb=chip(f,f.equals(filter));chips.addView(bb,new LinearLayout.LayoutParams(0,dp(36),1));bb.setOnClickListener(v->{filter=f;showDashboard();});if(!f.equals(fs[fs.length-1]))spaceH(chips,5);}c.addView(chips);content.addView(c);spacer(12);
        LinearLayout stat=card();stat.addView(tv("Öne çıkanlar",16,TEXT));TextView tip=tv("Sinyal gücüne göre sıralanır. Dokunarak ayrıntıya gir.",11,MUTED);stat.addView(tip);content.addView(stat);spacer(8);
        showStockList(filter,false);
    }
    LinearLayout indexCard(String name,String code){LinearLayout c=card();TextView a=tv(name,11,MUTED);TextView b=tv(code,17,TEXT);b.setTypeface(null,Typeface.BOLD);c.addView(a);c.addView(b);c.addView(tv(live?"Canlı veri bağlı":"Veri sağlayıcı bekleniyor",9,live?GREEN:YELLOW));return c;}
    void showMarket(){filter="Tümü";clear();content.addView(tv("Piyasa Tarayıcı",25,TEXT));content.addView(tv("Bütün hisseler ve hızlı filtreler",12,MUTED));spacer(10);buildSearchAndSort();showStockList(filter,true);}
    void buildSearchAndSort(){
        search=new EditText(this);search.setSingleLine(true);search.setHint("Hisse ara: THYAO, ASELS...");search.setHintTextColor(MUTED);search.setTextColor(TEXT);search.setTextSize(13);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(SURFACE2,14));content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){renderList();}public void afterTextChanged(android.text.Editable e){}});spacer(8);
        LinearLayout row=new LinearLayout(this);Button sortB=chip("Sıralama: "+sort,false);sortB.setOnClickListener(v->chooseSort(sortB));Button refresh=chip("↻ Yenile",false);refresh.setOnClickListener(v->data.refresh());row.addView(sortB,new LinearLayout.LayoutParams(0,dp(38),1));spaceH(row,8);row.addView(refresh,new LinearLayout.LayoutParams(0,dp(38),0.65f));content.addView(row);spacer(10);
    }
    void chooseSort(Button b){final String[] ops={"Sinyal","Günlük %","Hacim","Skor","Fiyat"};new AlertDialog.Builder(this).setTitle("Sıralama").setItems(ops,(d,w)->{sort=ops[w];b.setText("Sıralama: "+sort);renderList();}).show();}
    void showWatchlist(){filter="Takip";clear();content.addView(tv("Takip Listem",25,TEXT));content.addView(tv("Favori yıldızına dokunarak hisseleri burada topla",12,MUTED));spacer(12);showStockList("Takip",true);}
    void showStockList(String f,boolean withCount){
        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }
    void renderList(){
        if(listHost==null)return;listHost.removeAllViews();List<Stock> list=new ArrayList<>(all);String q=search==null?"":search.getText().toString().trim().toUpperCase(Locale.US);
        if(filter.equals("Düşük Risk")) list.removeIf(s->!s.risk.equals("Düşük Risk")); else if(filter.equals("Orta Risk")) list.removeIf(s->!s.risk.equals("Orta Risk")); else if(filter.equals("Yüksek Risk")) list.removeIf(s->!s.risk.equals("Yüksek Risk"));
        if(filter.equals("Takip")) list.removeIf(s->!isFavorite(s.symbol));
        if(!q.isEmpty())list.removeIf(s->!s.symbol.contains(q)&&!s.name.toUpperCase(Locale.US).contains(q));
        Comparator<Stock> cmp=Comparator.comparingDouble(s->-s.score);if(sort.equals("Günlük %"))cmp=Comparator.comparingDouble(s->-s.changePct);if(sort.equals("Hacim"))cmp=Comparator.comparingDouble(s->-s.volume);if(sort.equals("Fiyat"))cmp=Comparator.comparingDouble(s->-s.price);list.sort(cmp);
        count=tv(list.size()+" sonuç",11,MUTED);listHost.addView(count);spacerIn(listHost,6);
        adapter=new StockAdapter(this,this::showDetail);ListView lv=new ListView(this);lv.setDivider(null);lv.setDividerHeight(dp(8));lv.setBackgroundColor(Color.TRANSPARENT);lv.setAdapter(adapter);adapter.setItems(list);lv.setPadding(0,0,0,0);listHost.addView(lv,new LinearLayout.LayoutParams(-1,dp(520))); 
    }
    boolean isFavorite(String sym){return getSharedPreferences("favorites",0).getBoolean(sym,false);}
    void toggleFavorite(String sym){getSharedPreferences("favorites",0).edit().putBoolean(sym,!isFavorite(sym)).apply();}

    void showDetail(Stock s){clear();current=s;TextView back=tv("‹  Piyasa",13,BLUE);back.setPadding(0,0,0,dp(8));back.setOnClickListener(v->showMarket());content.addView(back);spacer(4);
        LinearLayout head=card();LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);TextView sym=tv(s.symbol,24,TEXT);sym.setTypeface(null,Typeface.BOLD);left.addView(sym);left.addView(tv(s.name+" • "+s.sector,11,MUTED));TextView fav=tv(isFavorite(s.symbol)?"★":"☆",28,YELLOW);fav.setGravity(Gravity.CENTER);fav.setOnClickListener(v->{toggleFavorite(s.symbol);fav.setText(isFavorite(s.symbol)?"★":"☆");});top.addView(left,new LinearLayout.LayoutParams(0,-2,1));top.addView(fav,new LinearLayout.LayoutParams(dp(48),dp(48)));head.addView(top);
        TextView price=tv(String.format(Locale.US,"%.2f ₺",s.price),30,TEXT);price.setTypeface(null,Typeface.BOLD);head.addView(price);TextView change=tv(String.format(Locale.US,"%+.2f%%   •   %s",s.changePct,s.signal),14,s.changePct>=0?GREEN:RED);head.addView(change);TextView risk=tv("● "+s.risk+"     Skor "+String.format(Locale.US,"%.0f",s.score)+"/100",12,s.risk.startsWith("Düşük")?GREEN:s.risk.startsWith("Yüksek")?RED:YELLOW);risk.setPadding(0,dp(7),0,0);head.addView(risk);content.addView(head);spacer(10);
        MiniChartView chart=new MiniChartView(this);chart.setStock(s);content.addView(chart,new LinearLayout.LayoutParams(-1,dp(210)));spacer(10);
        LinearLayout metrics=card();metrics.addView(tv("Teknik göstergeler",16,TEXT));addMetricGrid(metrics,s);content.addView(metrics);spacer(10);
        LinearLayout levels=card();levels.addView(tv("Destek / Direnç",16,TEXT));levels.addView(tv(String.format(Locale.US,"D1  %.2f   •   D2  %.2f",s.support1,s.support2),13,MUTED));levels.addView(tv(String.format(Locale.US,"R1  %.2f   •   R2  %.2f",s.resistance1,s.resistance2),13,MUTED));levels.addView(tv("Volatilite (ATR): "+String.format(Locale.US,"%.2f%%",s.atrPct),13,MUTED));content.addView(levels);spacer(10);
        LinearLayout ai=card();ai.addView(tv("AI Analiz Özeti",16,TEXT));TextView rs=tv(AnalysisEngine.reason(s),13,TEXT);rs.setPadding(0,dp(8),0,dp(8));ai.addView(rs);ai.addView(tv("Bu sinyal, teknik veriler + haber skoru + volatilite birleşiminden üretilir. Gerçek veri bağlanmadan DEMO etiketi korunur.",11,MUTED));content.addView(ai);spacer(10);
        LinearLayout newsCard=card();newsCard.addView(tv("Haber / KAP akışı",16,TEXT));detailNewsList=new LinearLayout(this);detailNewsList.setOrientation(LinearLayout.VERTICAL);detailNewsList.addView(tv("Yükleniyor...",11,MUTED));newsCard.addView(detailNewsList);content.addView(newsCard);news.refresh(s.symbol);spacer(10);
        LinearLayout trade=card();trade.addView(tv("Sanal işlem",16,TEXT));EditText qty=new EditText(this);qty.setHint("Adet");qty.setText("10");qty.setInputType(2);qty.setTextColor(TEXT);qty.setHintTextColor(MUTED);qty.setBackground(bg(SURFACE2,12));trade.addView(qty,new LinearLayout.LayoutParams(-1,dp(46)));spacerIn(trade,8);LinearLayout rr=new LinearLayout(this);Button buy=action("Sanal AL",GREEN), sell=action("Sanal SAT",RED);rr.addView(buy,new LinearLayout.LayoutParams(0,dp(46),1));spaceH(rr,8);rr.addView(sell,new LinearLayout.LayoutParams(0,dp(46),1));trade.addView(rr);buy.setOnClickListener(v->{tradeNow(s.symbol,qty,true);});sell.setOnClickListener(v->{tradeNow(s.symbol,qty,false);});content.addView(trade);spacer(12);
        content.addView(tv("Son güncelleme: "+time(s.updatedAt)+" • "+(s.live?"CANLI":"DEMO"),10,MUTED));
    }
    void addMetricGrid(LinearLayout box,Stock s){String[][] m={{"RSI (14)",String.format(Locale.US,"%.1f",s.rsi)},{"MACD",String.format(Locale.US,"%.2f",s.macd)},{"EMA 20",String.format(Locale.US,"%.2f",s.ema20)},{"EMA 50",String.format(Locale.US,"%.2f",s.ema50)},{"Hacim",""+compact(s.volume)},{"Ort. Hacim",""+compact(s.avgVolume)}};for(String[] x:m){LinearLayout r=new LinearLayout(this);r.setPadding(0,dp(6),0,dp(6));TextView a=tv(x[0],12,MUTED);TextView b=tv(x[1],13,TEXT);b.setGravity(Gravity.RIGHT);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(b,new LinearLayout.LayoutParams(dp(120),-2));box.addView(r);}}
    String compact(double v){if(v>=1e9)return String.format(Locale.US,"%.1fB",v/1e9);if(v>=1e6)return String.format(Locale.US,"%.1fM",v/1e6);if(v>=1e3)return String.format(Locale.US,"%.1fK",v/1e3);return String.format(Locale.US,"%.0f",v);}
    void tradeNow(String sym,EditText q,boolean buy){int qty;try{qty=Integer.parseInt(q.getText().toString());}catch(Exception e){toast("Geçerli adet gir");return;}Stock s=find(sym);if(s==null)return;boolean ok=buy?portfolio.buy(sym,s.price,qty):portfolio.sell(sym,s.price,qty);toast(ok?(buy?"Sanal alış yapıldı":"Sanal satış yapıldı"):"İşlem yapılamadı • bakiye/adet yetersiz");}

    void showPortfolio(){clear();content.addView(tv("Sanal Portföy",25,TEXT));content.addView(tv("Başlangıç bakiyesi 100.000 ₺ • gerçek para işlemi kapalı",12,MUTED));spacer(12);double cash=portfolio.cash(),value=cash;LinearLayout box=card();box.addView(tv("Portföy Özeti",16,TEXT));for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);Stock s=find(sym);if(s!=null)value+=s.price*q;}box.addView(tv(String.format(Locale.US,"Toplam değer   %.2f ₺",value),18,TEXT));box.addView(tv(String.format(Locale.US,"Nakit   %.2f ₺",cash),13,MUTED));box.addView(tv(String.format(Locale.US,"K/Z   %+.2f ₺",value-100000),13,value>=100000?GREEN:RED));content.addView(box);spacer(10);LinearLayout list=card();list.addView(tv("Pozisyonlar",16,TEXT));for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);if(q<=0)continue;Stock s=find(sym);if(s==null)continue;TextView r=tv(String.format(Locale.US,"%s   %d adet   %.2f ₺",sym,q,s.price*q),13,TEXT);r.setPadding(0,dp(8),0,dp(8));list.addView(r);}content.addView(list);spacer(10);Button reset=action("Portföyü sıfırla",YELLOW);reset.setOnClickListener(v->{portfolio.reset();showPortfolio();});content.addView(reset);}

    void showSettings(){clear();content.addView(tv("Ayarlar",25,TEXT));content.addView(tv("Canlı veri sağlayıcını buradan bağlayabilirsin.",12,MUTED));spacer(12);
        LinearLayout c=card();c.addView(tv("Veri bağlantısı",16,TEXT));c.addView(tv("Borsa İstanbul eşanlı verilerini lisanslı bir dağıtıcı üzerinden alacağız. API bilgilerini uygulamaya yerel olarak gir.",11,MUTED));
        Switch liveS=new Switch(this);liveS.setText("Gerçek veri modu");liveS.setTextColor(TEXT);liveS.setChecked(getSharedPreferences("settings",0).getBoolean("live_mode",false));c.addView(liveS);Switch alertsS=new Switch(this);alertsS.setText("AL/SAT değişim bildirimleri");alertsS.setTextColor(TEXT);alertsS.setChecked(getSharedPreferences("settings",0).getBoolean("alerts",false));c.addView(alertsS);EditText url=field("Quote API URL",getSharedPreferences("settings",0).getString("base_url",""));EditText token=field("API Token (opsiyonel)",getSharedPreferences("settings",0).getString("token",""));EditText newsUrl=field("Haber/KAP API URL",getSharedPreferences("settings",0).getString("news_url",""));EditText refreshSec=field("Yenileme saniyesi (min 2)",String.valueOf(getSharedPreferences("settings",0).getInt("refresh_sec",3)));refreshSec.setInputType(2);c.addView(url);c.addView(token);c.addView(newsUrl);c.addView(refreshSec);Button save=action("Kaydet ve Bağlantıyı Test Et",GREEN);save.setOnClickListener(v->{getSharedPreferences("settings",0).edit().putBoolean("live_mode",liveS.isChecked()).putBoolean("alerts",alertsS.isChecked()).putString("base_url",url.getText().toString().trim()).putString("token",token.getText().toString().trim()).putString("news_url",newsUrl.getText().toString().trim()).putInt("refresh_sec",Math.max(2,parseInt(refreshSec.getText().toString(),3))).apply();toast("Ayarlar kaydedildi");data.refresh();});c.addView(save);content.addView(c);spacer(10);
        LinearLayout r=card();r.addView(tv("Önerilen sağlayıcı sözleşmesi",16,TEXT));r.addView(tv("Gerçek zamanlı BIST verisi için yetkili/lisanslı veri dağıtıcısı gerekir. Eşanlı veri, gecikmeli veri gibi paketlerin koşulları sağlayıcıya göre değişir.",11,MUTED));r.addView(tv("Uygulama, veri sağlayıcının JSON cevabını standart alanlarla kabul eder; ayrıntılı örnek README'de bulunur.",11,MUTED));content.addView(r);spacer(10);
        Button req=action("Bildirimleri aç",BLUE);req.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);else toast("Bildirim izni zaten açık");});content.addView(req);spacer(8);content.addView(tv("Sistem notu: Borsada gerçek anlamda risksiz hisse yoktur. Uygulamadaki üçlü sınıflama volatilite/likidite/analiz ölçümlerine göre göreli risk sınıfıdır.",10,MUTED));}
    EditText field(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(13),0,dp(13),0);e.setBackground(bg(SURFACE2,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(8);e.setLayoutParams(lp);return e;}

    void startRefresh(){int sec=getSharedPreferences("settings",0).getInt("refresh_sec",3);refreshTask=()->{data.refresh();int s=getSharedPreferences("settings",0).getInt("refresh_sec",3);timer.postDelayed(refreshTask,Math.max(2,s)*1000L);};timer.post(refreshTask);}
    @Override public void onData(List<Stock> stocks,boolean l,String msg){all.clear();all.addAll(stocks);live=l;status.setText(l?"● CANLI":"● DEMO");status.setTextColor(l?GREEN:YELLOW);if(listHost!=null)renderList();if(current!=null){Stock updated=find(current.symbol);if(updated!=null)current=updated;}if(l && getSharedPreferences("settings",0).getBoolean("alerts",false)) checkSignalTransitions(stocks);}
    void checkSignalTransitions(List<Stock> stocks){android.content.SharedPreferences p=getSharedPreferences("signals",0);for(Stock s:stocks){String old=p.getString(s.symbol,"");if(!old.isEmpty()&&!old.equals(s.signal)&&!s.signal.equals("BEKLE")) sendSignalNotification(s);p.edit().putString(s.symbol,s.signal).apply();}}
    void sendSignalNotification(Stock s){if(Build.VERSION.SDK_INT>=26){android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);android.app.NotificationChannel ch=new android.app.NotificationChannel("signals","AI Sinyalleri",android.app.NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"signals"):new android.app.Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("BIST AI Trader • "+s.symbol).setContentText(s.signal+" sinyali • Skor "+String.format(Locale.US,"%.0f",s.score)+" • "+s.risk).setAutoCancel(true);((android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(Math.abs(s.symbol.hashCode()),b.build());}
    @Override public void onNews(List<NewsItem> items,String statusMsg){if(detailNewsList==null)return;detailNewsList.removeAllViews();if(items.isEmpty()){detailNewsList.addView(tv(statusMsg,11,MUTED));return;}for(NewsItem n:items){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);TextView h=tv(n.title,13,TEXT);h.setTypeface(null,Typeface.BOLD);TextView m=tv(n.source+"  •  "+n.time+"  •  duygu "+String.format(Locale.US,"%+.2f",n.sentiment),10,MUTED);r.addView(h);r.addView(m);detailNewsList.addView(r);spacerIn(detailNewsList,6);}}
    Stock find(String sym){for(Stock s:all)if(s.symbol.equals(sym))return s;return null;}

    void clear(){content.removeAllViews();search=null;listHost=null;current=null;}
    void spacer(int d){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(d)));}
    void spacerIn(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,dp(d)));}
    void spaceH(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(d),1));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    int parseInt(String s,int def){try{return Integer.parseInt(s);}catch(Exception e){return def;}}
    String time(long t){return new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t));}
}
