package com.bistaitrader;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import java.util.*;

/**
 * Best-effort five-minute virtual-portfolio monitor.
 * It deliberately uses the app's normal DataService/fallback source, not a specific live vendor.
 * It never places an order automatically. Android may defer/stop background work.
 */
public class PortfolioMonitorService extends Service implements DataService.Listener {
    private static final int NOTIFICATION_ID=4705;
    private static final long INTERVAL_MS=5*60*1000L;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable task;
    private DataService data;
    private boolean checking=false;

    @Override public void onCreate(){
        super.onCreate();
        createChannels();
        data=new DataService(this,this);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        startForegroundCompat();
        if(task==null){task=()->{checkNow();handler.postDelayed(task,INTERVAL_MS);};handler.post(task);}
        return START_STICKY;
    }

    private void checkNow(){
        if(checking)return;
        android.content.SharedPreferences sp=getSharedPreferences("settings",0);
        if(!sp.getBoolean("portfolio_alerts_enabled",true)){stopSelf();return;}
        PortfolioStore p=new PortfolioStore(this);
        if(!p.hasPositions()){getSharedPreferences("runtime",0).edit().putString("portfolio_monitor_status","Pozisyon yok").apply();return;}
        checking=true;
        getSharedPreferences("runtime",0).edit().putString("portfolio_monitor_status","5 dk kontrolü çalışıyor").apply();
        try{data.refresh();}catch(Exception e){checking=false;getSharedPreferences("runtime",0).edit().putLong("portfolio_last_monitor",System.currentTimeMillis()).putString("portfolio_monitor_status","Veri yenileme hatası: "+safe(e)).apply();}
    }

    @Override public void onData(List<Stock> stocks,boolean isLive,String msg){
        if(!checking)return;
        try{
            int triggered=0;long newest=0;
            PortfolioStore p=new PortfolioStore(this);
            PredictionStore ps=new PredictionStore(this);
            for(Stock s:stocks){
                if(s==null||s.price<=0||p.qty(s.symbol)<=0)continue;
                newest=Math.max(newest,s.quoteTime>0?s.quoteTime:System.currentTimeMillis());
                PortfolioAlertEngine.Decision d=PortfolioAlertEngine.evaluate(this,s.symbol,s.price,s);
                ps.observeQuote(s.symbol,s.price,System.currentTimeMillis());
                if(d.notify){triggered++;sendAlert(d);}
            }
            long now=System.currentTimeMillis();
            getSharedPreferences("runtime",0).edit().putLong("portfolio_last_monitor",now).putLong("last_quote_time",newest>0?newest:now).putString("quote_source",isLive?"Canlı veri sağlayıcısı":"İş Yatırım / fallback").putString("portfolio_monitor_status",triggered>0?triggered+" yeni alarm":"Kontrol tamam • "+time(now)).apply();
        }finally{checking=false;}
    }

    private void sendAlert(PortfolioAlertEngine.Decision d){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)return;
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"portfolio"):new Notification.Builder(this);
        String clean=d.message.replace("\\n"," • ");
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("BIST AI Trader • "+d.title).setContentText(clean).setStyle(new Notification.BigTextStyle().bigText(d.message.replace("\\n","\n"))).setAutoCancel(true);
        ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(Math.abs((d.symbol+"_"+d.key).hashCode()),b.build());
    }

    private void createChannels(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("portfolio","Portföy Alarmları",NotificationManager.IMPORTANCE_HIGH));nm.createNotificationChannel(new NotificationChannel("portfolio_service","Portföy İzleme",NotificationManager.IMPORTANCE_LOW));}
    }
    private void startForegroundCompat(){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"portfolio_service"):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_popup_sync).setContentTitle("BIST AI Trader").setContentText("Sanal portföy 5 dk kontrolü aktif").setOngoing(true).setShowWhen(false);
        Notification n=b.build();
        if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(NOTIFICATION_ID,n);
    }
    private String safe(Exception e){return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
    private String time(long t){return new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t));}
    @Override public void onDestroy(){if(task!=null)handler.removeCallbacks(task);if(data!=null)data.shutdown();super.onDestroy();}
    @Override public void onTimeout(int startId,int fgsType){getSharedPreferences("runtime",0).edit().putString("portfolio_monitor_status","Android 15 arka plan süre sınırı nedeniyle durdu • uygulamayı açınca yeniden başlatılır").apply();stopSelf();}
    @Override public IBinder onBind(Intent intent){return null;}
}
