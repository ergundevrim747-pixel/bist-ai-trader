package com.bistaitrader;

import java.util.*;

public final class AnalysisEngine {
    private AnalysisEngine() {}

    public static void enrichDemo(Stock s, int index) {
        if (s.price <= 0) {
            double base = 15 + ((Math.abs(s.symbol.hashCode()) % 900) / 10.0);
            if (s.symbol.equals("THYAO")) base = 312.50;
            if (s.symbol.equals("ASELS")) base = 184.30;
            if (s.symbol.equals("AKBNK")) base = 68.10;
            if (s.symbol.equals("SAHOL")) base = 121.40;
            if (s.symbol.equals("TUPRS")) base = 169.80;
            if (s.symbol.equals("BIMAS")) base = 574.20;
            s.price = base;
            s.previousClose = base * 0.995;
        }
        double ch = s.changePct;
        s.rsi = clamp(50 + ch * 2.8 + Math.sin(index * .5) * 4, 25, 75);
        s.macd = ch * .10;
        s.macdSignal = ch * .06;
        s.ema20 = s.price * (1 - ch / 900.0);
        s.ema50 = s.price * (1 - ch / 650.0);
        s.ema200 = s.price * (1 - ch / 500.0);
        s.atrPct = Math.max(1.2, Math.abs(ch) * .8);
        s.momentumPct = ch;
        s.avgVolume = Math.max(100000, s.volume <= 0 ? 1000000 : s.volume);
        s.volumeRatio = s.avgVolume <= 0 ? 1 : s.volume / s.avgVolume;
        s.bollingerUpper = s.price * 1.04;
        s.bollingerLower = s.price * .96;
        s.trend = s.price > s.ema20 && s.ema20 > s.ema50 ? "Yukarı" : s.price < s.ema20 && s.ema20 < s.ema50 ? "Aşağı" : "Yatay/Karışık";
        s.score = clamp(50 + ch * 7, 5, 95);
        s.signal = s.score >= 68 ? "AL" : s.score <= 32 ? "SAT" : "BEKLE";
        s.risk = riskFor(s.atrPct, s.volumeRatio);
        double swing = s.price * Math.max(.01, s.atrPct / 100.0);
        s.support1 = Math.max(.01, s.price - swing);
        s.support2 = Math.max(.01, s.price - swing * 2);
        s.resistance1 = s.price + swing;
        s.resistance2 = s.price + swing * 2;
        s.stopPrice = Math.max(.01, s.price - swing * 1.6);
        s.targetPrice = s.price + swing * 2.4;
        s.updatedAt = System.currentTimeMillis();
        s.live = false;
        s.analysisReady = false;
    }

    /** Keeps live quote correct while richer historical analysis is loading. */
    public static void enrichLiveQuote(Stock s) {
        double ch = s.changePct;
        s.rsi = clamp(50 + ch * 2.5, 20, 80);
        s.macd = ch * .10;
        s.macdSignal = ch * .08;
        s.ema20 = s.price * (1.0 - ch / 1000.0);
        s.ema50 = s.price * (1.0 - ch / 750.0);
        s.ema200 = s.price * (1.0 - ch / 550.0);
        s.atrPct = Math.max(1.0, Math.abs(ch) * .75);
        s.momentumPct = ch;
        if (s.avgVolume <= 0) s.avgVolume = Math.max(1, s.volume);
        s.volumeRatio = s.avgVolume <= 0 ? 1 : s.volume / s.avgVolume;
        s.newsScore = 0;
        s.trend = s.price > s.ema20 && s.ema20 > s.ema50 ? "Yukarı" : s.price < s.ema20 && s.ema20 < s.ema50 ? "Aşağı" : "Yatay/Karışık";
        double technical = 50 + ch * 6.0 + (s.rsi - 50) * .35 + s.macd * 8 + (s.volumeRatio > 1.2 ? 5 : 0);
        s.score = clamp(technical, 5, 95);
        s.signal = s.score >= 68 ? "AL" : s.score <= 32 ? "SAT" : "BEKLE";
        s.risk = riskFor(s.atrPct, s.volumeRatio);
        double swing = s.price * Math.max(.01, s.atrPct / 100.0);
        s.support1 = Math.max(.01, s.price - swing);
        s.support2 = Math.max(.01, s.price - swing * 2);
        s.resistance1 = s.price + swing;
        s.resistance2 = s.price + swing * 2;
        s.stopPrice = Math.max(.01, s.price - swing * 1.6);
        s.targetPrice = s.price + swing * 2.4;
        s.analysisReady = false;
    }

    public static void enrichFromHistory(Stock s, List<Candle> bars) {
        if (bars == null || bars.size() < 20) return;
        int n = bars.size();
        double[] close = new double[n], high = new double[n], low = new double[n], volume = new double[n];
        for (int i = 0; i < n; i++) { Candle c = bars.get(i); close[i]=c.close; high[i]=c.high; low[i]=c.low; volume[i]=c.volume; }

        s.ema20 = ema(close, 20);
        s.ema50 = ema(close, 50);
        s.ema200 = ema(close, 200);
        s.rsi = rsi(close, 14);
        double[] macd = macd(close, 12, 26, 9);
        s.macd = macd[0]; s.macdSignal = macd[1];
        s.atrPct = atrPercent(close, high, low, 14);
        s.momentumPct = pctAgo(close, Math.min(20, n - 1));
        s.avgVolume = average(volume, Math.min(20, n));
        s.volumeRatio = s.avgVolume <= 0 ? 1 : volume[n-1] / s.avgVolume;
        double sd = stddevLast(close, 20);
        double mean = average(close, Math.min(20, n));
        s.bollingerUpper = mean + 2 * sd;
        s.bollingerLower = Math.max(0, mean - 2 * sd);

        s.support1 = rollingLow(low, 20);
        s.support2 = rollingLow(low, Math.min(60, n));
        s.resistance1 = rollingHigh(high, 20);
        s.resistance2 = rollingHigh(high, Math.min(60, n));

        boolean upTrend = close[n-1] > s.ema20 && s.ema20 > s.ema50;
        boolean downTrend = close[n-1] < s.ema20 && s.ema20 < s.ema50;
        s.trend = upTrend ? "Yukarı" : downTrend ? "Aşağı" : "Yatay/Karışık";

        double score = 50;
        if (upTrend) score += 18; else if (downTrend) score -= 18;
        if (s.ema50 > 0 && s.ema20 > s.ema50) score += 7; else if (s.ema20 > 0 && s.ema20 < s.ema50) score -= 7;
        if (s.ema200 > 0 && close[n-1] > s.ema200) score += 5; else if (s.ema200 > 0) score -= 5;
        if (s.rsi >= 55 && s.rsi < 72) score += 13; else if (s.rsi <= 35) score -= 10; else if (s.rsi >= 72) score -= 4;
        if (s.macd > s.macdSignal) score += 12; else score -= 12;
        if (s.momentumPct > 0) score += 8; else score -= 8;
        if (s.volumeRatio >= 1.35) score += 8; else if (s.volumeRatio < .65) score -= 3;
        double news = clamp(s.newsScore, -1, 1) * 5;
        score += news;
        s.score = clamp(score, 0, 100);
        s.signal = s.score >= 68 ? "AL" : s.score <= 32 ? "SAT" : "BEKLE";
        s.risk = riskFor(s.atrPct, s.volumeRatio);
        double riskUnit = s.price * Math.max(.008, s.atrPct / 100.0);
        s.stopPrice = Math.max(.01, s.price - riskUnit * 1.5);
        s.targetPrice = s.price + riskUnit * 2.5;
        s.analysisReady = true;
        s.updatedAt = System.currentTimeMillis();
    }

    private static double ema(double[] a, int period) {
        if (a.length == 0) return 0;
        int p = Math.min(period, a.length);
        double e = a[0], k = 2.0 / (p + 1.0);
        for (int i=1;i<a.length;i++) e = a[i] * k + e * (1-k);
        return e;
    }

    private static double rsi(double[] c, int p) {
        if (c.length <= 1) return 50;
        int period = Math.min(p, c.length-1);
        double gain=0, loss=0;
        for(int i=1;i<=period;i++){double d=c[i]-c[i-1];if(d>=0)gain+=d;else loss-=d;}
        gain/=period; loss/=period;
        for(int i=period+1;i<c.length;i++){double d=c[i]-c[i-1];double g=Math.max(0,d),l=Math.max(0,-d);gain=(gain*(period-1)+g)/period;loss=(loss*(period-1)+l)/period;}
        if(loss==0)return 100;double rs=gain/loss;return 100-(100/(1+rs));
    }

    private static double[] macd(double[] c,int fast,int slow,int signalPeriod){
        int f=Math.min(fast,c.length), s=Math.min(slow,c.length); double ef=ema(c,f), es=ema(c,s); double line=ef-es;
        ArrayList<Double> values=new ArrayList<>(); double prevF=c[0], prevS=c[0];
        double kf=2.0/(f+1), ks=2.0/(s+1);
        for(int i=1;i<c.length;i++){prevF=c[i]*kf+prevF*(1-kf);prevS=c[i]*ks+prevS*(1-ks);values.add(prevF-prevS);}
        int sp=Math.min(signalPeriod,Math.max(1,values.size()));double sig=values.isEmpty()?0:values.get(0),k=2.0/(sp+1);
        for(int i=1;i<values.size();i++)sig=values.get(i)*k+sig*(1-k);
        return new double[]{line,sig};
    }

    private static double atrPercent(double[] close,double[] high,double[] low,int period){
        if(close.length<2)return 0;int p=Math.min(period,close.length-1);double atr=0;
        for(int i=1;i<=p;i++){double tr=Math.max(high[i]-low[i],Math.max(Math.abs(high[i]-close[i-1]),Math.abs(low[i]-close[i-1])));atr+=tr;}atr/=p;return close[close.length-1]<=0?0:(atr/close[close.length-1])*100;
    }
    private static double pctAgo(double[] c,int days){int i=Math.max(0,c.length-1-days);double base=c[i];return base==0?0:(c[c.length-1]/base-1)*100;}
    private static double average(double[] a,int count){if(a.length==0)return 0;int start=Math.max(0,a.length-count);double sum=0;for(int i=start;i<a.length;i++)sum+=a[i];return sum/(a.length-start);}
    private static double stddevLast(double[] a,int count){if(a.length==0)return 0;int start=Math.max(0,a.length-count);double m=average(a,count),ss=0;for(int i=start;i<a.length;i++){double d=a[i]-m;ss+=d*d;}return Math.sqrt(ss/Math.max(1,a.length-start));}
    private static double rollingLow(double[] a,int count){int start=Math.max(0,a.length-count);double v=Double.MAX_VALUE;for(int i=start;i<a.length;i++)v=Math.min(v,a[i]);return v==Double.MAX_VALUE?0:v;}
    private static double rollingHigh(double[] a,int count){int start=Math.max(0,a.length-count);double v=0;for(int i=start;i<a.length;i++)v=Math.max(v,a[i]);return v;}
    private static String riskFor(double atr,double volumeRatio){if(atr<2.5 && volumeRatio>=.65)return "Düşük Risk";if(atr<5.5)return "Orta Risk";return "Yüksek Risk";}
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}

    public static String reason(Stock s) {
        String trend = "Trend: " + s.trend;
        String momentum = String.format(Locale.forLanguageTag("tr-TR"), "RSI %.1f • 20G momentum %+.2f%%", s.rsi, s.momentumPct);
        String macd = s.macd > s.macdSignal ? "MACD pozitif kesişim bölgesinde" : "MACD zayıf/negatif bölgede";
        String volume = s.volumeRatio >= 1.35 ? "hacim ortalamanın belirgin üzerinde" : s.volumeRatio < .65 ? "hacim düşük" : "hacim normal";
        return trend + " • " + momentum + " • " + macd + " • " + volume + ".";
    }
}
