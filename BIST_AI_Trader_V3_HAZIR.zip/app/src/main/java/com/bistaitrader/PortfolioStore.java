package com.bistaitrader;

import android.content.Context;
import org.json.*;
import java.util.*;

public class PortfolioStore {
    private final Context c; private final android.content.SharedPreferences sp;
    public PortfolioStore(Context c){this.c=c.getApplicationContext(); sp=c.getSharedPreferences("portfolio",Context.MODE_PRIVATE);}
    public double cash(){return Double.longBitsToDouble(sp.getLong("cash",Double.doubleToLongBits(100000.0)));}
    public void setCash(double v){sp.edit().putLong("cash",Double.doubleToLongBits(v)).apply();}
    public int qty(String sym){return sp.getInt("q_"+sym,0);}
    public void setQty(String sym,int q){sp.edit().putInt("q_"+sym,Math.max(0,q)).apply();}
    public Set<String> symbols(){String raw=sp.getString("symbols",""); Set<String> out=new LinkedHashSet<>(); if(!raw.isEmpty()) out.addAll(Arrays.asList(raw.split(","))); return out;}
    private void addSymbol(String sym){Set<String> s=symbols();s.add(sym);sp.edit().putString("symbols",String.join(",",s)).apply();}
    public boolean buy(String sym,double price,int q){if(q<=0||price<=0)return false;double cost=price*q;if(cost>cash())return false;setCash(cash()-cost);setQty(sym,qty(sym)+q);addSymbol(sym);return true;}
    public boolean sell(String sym,double price,int q){if(q<=0||price<=0||qty(sym)<q)return false;setCash(cash()+price*q);setQty(sym,qty(sym)-q);return true;}
    public void reset(){sp.edit().clear().apply();setCash(100000);}
}
