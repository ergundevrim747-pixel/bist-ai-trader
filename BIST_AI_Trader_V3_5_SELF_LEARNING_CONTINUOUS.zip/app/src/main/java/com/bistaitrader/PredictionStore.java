package com.bistaitrader;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/**
 * Counterfactual / paper-prediction memory. It works without any real portfolio position:
 * every qualifying AL setup can be tracked, evaluated against later daily OHLCV, and fed back
 * into the learning store. No broker order is created.
 */
public final class PredictionStore {
    public static final int MAX_OPEN = 250;
    public static final int MAX_CLOSED = 4000;
    public static final int MAX_HOLD_BARS = 15;
    private final android.content.SharedPreferences sp;
    public PredictionStore(Context c){sp=c.getApplicationContext().getSharedPreferences("ai_predictions",Context.MODE_PRIVATE);}

    public static final class Report {
        public int open, closed, wins, losses, partials;
        public double winRate, avgPnl, avgWin, avgLoss;
        public final LinkedHashMap<String,Integer> reasons=new LinkedHashMap<>();
    }

    public synchronized void observeAnalysis(Stock s, List<Candle> bars){
        if(s==null||bars==null||bars.size()==0||!s.analysisReady)return;
        long signalTime=bars.get(bars.size()-1).time;
        JSONArray a=read("open");
        // First resolve old paper predictions against the newest OHLCV.
        evaluateHistory(s.symbol,bars);
        a=read("open");
        if(!"AL".equals(s.signal)||!s.hardGateOk||s.stopPrice<=0||s.targetPrice<=0)return;
        String id=s.symbol+"|AL|"+signalTime;
        for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&id.equals(p.optString("id")))return;}
        // Avoid replacing a still-open prediction with a near-identical same-day signal.
        for(int i=0;i<a.length();i++){
            JSONObject p=a.optJSONObject(i); if(p==null||!s.symbol.equals(p.optString("symbol")))continue;
            long t=p.optLong("time",0); if(Math.abs(signalTime-t)<36L*3600_000L)return;
        }
        try{
            JSONObject p=new JSONObject();
            p.put("id",id);p.put("symbol",s.symbol);p.put("signal","AL");p.put("time",signalTime);
            double entry=s.entryLow>0&&s.entryHigh>0?(s.entryLow+s.entryHigh)/2.0:s.price;
            p.put("entry",entry);p.put("entryLow",s.entryLow);p.put("entryHigh",s.entryHigh);
            p.put("stop",s.stopPrice);p.put("t1",s.targetPrice);p.put("t2",s.targetPrice2);p.put("trailing",s.trailingStop);
            p.put("score",s.score);p.put("confidence",s.confidence);p.put("conditions",s.conditionsMet);p.put("setup",s.setupType);
            p.put("stage",s.stage);p.put("market",s.marketRegime);p.put("rs",s.relativeStrengthPct);p.put("adx",s.adx);
            p.put("volRatio",s.volumeRatio);p.put("atrPct",s.atrPct);p.put("stopPct",s.stopPct);p.put("rr1",s.rr1);p.put("rr2",s.rr2);
            p.put("rsi",s.rsiOk);p.put("macd",s.macdOk);p.put("ema",s.emaOk);p.put("volume",s.volumeOk);p.put("trend",s.trendOk);p.put("support",s.supportOk);p.put("momentum",s.momentumOk);
            p.put("breakout",s.breakoutConfirmed);p.put("pullback",s.pullbackConfirmed);p.put("contraction",s.contractionConfirmed);
            p.put("overextended",s.overextended);p.put("volShock",s.volatilityShock);p.put("distribution",s.distributionFlag);p.put("rsOk",s.relativeStrengthOk);
            p.put("status","OPEN");p.put("t1Hit",false);p.put("barsHeld",0);p.put("maxFavPct",0);p.put("maxAdvPct",0);p.put("realizedPct",0);
            p.put("lastQuote",s.price);p.put("lastQuoteTime",System.currentTimeMillis());p.put("origin","continuous");
            a.put(p);while(a.length()>MAX_OPEN)a.remove(0);write("open",a);
        }catch(Exception ignored){}
    }

    /** Live quotes update paper-PnL extrema only; final labels are confirmed by OHLCV history. */
    public synchronized void observeQuote(String symbol,double price,long now){
        if(symbol==null||price<=0)return;
        ArrayList<Stock> one=new ArrayList<>();Stock s=new Stock();s.symbol=symbol;s.price=price;one.add(s);observeQuotes(one,now);
    }

    /** Batch version: one JSON read/write for all quotes, so 1-second refresh cannot cause hundreds of preference writes. */
    public synchronized void observeQuotes(List<Stock> stocks,long now){
        if(stocks==null||stocks.isEmpty())return;JSONArray a=read("open");if(a.length()==0)return;
        HashMap<String,Double> prices=new HashMap<>();for(Stock s:stocks)if(s!=null&&s.symbol!=null&&s.price>0)prices.put(s.symbol,s.price);
        boolean changed=false;
        for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;Double price=prices.get(p.optString("symbol"));if(price==null||price<=0)continue;double entry=p.optDouble("entry",0);if(entry<=0)continue;double ret=(price/entry-1)*100.0;
            try{p.put("lastQuote",price);p.put("lastQuoteTime",now);p.put("maxFavPct",Math.max(p.optDouble("maxFavPct",0),ret));p.put("maxAdvPct",Math.min(p.optDouble("maxAdvPct",0),ret));changed=true;}catch(Exception ignored){}
        }
        if(changed)write("open",a);
    }

    public synchronized int evaluateHistory(String symbol,List<Candle> bars){
        if(symbol==null||bars==null||bars.size()<2)return 0;
        ArrayList<Candle> clean=new ArrayList<>(bars);clean.sort((x,y)->Long.compare(x.time,y.time));
        JSONArray a=read("open"); if(a.length()==0)return 0;
        return evaluateHistoryInternal(symbol,clean,null);
    }

    public synchronized int evaluateHistory(Context context,String symbol,List<Candle> bars){
        if(symbol==null||bars==null||bars.size()<2)return 0;
        ArrayList<Candle> clean=new ArrayList<>(bars);clean.sort((x,y)->Long.compare(x.time,y.time));
        return evaluateHistoryInternal(symbol,clean,context);
    }

    private int evaluateHistoryInternal(String symbol,List<Candle> bars,Context context){
        JSONArray a=read("open"); if(a.length()==0)return 0; int closed=0;JSONArray keep=new JSONArray();
        for(int pi=0;pi<a.length();pi++){
            JSONObject p=a.optJSONObject(pi);if(p==null){continue;}if(!symbol.equals(p.optString("symbol"))){keep.put(p);continue;}
            boolean isClosed=false;
            long entryTime=p.optLong("time",0);double entry=p.optDouble("entry",0),stop=p.optDouble("stop",0),t1=p.optDouble("t1",0),t2=p.optDouble("t2",0);
            boolean t1Hit=p.optBoolean("t1Hit",false);double realized=p.optDouble("realizedPct",0);int held=p.optInt("barsHeld",0);
            double maxFav=p.optDouble("maxFavPct",0),maxAdv=p.optDouble("maxAdvPct",0);
            for(Candle b:bars){
                if(b==null||b.time<=entryTime)continue;
                if(entry<=0||stop<=0||t1<=0){isClosed=true;try{p.put("status","DATA_ERROR");}catch(Exception ignored){}break;}
                held++;
                boolean t1JustHit=false;
                double hiRet=(b.high/entry-1)*100.0, loRet=(b.low/entry-1)*100.0;
                maxFav=Math.max(maxFav,hiRet);maxAdv=Math.min(maxAdv,loRet);
                if(!t1Hit){
                    // Conservative daily-candle sequencing: when stop and target occur in the same
                    // candle, stop is treated as having happened first because intraday path is unknown.
                    if(b.open<=stop || b.low<=stop){double px=b.open<=stop?b.open:stop;double pnl=(px/entry-1)*100.0;closePrediction(p,"STOP",b.time,pnl,maxFav,maxAdv,held,reasonForLoss(p,maxFav,entry,stop, false),context);isClosed=true;break;}
                    if(t2>0&&b.high>=t2){double full=(t2/entry-1)*100.0;pnlSet(p,"T2",b.time,(t1/entry-1)*50.0+(t2/entry-1)*50.0,maxFav,maxAdv,held,context);isClosed=true;break;}
                    if(b.high>=t1){t1Hit=true;t1JustHit=true;realized=(t1/entry-1)*0.5*100.0;try{p.put("t1Hit",true);p.put("realizedPct",realized);p.put("t1Time",b.time);}catch(Exception ignored){}}
                }
                if(t1Hit&&!t1JustHit&&!isClosed){
                    double be=entry*1.002;
                    if(t2>0&&b.high>=t2){double pnl=realized+(t2/entry-1)*50.0;closePrediction(p,"T2",b.time,pnl,maxFav,maxAdv,held,"T2 hedefi gerçekleşti",context);isClosed=true;break;}
                    if(b.open<=be || b.low<=be){double px=b.open<=be?b.open:be;double pnl=realized+(px/entry-1)*50.0;closePrediction(p,"T1_BE",b.time,pnl,maxFav,maxAdv,held,"T1 gerçekleşti; kalan pozisyon başa baş/koruma stopuyla kapandı",context);isClosed=true;break;}
                }
                if(held>=MAX_HOLD_BARS){
                    double pnl;
                    if(t1Hit)pnl=realized+(b.close/entry-1)*50.0;else pnl=(b.close/entry-1)*100.0;
                    closePrediction(p,pnl>0?"TIMEOUT_PROFIT":"TIMEOUT",b.time,pnl,maxFav,maxAdv,held,pnl>0?"Süre doldu ama tahmin pozitif sonuçlandı":"Süre doldu; T1/stop oluşmadan plan başarısız kaldı",context);isClosed=true;break;
                }
            }
            if(!isClosed){try{p.put("t1Hit",t1Hit);p.put("realizedPct",realized);p.put("barsHeld",held);p.put("maxFavPct",maxFav);p.put("maxAdvPct",maxAdv);}catch(Exception ignored){}keep.put(p);}else closed++;
        }
        write("open",keep);return closed;
    }

    private void closePrediction(JSONObject p,String status,long t,double pnl,double maxFav,double maxAdv,int held,String reason,Context context){
        try{p.put("status",status);p.put("closedAt",t);p.put("pnl",pnl);p.put("maxFavPct",maxFav);p.put("maxAdvPct",maxAdv);p.put("barsHeld",held);p.put("reason",reason);p.put("learningRecorded",true);
            JSONArray c=read("closed");c.put(p);while(c.length()>MAX_CLOSED)c.remove(0);write("closed",c);
            if(context!=null)new LearningStore(context).recordPredictionOutcome(p);
        }catch(Exception ignored){}
    }
    private void pnlSet(JSONObject p,String status,long t,double pnl,double maxFav,double maxAdv,int held,Context context){
        try{
            p.put("status",status);p.put("closedAt",t);p.put("pnl",pnl);p.put("maxFavPct",maxFav);p.put("maxAdvPct",maxAdv);p.put("barsHeld",held);p.put("reason","T2 hedefi gerçekleşti");p.put("learningRecorded",true);
            JSONArray c=read("closed");c.put(p);while(c.length()>MAX_CLOSED)c.remove(0);write("closed",c);
            if(context!=null)new LearningStore(context).recordPredictionOutcome(p);
        }catch(Exception ignored){}
    }
    private static String reasonForLoss(JSONObject p,double maxFav,double entry,double stop,boolean dummy){
        if(p.optBoolean("volShock",false))return "Volatilite şoku";
        if("Riskli".equals(p.optString("market")))return "Piyasa koşulu ters";
        if(p.optBoolean("distribution",false))return "Dağıtım / satış baskısı";
        if(p.optBoolean("breakout",false)&&maxFav<Math.max(0.5,Math.abs(p.optDouble("rr1",2))*0.25))return "Fake breakout / kırılım teyitsiz";
        if(p.optBoolean("breakout",false)&&p.optDouble("volRatio",0)<1.25)return "Hacim teyidi zayıf";
        if(p.optDouble("rs",0)<-1)return "BIST100'e göre göreli güç zayıf";
        if(p.optDouble("adx",0)<16)return "Trend gücü zayıf (ADX)";
        if(!p.optBoolean("trend",false))return "Trend teyidi zayıf";
        if(p.optBoolean("overextended",false))return "Aşırı uzama / fiyat kovalanması";
        if(p.optDouble("stopPct",0)>5.0)return "Yüksek volatilite / geniş stop";
        if(!p.optBoolean("volume",false))return "Hacim teyidi yetersiz";
        if(!p.optBoolean("support",false))return "Destek yapısı zayıf";
        return "Yapı bozuldu / belirgin tek neden yok";
    }

    public synchronized Report report(){
        Report r=new Report();JSONArray o=read("open"),c=read("closed");r.open=o.length();r.closed=c.length();double p=0,wp=0,lp=0;int w=0,l=0;
        for(int i=0;i<c.length();i++){JSONObject x=c.optJSONObject(i);if(x==null)continue;double pnl=x.optDouble("pnl",0);p+=pnl;if(pnl>0){w++;wp+=pnl;}else if(pnl<0){l++;lp+=pnl;}String reason=x.optString("reason","");if(pnl<0&&reason.length()>0)r.reasons.put(reason,r.reasons.containsKey(reason)?r.reasons.get(reason)+1:1);}
        r.wins=w;r.losses=l;r.winRate=(w+l)==0?0:w*100.0/(w+l);r.avgPnl=r.closed==0?0:p/r.closed;r.avgWin=w==0?0:wp/w;r.avgLoss=l==0?0:lp/l;return r;
    }
    public JSONArray open(){return read("open");}
    public JSONArray closed(){return read("closed");}
    public long lastMonitor(){return sp.getLong("last_monitor",0);}
    public void setLastMonitor(long t){sp.edit().putLong("last_monitor",t).apply();}
    public String monitorStatus(){return sp.getString("monitor_status","Bekleniyor");}
    public void setMonitorStatus(String s){sp.edit().putString("monitor_status",s==null?"":s).apply();}
    private JSONArray read(String k){try{return new JSONArray(sp.getString(k,"[]"));}catch(Exception e){return new JSONArray();}}
    private void write(String k,JSONArray a){sp.edit().putString(k,a.toString()).apply();}
}
