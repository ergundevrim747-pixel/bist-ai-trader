package com.bistaitrader;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Historical daily OHLCV loader.
 * Primary source: public Yahoo Finance chart endpoint.
 * Fallback: public İş Yatırım historical close/volume endpoint.
 * Requests are cached in memory to avoid repeated network traffic.
 */
public class HistoryService {
    public interface Listener { void onHistory(String symbol, String rangeKey, List<Candle> candles, String source, String message); }
    public interface ScanListener { void onScanProgress(int done, int total, Stock stock); void onScanFinished(int completed, int total); }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Map<String, List<Candle>> cache = new HashMap<>();
    private final Map<String, Long> lastFetch = new HashMap<>();

    public HistoryService(Context c) { context = c.getApplicationContext(); }
    public void shutdown(){ executor.shutdownNow(); main.removeCallbacksAndMessages(null); }

    public void load(String symbol, String rangeKey, Listener listener) {
        final String sym = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);
        final String range = rangeKey == null ? "6A" : rangeKey;
        final String key = sym + "|" + range;
        synchronized (cache) {
            List<Candle> cached = cache.get(key);
            if (cached != null && !cached.isEmpty()) {
                final List<Candle> copy = new ArrayList<>(cached);
                main.post(() -> listener.onHistory(sym, range, copy, "Önbellek", "Geçmiş veri önbellekten gösteriliyor"));
                Long t = lastFetch.get(key);
                if (t != null && System.currentTimeMillis() - t < 5 * 60_000L) return;
            }
        }
        executor.execute(() -> {
            try {
                List<Candle> candles = fetchYahoo(sym, range);
                if (candles.size() < 20) throw new Exception("Yeterli Yahoo tarihsel verisi yok");
                synchronized (cache) { cache.put(key, candles); lastFetch.put(key, System.currentTimeMillis()); }
                post(listener, sym, range, candles, "Yahoo Finance", "Geçmiş OHLCV verisi güncellendi");
            } catch (Exception yahooError) {
                try {
                    List<Candle> fallback = fetchIsYatirim(sym, range);
                    if (fallback.size() < 10) throw new Exception("Yeterli İş Yatırım geçmiş verisi yok");
                    synchronized (cache) { cache.put(key, fallback); lastFetch.put(key, System.currentTimeMillis()); }
                    post(listener, sym, range, fallback, "İş Yatırım", "Yahoo geçmiş verisi alınamadı; İş Yatırım geçmiş verisi kullanılıyor");
                } catch (Exception fallbackError) {
                    List<Candle> empty = Collections.emptyList();
                    post(listener, sym, range, empty, "", "Geçmiş veri alınamadı. Bağlantıyı kontrol et.");
                }
            }
        });
    }

    /** Background scanner. Requests are parallelized but bounded so the UI stays responsive. */
    public void scan(List<String> symbols, String rangeKey, String strategy, ScanListener listener) {
        final ArrayList<String> list = new ArrayList<>();
        if (symbols != null) for (String x : symbols) if (x != null && !x.trim().isEmpty()) list.add(x.trim().toUpperCase(Locale.US));
        final int total = list.size();
        if (total == 0) { main.post(() -> listener.onScanFinished(0, 0)); return; }
        List<Candle> benchmark = cachedBenchmark("1Y");
        if (benchmark.size() < AnalysisEngine.MIN_DEEP_BARS || !hasStrictFullOhlc(benchmark)) {
            try { benchmark = fetchYahoo("XU100", "1Y");
            } catch (Exception ignored) { benchmark = Collections.emptyList(); }
            if (benchmark.size() >= 40 && hasStrictFullOhlc(benchmark)) {
                synchronized (cache) { cache.put("XU100|1Y", new ArrayList<>(benchmark)); lastFetch.put("XU100|1Y", System.currentTimeMillis()); }
            }
        }
        final List<Candle> scanBenchmark = new ArrayList<>(benchmark);
        final AtomicInteger done = new AtomicInteger(0);
        for (String sym : list) {
            executor.execute(() -> {
                Stock st = new Stock(); st.symbol = sym; st.name = sym; st.sector = "BIST";
                try {
                    List<Candle> candles = fetchYahoo(sym, "1Y");
                    if (candles.size() < 35) throw new Exception("Yeterli Yahoo verisi yok");
                    AnalysisEngine.enrichFromHistory(st, candles, strategy, scanBenchmark);
                    LearningEngine.harvestHistory(new LearningStore(context), sym, candles, strategy);
                    PredictionStore ps=new PredictionStore(context);
                    ps.evaluateHistory(context,sym,candles);
                    ps.observeAnalysis(st,candles);
                    synchronized (cache) { cache.put(sym + "|SCAN", new ArrayList<>(candles)); }
                } catch (Exception e) {
                    try {
                        List<Candle> candles = fetchIsYatirim(sym, "1Y");
                        if (candles.size() < 35) throw new Exception("Yeterli İş Yatırım verisi yok");
                        AnalysisEngine.enrichFromHistory(st, candles, strategy, scanBenchmark);
                        LearningEngine.harvestHistory(new LearningStore(context), sym, candles, strategy);
                        PredictionStore ps=new PredictionStore(context);
                        ps.evaluateHistory(context,sym,candles);
                        ps.observeAnalysis(st,candles);
                        synchronized (cache) { cache.put(sym + "|SCAN", new ArrayList<>(candles)); }
                    } catch (Exception ignored) {
                        st.analysisReady = false; st.signal = "BEKLE"; st.reason = "Tarama verisi alınamadı.";
                    }
                }
                int d = done.incrementAndGet();
                main.post(() -> listener.onScanProgress(d, total, st));
                if (d == total) { LearningEngine.learn(new LearningStore(context)); main.post(() -> listener.onScanFinished(total, total)); }
            });
        }
    }

    public interface BenchmarkListener { void onBenchmarkReady(List<Candle> benchmark, String source, String message); }

    /** Loads the BIST 100 benchmark (XU100) so stock signals can use market-regime and relative-strength filters. */
    public void loadBenchmark(String rangeKey, BenchmarkListener listener) {
        final String range = rangeKey == null ? "1Y" : rangeKey;
        final String key = "XU100|" + range;
        synchronized (cache) {
            List<Candle> cached = cache.get(key);
            if (cached != null && !cached.isEmpty()) {
                final List<Candle> copy = new ArrayList<>(cached);
                main.post(() -> listener.onBenchmarkReady(copy, "Önbellek", "BIST 100 geçmişi önbellekten hazır"));
                Long t = lastFetch.get(key);
                if (t != null && System.currentTimeMillis() - t < 5 * 60_000L) return;
            }
        }
        executor.execute(() -> {
            try {
                List<Candle> candles = fetchYahoo("XU100", range);
                if (candles.size() < 40 || !hasStrictFullOhlc(candles)) throw new Exception("BIST 100 geçmiş OHLCV eksik");
                synchronized (cache) { cache.put(key, new ArrayList<>(candles)); lastFetch.put(key, System.currentTimeMillis()); }
                final List<Candle> copy = new ArrayList<>(candles);
                main.post(() -> listener.onBenchmarkReady(copy, "Yahoo Finance • XU100", "BIST 100 benchmark güncellendi"));
            } catch (Exception e) {
                main.post(() -> listener.onBenchmarkReady(Collections.emptyList(), "", "BIST 100 benchmark alınamadı: " + e.getMessage()));
            }
        });
    }

    public List<Candle> cachedScan(String symbol){
        String sym=symbol==null?"":symbol.trim().toUpperCase(Locale.US);
        synchronized(cache){List<Candle> c=cache.get(sym+"|SCAN");return c==null?Collections.emptyList():new ArrayList<>(c);}
    }

    public List<Candle> cachedBenchmark(String rangeKey) {
        final String range = rangeKey == null ? "1Y" : rangeKey;
        synchronized (cache) {
            List<Candle> c = cache.get("XU100|" + range);
            return c == null ? Collections.emptyList() : new ArrayList<>(c);
        }
    }

    private static boolean hasStrictFullOhlc(List<Candle> bars) {
        if (bars == null || bars.isEmpty()) return false;
        int full=0;
        for (Candle c: bars) if (c != null && c.fullOhlc && valid(c.open) && valid(c.high) && valid(c.low) && valid(c.close)) full++;
        return full >= Math.max(40, (int)Math.ceil(bars.size()*0.92));
    }

    private void post(Listener listener, String symbol, String range, List<Candle> candles, String source, String msg) {
        final List<Candle> safe = new ArrayList<>(candles);
        main.post(() -> listener.onHistory(symbol, range, safe, source, msg));
    }

    private List<Candle> fetchYahoo(String symbol, String rangeKey) throws Exception {
        String range = yahooRange(rangeKey);
        String ticker = URLEncoder.encode(symbol + ".IS", "UTF-8");
        String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + ticker +
                "?range=" + range + "&interval=1d&events=div%2Csplits&includeAdjustedClose=true";
        String body = httpGet(url, "application/json,text/plain,*/*");
        JSONObject root = new JSONObject(new JSONTokener(body).nextValue().toString());
        JSONObject chart = root.optJSONObject("chart");
        if (chart == null) throw new Exception("Yahoo chart yok");
        JSONArray results = chart.optJSONArray("result");
        if (results == null || results.length() == 0) throw new Exception("Yahoo sonuç yok");
        JSONObject result = results.getJSONObject(0);
        JSONArray timestamps = result.optJSONArray("timestamp");
        JSONObject indicators = result.optJSONObject("indicators");
        if (timestamps == null || indicators == null) throw new Exception("Yahoo OHLCV eksik");
        JSONArray quotes = indicators.optJSONArray("quote");
        if (quotes == null || quotes.length() == 0) throw new Exception("Yahoo quote eksik");
        JSONObject q = quotes.getJSONObject(0);
        JSONArray opens = q.optJSONArray("open"), highs = q.optJSONArray("high"), lows = q.optJSONArray("low"), closes = q.optJSONArray("close"), volumes = q.optJSONArray("volume");
        if (closes == null) throw new Exception("Yahoo close eksik");

        ArrayList<Candle> out = new ArrayList<>();
        double previousClose = Double.NaN;
        for (int i = 0; i < timestamps.length() && i < closes.length(); i++) {
            long sec = timestamps.optLong(i, 0);
            if (sec <= 0) continue;
            double close = numberAt(closes, i);
            if (!valid(close)) continue;
            double open = numberAt(opens, i);
            double high = numberAt(highs, i);
            double low = numberAt(lows, i);
            // Deep stop/target analysis must never use fabricated OHLC.
            if (!valid(open) || !valid(high) || !valid(low)) {
                previousClose = close;
                continue;
            }
            double volume = numberAt(volumes, i);
            if (!valid(volume)) volume = 0;
            if (high < Math.max(open, close) || low > Math.min(open, close) || low <= 0) continue;
            out.add(new Candle(sec * 1000L, formatDate(sec * 1000L), open, high, low, close, volume, true));
            previousClose = close;
        }
        return cropRange(out, rangeKey);
    }

    private List<Candle> fetchIsYatirim(String symbol, String rangeKey) throws Exception {
        DateRange r = dateRange(rangeKey);
        String url = "https://www.isyatirim.com.tr/_layouts/15/Isyatirim.Website/Common/Data.aspx/HisseTekil?hisse=" +
                URLEncoder.encode(symbol, "UTF-8") + "&startdate=" + r.start + "&enddate=" + r.end + ".json";
        String body = httpGet(url, "application/json,text/plain,*/*");
        JSONObject root = new JSONObject(new JSONTokener(body).nextValue().toString());
        JSONArray values = root.optJSONArray("value");
        if (values == null) throw new Exception("İş Yatırım value yok");
        ArrayList<Candle> out = new ArrayList<>();
        double prev = Double.NaN;
        for (int i = 0; i < values.length(); i++) {
            JSONObject o = values.optJSONObject(i);
            if (o == null) continue;
            String ds = o.optString("HGDG_TARIH", "");
            Double close = parseNumber(o.opt("HGDG_KAPANIS"));
            if (close == null || close <= 0) continue;
            double c = close;
            double open = valid(prev) ? prev : c;
            double high = Math.max(open, c);
            double low = Math.min(open, c);
            double vol = valueNumber(o, "HGDG_HACIM");
            long time = parseDate(ds);
            if (time <= 0) time = System.currentTimeMillis() - (long)(values.length() - i) * 86400000L;
            out.add(new Candle(time, ds, open, high, low, c, Math.max(0, vol), false));
            prev = c;
        }
        Collections.sort(out, (a,b) -> Long.compare(a.time,b.time));
        return cropRange(out, rangeKey);
    }

    private static List<Candle> cropRange(List<Candle> src, String rangeKey) {
        if (src.isEmpty()) return src;
        long days;
        switch (rangeKey) {
            case "1A": days = 31; break;
            case "3A": days = 93; break;
            case "6A": days = 186; break;
            case "1Y": days = 370; break;
            case "3Y": days = 1100; break;
            default: days = 1850;
        }
        long cutoff = System.currentTimeMillis() - days * 86400000L;
        ArrayList<Candle> out = new ArrayList<>();
        for (Candle c : src) if (c.time >= cutoff) out.add(c);
        if (out.size() < 20 && src.size() > 20) return new ArrayList<>(src.subList(Math.max(0, src.size() - Math.min(src.size(), 20)), src.size()));
        return out;
    }

    private static String yahooRange(String key) {
        switch (key) {
            case "1A": return "1mo";
            case "3A": return "3mo";
            case "6A": return "6mo";
            case "1Y": return "1y";
            case "3Y": return "5y";
            default: return "5y";
        }
    }

    private static String httpGet(String urlText, String accept) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept", accept);
        c.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8");
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line; while ((line = r.readLine()) != null) sb.append(line); r.close();
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        return sb.toString();
    }

    private static double numberAt(JSONArray a, int i) {
        if (a == null || i >= a.length() || a.isNull(i)) return Double.NaN;
        Object v = a.opt(i);
        if (v instanceof Number) return ((Number)v).doubleValue();
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return Double.NaN; }
    }
    private static boolean valid(double d) { return !Double.isNaN(d) && !Double.isInfinite(d) && d > 0; }
    private static Double parseNumber(Object v) {
        if (v == null || v == JSONObject.NULL) return null;
        try { String s = String.valueOf(v).replace(".", "").replace(",", ".").replaceAll("[^0-9.\\-]", ""); return s.isEmpty() ? null : Double.parseDouble(s); } catch (Exception e) { return null; }
    }
    private static double valueNumber(JSONObject o, String k) { Double d = parseNumber(o.opt(k)); return d == null ? 0 : d; }
    private static long parseDate(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        String[] patterns = {"dd.MM.yyyy", "dd-MM-yyyy", "yyyy-MM-dd", "dd/MM/yyyy"};
        for (String p : patterns) try {
            SimpleDateFormat f = new SimpleDateFormat(p, Locale.US); f.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul")); return f.parse(s.trim()).getTime();
        } catch (Exception ignored) {}
        return 0;
    }
    private static String formatDate(long t) {
        SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy", Locale.US); f.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul")); return f.format(new Date(t));
    }
    private static class DateRange {
        String start, end;
        DateRange(String s, String e) { start = s; end = e; }
    }
    private static DateRange dateRange(String key) {
        long days;
        switch (key) { case "1A": days=45; break; case "3A":days=110;break; case "6A":days=220;break; case "1Y":days=400;break; case "3Y":days=1120;break; default:days=1900; }
        long now=System.currentTimeMillis(), start=now-days*86400000L;
        SimpleDateFormat f=new SimpleDateFormat("dd-MM-yyyy",Locale.US); f.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul"));
        return new DateRange(f.format(new Date(start)),f.format(new Date(now)));
    }
}
