package com.bistaitrader;

import org.json.*;
import java.util.*;

/**
 * Controlled self-learning layer. It learns bounded feature weights from historical
 * signal outcomes, compares the adaptive profile with neutral weights, and only
 * activates changes that pass minimum evidence and improvement gates.
 */
public final class LearningEngine {
    private LearningEngine(){}
    public static final class Report {
        public int samples, wins, losses, eligible, improved;
        public double baselineWinRate, adaptiveWinRate, baselineExpectancy, adaptiveExpectancy;
        public final LinkedHashMap<String,Double> weights=new LinkedHashMap<>();
        public final LinkedHashMap<String,String> featureStats=new LinkedHashMap<>();
        public String status="Bekleniyor";
        public String lastUpdate="";
        public int predictionOpen, predictionClosed, predictionWins, predictionLosses;
        public final LinkedHashMap<String,Integer> lossReasons=new LinkedHashMap<>();
    }
    private static final String[] KEYS={"rsi","macd","ema","volume","trend","support","momentum"};
    private static final double MIN_WEIGHT=.75, MAX_WEIGHT=1.25;
    private static final int MIN_FEATURE_SAMPLES=20;

    public static Report learn(LearningStore store){
        Report r=new Report(); JSONArray a=store.learningSamples();r.samples=a.length();
        JSONObject old=store.profile();
        for(String k:KEYS){double w=old.optDouble(k,1.0);r.weights.put(k,clamp(w,MIN_WEIGHT,MAX_WEIGHT));}
        JSONArray ps=store.predictionSamples();
        for(int i=0;i<ps.length();i++){JSONObject o=ps.optJSONObject(i);if(o==null)continue; if(o.has("pnl")){double v=o.optDouble("pnl",0);if(v>0)r.predictionWins++;else if(v<0)r.predictionLosses++;}String reason=o.optString("reason","");if(o.has("pnl")&&o.optDouble("pnl",0)<0&&reason.length()>0)r.lossReasons.put(reason,r.lossReasons.containsKey(reason)?r.lossReasons.get(reason)+1:1);}
        r.predictionClosed=r.predictionWins+r.predictionLosses;
        if(a.length()<MIN_FEATURE_SAMPLES){r.status="Öğrenmek için en az 20 sonuç bekleniyor.";return r;}
        double baseP=0, adaptP=0;int baseW=0,adaptW=0, n=0, adaptiveN=0;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            double pnl=o.optDouble("pnl",0);boolean win=o.optBoolean("win",pnl>0);n++;baseP+=pnl;if(win)baseW++;
            double score=0;for(int j=0;j<KEYS.length;j++)if(o.optBoolean(KEYS[j],false))score+=r.weights.get(KEYS[j]);
            // Shadow candidate: require roughly the same seven-condition strength,
            // but allow learned weights to promote/demote marginal setups.
            boolean selected=score>=4.75;
            if(selected){adaptiveN++;adaptP+=pnl;if(win)adaptW++;}
        }
        r.eligible=n;r.wins=baseW;r.losses=n-baseW;r.baselineWinRate=n==0?0:baseW*100.0/n;r.adaptiveWinRate=adaptiveN==0?0:adaptW*100.0/adaptiveN;
        r.baselineExpectancy=n==0?0:baseP/n;r.adaptiveExpectancy=adaptiveN==0?0:adaptP/adaptiveN;

        // Re-estimate each feature from outcomes, then smooth and bound it.
        for(int j=0;j<KEYS.length;j++){
            String key=KEYS[j];int cnt=0,wins=0;double sum=0;
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!o.optBoolean(key,false))continue;cnt++;if(o.optBoolean("win",false))wins++;sum+=o.optDouble("pnl",0);}
            if(cnt>=MIN_FEATURE_SAMPLES){
                double wr=wins*1.0/cnt;double quality=0.75+(wr*0.50);double oldW=r.weights.get(key);double nw=clamp(oldW*0.70+quality*0.30,MIN_WEIGHT,MAX_WEIGHT);r.weights.put(key,nw);r.featureStats.put(key,String.format(Locale.US,"%d örnek • %s • ağırlık %.2f",cnt,percent(wr),nw));
            } else r.featureStats.put(key,cnt+" örnek • yeterli kanıt yok");
        }
        // Safety gate: don't activate if the shadow profile is not better on both measures.
        if(adaptiveN>=MIN_FEATURE_SAMPLES && r.adaptiveExpectancy>=r.baselineExpectancy && r.adaptiveWinRate>=r.baselineWinRate){
            JSONObject p=new JSONObject();try{for(String k:KEYS)p.put(k,r.weights.get(k));p.put("version",old.optInt("version",0)+1);p.put("samples",n);p.put("updated",System.currentTimeMillis());store.setProfile(p);store.setLastRun(System.currentTimeMillis());store.setActive(true);}catch(Exception ignored){}
            r.status="Yeni profil doğrulandı ve aktif edildi.";r.improved=1;
        }else{
            r.status="Yeni profil güvenlik testini geçmedi; mevcut profil korundu.";store.setLastRun(System.currentTimeMillis());
        }
        r.lastUpdate=new Date().toString();return r;
    }
    /** Convert historical signals into labeled examples using the existing stop/target plan.
     * Stop is conservatively checked before target when both occur in one daily candle. */
    public static int harvestHistory(LearningStore store,String symbol,List<Candle> bars,String strategy){
        if(store==null||bars==null||bars.size()<AnalysisEngine.MIN_DEEP_BARS+12)return 0;
        ArrayList<Candle> clean=new ArrayList<>();for(Candle c:bars)if(c!=null)clean.add(c);
        clean.sort((a,b)->Long.compare(a.time,b.time));
        int added=0;
        for(int i=AnalysisEngine.MIN_DEEP_BARS-1;i<clean.size()-10;i++){
            AnalysisEngine.Decision d=AnalysisEngine.evaluateAt(clean,i,strategy);
            if(!"AL".equals(d.signal)||d.stop<=0||d.target1<=0)continue;
            Candle sig=clean.get(i);if(store.hasSample(symbol,sig.time))continue;
            boolean win=false,done=false;double pnl=0;
            for(int j=i+1;j<Math.min(clean.size(),i+11);j++){
                Candle b=clean.get(j);
                if(b.open<=d.stop){pnl=(b.open/sig.close-1)*100;done=true;break;}
                if(b.low<=d.stop){pnl=(d.stop/sig.close-1)*100;done=true;break;}
                if(b.high>=d.target1){pnl=(d.target1/sig.close-1)*100;win=true;done=true;break;}
            }
            if(!done){Candle b=clean.get(Math.min(clean.size()-1,i+10));pnl=(b.close/sig.close-1)*100;win=pnl>0;}
            Stock snap=new Stock();snap.symbol=symbol;snap.price=sig.close;snap.rsiOk=d.rsiOk;snap.macdOk=d.macdOk;snap.emaOk=d.emaOk;snap.volumeOk=d.volumeOk;snap.trendOk=d.trendOk;snap.supportOk=d.supportOk;snap.momentumOk=d.momentumOk;snap.score=d.score;snap.conditionsMet=d.met;snap.setupType=d.setupType;snap.adx=d.adx;snap.volumeRatio=d.volumeRatio;snap.atrPct=d.atrPct;
            store.recordSample(symbol,sig.time,"AL",snap,win,pnl);added++;
        }
        return added;
    }

    public static double weight(LearningStore s,String key){if(s==null||!s.active())return 1.0;return clamp(s.profile().optDouble(key,1.0),MIN_WEIGHT,MAX_WEIGHT);}
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    private static String percent(double x){return String.format(Locale.US,"%.1f%%",x*100.0);}
}
