BIST AI Trader V5.1 — GitHub yükleme paketi

1) Bu ZIP dosyasını bilgisayarda çıkar.
2) GitHub repo köküne şu iki şeyi yükle:
   - BIST_AI_Trader_V5_ALL_FEATURES_SIGNAL_BALANCED_FIX.zip
   - .github/workflows/BIST_AI_Trader_V5_ALL_FEATURES_WORKFLOW.yml
3) Commit/push yap.
4) GitHub > Actions > “Build BIST AI Trader v5.1 - Signal Balance Fix” > Run workflow.
5) İş bitince Artifacts bölümünden “BIST_AI_Trader_v5_1_signal_balance_fix_debug” dosyasını indir.

Android Studio gerekmez. Java 17 + Android SDK 35 + Gradle 8.9 workflow içinde hazırlanır.
