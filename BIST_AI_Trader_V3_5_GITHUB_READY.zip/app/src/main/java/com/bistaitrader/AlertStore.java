package com.bistaitrader;

import android.content.Context;
import org.json.*;
import java.util.*;

public class AlertStore {
    private final android.content.SharedPreferences sp;
    public AlertStore(Context c){sp=c.getApplicationContext().getSharedPreferences("price_alerts",Context.MODE_PRIVATE);}
    private String key(String sym){return "a_"+sym;}
    public double get(String sym){return Double.longBitsToDouble(sp.getLong(key(sym),Double.doubleToLongBits(0)));}
    public void set(String sym,double price){sp.edit().putLong(key(sym),Double.doubleToLongBits(price)).apply();}
    public void clear(String sym){sp.edit().remove(key(sym)).apply();}
    public boolean checkAndClear(String sym,double oldPrice,double newPrice){
        double target=get(sym); if(target<=0||newPrice<=0)return false;
        boolean crossed=(oldPrice<target&&newPrice>=target)||(oldPrice>target&&newPrice<=target);
        if(crossed){clear(sym);return true;}return false;
    }
}
