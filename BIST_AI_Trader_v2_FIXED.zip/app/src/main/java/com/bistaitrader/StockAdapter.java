package com.bistaitrader;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class StockAdapter extends BaseAdapter {
    public interface Click { void onClick(Stock s); }
    private final Context context; private final Click click; private List<Stock> items=new ArrayList<>();
    private final int blue=Color.rgb(79,140,255), text=Color.rgb(244,247,251), muted=Color.rgb(145,164,186), green=Color.rgb(48,209,88), yellow=Color.rgb(255,204,0), red=Color.rgb(255,69,58);
    public StockAdapter(Context c, Click cl){context=c;click=cl;}
    public void setItems(List<Stock> list){items=new ArrayList<>(list);notifyDataSetChanged();}
    @Override public int getCount(){return items.size();}
    @Override public Object getItem(int p){return items.get(p);} @Override public long getItemId(int p){return p;}
    private int dp(float x){return (int)(x*context.getResources().getDisplayMetrics().density+0.5f);}
    private TextView tv(String s,float sp,int col){TextView t=new TextView(context);t.setText(s);t.setTextSize(sp);t.setTextColor(col);return t;}
    private GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),Color.rgb(34,51,77));return g;}
    @Override public View getView(int pos,View convert,ViewGroup parent){
        Stock s=items.get(pos);
        LinearLayout outer=new LinearLayout(context); outer.setOrientation(LinearLayout.VERTICAL); outer.setPadding(dp(14),dp(12),dp(14),dp(12)); outer.setBackground(bg(Color.rgb(15,27,45),16));
        TextView[] row=new TextView[3];
        LinearLayout top=new LinearLayout(context); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left=new LinearLayout(context); left.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv(s.symbol,17,text); a.setTypeface(null,android.graphics.Typeface.BOLD);
        TextView b=tv(s.name,11,muted); b.setMaxLines(1); left.addView(a); left.addView(b);
        TextView mid=tv(String.format(Locale.US,"%.2f ₺",s.price),16,text); mid.setGravity(Gravity.CENTER); mid.setTypeface(null,android.graphics.Typeface.BOLD);
        TextView ch=tv(String.format(Locale.US,"%+.2f%%",s.changePct),13,s.changePct>=0?green:red); ch.setGravity(Gravity.CENTER);
        LinearLayout vals=new LinearLayout(context); vals.setOrientation(LinearLayout.VERTICAL); vals.setGravity(Gravity.CENTER_HORIZONTAL); vals.addView(mid); vals.addView(ch);
        TextView sig=tv(s.signal,12,text); sig.setGravity(Gravity.CENTER); sig.setPadding(dp(9),dp(5),dp(9),dp(5)); sig.setTypeface(null,android.graphics.Typeface.BOLD); sig.setBackground(bg(s.signal.equals("AL")?green:s.signal.equals("SAT")?red:yellow,20));
        if(s.signal.equals("AL")) sig.setTextColor(Color.BLACK); else sig.setTextColor(Color.BLACK);
        top.addView(left,new LinearLayout.LayoutParams(0,-2,1)); top.addView(vals,new LinearLayout.LayoutParams(dp(105),-2)); top.addView(sig,new LinearLayout.LayoutParams(dp(72),dp(34)));
        outer.addView(top);
        LinearLayout bottom=new LinearLayout(context); bottom.setPadding(0,dp(9),0,0);
        String risk=s.risk; TextView r=tv("● "+risk,11,risk.startsWith("Düşük")?green:risk.startsWith("Yüksek")?red:yellow);
        TextView sc=tv("Skor "+String.format(Locale.US,"%.0f",s.score)+"/100",11,muted); sc.setGravity(Gravity.RIGHT);
        bottom.addView(r,new LinearLayout.LayoutParams(0,-2,1)); bottom.addView(sc,new LinearLayout.LayoutParams(0,-2,1)); outer.addView(bottom);
        outer.setOnClickListener(v->click.onClick(s));
        AbsListView.LayoutParams lp=new AbsListView.LayoutParams(-1,dp(100)); outer.setLayoutParams(lp); return outer;
    }
}
