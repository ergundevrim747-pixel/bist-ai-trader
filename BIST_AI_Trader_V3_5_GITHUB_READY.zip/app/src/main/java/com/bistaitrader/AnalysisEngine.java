package com.bistaitrader;

import java.util.*;

/**
 * Research-driven, deterministic technical-analysis engine.
 *
 * The engine deliberately combines several independent lenses instead of trusting
 * one indicator: higher-timeframe trend/stage, daily setup, momentum, volume/OBV,
 * market regime, relative strength, volatility, candle quality and structural
 * support/resistance.  Stop/target levels are generated only when full OHLCV is
 * available and reward/risk is adequate.  "confidence" is a model score, not a
 * probability and never a guarantee of future performance.
 */
public final class AnalysisEngine {
    private static LearningStore learningStore;
    private AnalysisEngine() {}
    public static void setLearningStore(LearningStore s){ learningStore=s; }

    public static final int TOTAL_CONDITIONS = 7;
    public static final int MIN_DEEP_BARS = 160;
    public static final double MAX_INITIAL_STOP_PCT = 7.5;
    public static final double MIN_INITIAL_STOP_PCT = 0.80;
    public static final double MIN_RR_TARGET1 = 2.00;
    public static final double MIN_RR_TARGET2 = 2.80;
    public static final double MAX_GAP_ENTRY_PCT = 4.0;

    public static final class Decision {
        public boolean rsiOk, macdOk, emaOk, volumeOk, trendOk, supportOk, momentumOk;
        public int met;
        public double score;
        public double confidence;
        public double adx;
        public double diPlus, diMinus;
        public double obvSlopePct;
        public double dailyGapPct;
        public double volumeRatio;
        public double atrPct;
        public double relativeStrengthPct;
        public double stopPct, rr1, rr2, riskPerShare;
        public int suggestedQty;
        public double suggestedPositionPct;
        public String signal = "BEKLE";
        public String risk = "Orta Risk";
        public String entryLowLabel = "";
        public double entryLow, entryHigh, stop, target1, target2, trailingStop;
        public String setupType = "Kurulum yok";
        public String stage = "Belirsiz";
        public String marketRegime = "Belirsiz";
        public String reason = "Yeterli geçmiş veri bekleniyor.";
        public String management = "";
        public String safety = "";
        public boolean dataQualityOk;
        public boolean marketOk;
        public boolean relativeStrengthOk;
        public boolean volumeSetupOk;
        public boolean volatilityOk;
        public boolean overextended, volatilityShock, distributionFlag;
        public boolean breakoutConfirmed;
        public boolean pullbackConfirmed;
        public boolean contractionConfirmed;
        public boolean candleConfirmed;
        public boolean adxConfirmed;
        public boolean obvConfirmed;
        public boolean entryZoneOk;
        public boolean hardGateOk;
    }

    public static void enrichLiveQuote(Stock s) {
        if (s == null) return;
        s.analysisReady = false;
        s.signal = "BEKLE";
        s.score = -1;
        s.confidence = 0;
        s.conditionsMet = 0;
        s.conditionsTotal = TOTAL_CONDITIONS;
        s.reason = "Geçmiş tam OHLCV verisi yüklenmeden teknik sinyal ve stop/hedef üretilmez.";
        s.updatedAt = System.currentTimeMillis();
    }

    public static void enrichFromHistory(Stock s, List<Candle> bars) {
        enrichFromHistory(s, bars, "Dengeli", null);
    }

    public static void enrichFromHistory(Stock s, List<Candle> bars, String strategy) {
        enrichFromHistory(s, bars, strategy, null);
    }

    public static void enrichFromHistory(Stock s, List<Candle> bars, String strategy, List<Candle> benchmark) {
        if (s == null) return;
        ArrayList<Candle> clean = cleanBars(bars);
        if (clean.size() < MIN_DEEP_BARS) {
            s.analysisReady = false;
            s.signal = "BEKLE";
            s.reason = "Derin analiz için en az " + MIN_DEEP_BARS + " geçerli günlük mum gerekli.";
            return;
        }
        if (!hasFullOhlcv(clean)) {
            s.analysisReady = false;
            s.signal = "BEKLE";
            s.reason = "Tam OHLCV bulunamadı. Eksik OHLC ile stop/hedef üretilmedi.";
            return;
        }

        Decision d = evaluateAt(clean, clean.size() - 1, strategy, benchmark);
        Candle last = clean.get(clean.size() - 1);
        Candle prev = clean.get(clean.size() - 2);
        s.price = last.close;
        s.previousClose = prev.close;
        s.changePct = prev.close > 0 ? (last.close / prev.close - 1) * 100 : 0;
        s.volume = last.volume;

        int n = clean.size();
        double[] close = new double[n], high = new double[n], low = new double[n], volume = new double[n];
        for (int i = 0; i < n; i++) {
            Candle c = clean.get(i);
            close[i] = c.close; high[i] = c.high; low[i] = c.low; volume[i] = c.volume;
        }
        double[] ema20 = emaSeries(close, 20);
        double[] ema50 = emaSeries(close, 50);
        double[] ema200 = emaSeries(close, 200);
        s.ema20 = ema20[n-1];
        s.ema50 = ema50[n-1];
        s.ema200 = ema200[n-1];
        s.rsi = rsiLast(close, 14);
        MacdSeries ms = macdSeries(close, 12, 26, 9);
        s.macd = ms.macd[n-1]; s.macdSignal = ms.signal[n-1];
        s.atrPct = atrPctLast(close, high, low, 14);
        s.momentumPct = pctAgo(close, Math.min(20, n-1));
        s.avgVolume = averageTail(volume, Math.min(20, n));
        s.volumeRatio = s.avgVolume > 0 ? last.volume / s.avgVolume : 0;
        double sd = stddevLast(close, 20), mean = averageTail(close, Math.min(20, n));
        s.bollingerUpper = mean + 2 * sd;
        s.bollingerLower = Math.max(0, mean - 2 * sd);
        s.support1 = rollingLowExcludingLast(low, Math.min(20, n));
        s.support2 = rollingLowExcludingLast(low, Math.min(60, n));
        s.resistance1 = rollingHighExcludingLast(high, Math.min(20, n));
        s.resistance2 = rollingHighExcludingLast(high, Math.min(60, n));
        s.trend = s.price > s.ema20 && s.ema20 > s.ema50 && slopePercent(ema20,10) > 0 ? "Yukarı" :
                s.price < s.ema20 && s.ema20 < s.ema50 && slopePercent(ema20,10) < 0 ? "Aşağı" : "Yatay/Karışık";

        s.score = d.score;
        s.confidence = d.confidence;
        s.signal = d.signal;
        s.risk = d.risk;
        s.stopPrice = d.stop;
        s.targetPrice = d.target1;
        s.entryLow = d.entryLow;
        s.entryHigh = d.entryHigh;
        s.targetPrice2 = d.target2;
        s.trailingStop = d.trailingStop;
        s.conditionsMet = d.met;
        s.conditionsTotal = TOTAL_CONDITIONS;
        s.rsiOk = d.rsiOk; s.macdOk = d.macdOk; s.emaOk = d.emaOk; s.volumeOk = d.volumeOk;
        s.trendOk = d.trendOk; s.supportOk = d.supportOk; s.momentumOk = d.momentumOk;
        s.relativeStrengthPct = d.relativeStrengthPct;
        s.adx=d.adx; s.diPlus=d.diPlus; s.diMinus=d.diMinus; s.obvSlopePct=d.obvSlopePct; s.dailyGapPct=d.dailyGapPct;
        s.contractionConfirmed=d.contractionConfirmed; s.candleConfirmed=d.candleConfirmed; s.adxConfirmed=d.adxConfirmed; s.obvConfirmed=d.obvConfirmed; s.entryZoneOk=d.entryZoneOk;
        s.stopPct = d.stopPct; s.rr1 = d.rr1; s.rr2 = d.rr2;
        s.riskPerShare = d.riskPerShare; s.suggestedQty = d.suggestedQty; s.suggestedPositionPct = d.suggestedPositionPct;
        s.setupType = d.setupType; s.stage = d.stage; s.marketRegime = d.marketRegime;
        s.dataQualityOk = d.dataQualityOk; s.marketOk = d.marketOk; s.relativeStrengthOk = d.relativeStrengthOk;
        s.volumeSetupOk = d.volumeSetupOk; s.volatilityOk = d.volatilityOk; s.overextended = d.overextended; s.volatilityShock = d.volatilityShock; s.distributionFlag = d.distributionFlag;
        s.breakoutConfirmed = d.breakoutConfirmed; s.pullbackConfirmed = d.pullbackConfirmed; s.hardGateOk = d.hardGateOk;
        s.reason = d.reason; s.management = d.management; s.safety = d.safety;
        s.updatedAt = System.currentTimeMillis();
        s.analysisReady = true;
    }

    public static Decision evaluateAt(List<Candle> input, int idx, String strategy) {
        return evaluateAt(input, idx, strategy, null);
    }

    public static Decision evaluateAt(List<Candle> input, int idx, String strategy, List<Candle> benchmarkInput) {
        ArrayList<Candle> bars = cleanBars(input);
        Decision d = new Decision();
        if (idx < MIN_DEEP_BARS - 1 || idx >= bars.size()) {
            d.reason = "Derin analiz için yeterli geçmiş veri yok.";
            return d;
        }
        int n = idx + 1;
        ArrayList<Candle> benchmark = cleanBars(benchmarkInput);
        boolean benchmarkUsable = benchmark.size() >= MIN_DEEP_BARS && hasFullOhlcv(benchmark);
        List<Candle> prefix = bars.subList(0, n);
        if (!hasFullOhlcv(prefix)) {
            d.reason = "Eksik OHLCV nedeniyle güvenli işlem planı üretilemedi.";
            return d;
        }

        double[] close = new double[n], high = new double[n], low = new double[n], volume = new double[n];
        for (int i=0;i<n;i++) { Candle c=bars.get(i); close[i]=c.close;high[i]=c.high;low[i]=c.low;volume[i]=c.volume; }
        double price=close[n-1], prevClose=close[n-2];
        double[] ema20=emaSeries(close,20), ema50=emaSeries(close,50), ema200=emaSeries(close,200);
        double ema20Now=ema20[n-1], ema50Now=ema50[n-1], ema200Now=ema200[n-1];
        double rsi=rsiLast(close,14);
        MacdSeries macd=macdSeries(close,12,26,9);
        double macdNow=macd.macd[n-1], macdSig=macd.signal[n-1], histNow=macd.hist[n-1];
        double atr=atrLast(close,high,low,14), atrPct=price>0?atr/price*100:0;
        double atr50=atrLast(close,high,low,50), atr20=atrLast(close,high,low,20);
        double momentum20=pctAgo(close,Math.min(20,n-1));
        double momentum5=pctAgo(close,Math.min(5,n-1));
        double avgVol20=averageTail(volume,Math.min(20,n)), volRatio=avgVol20>0?volume[n-1]/avgVol20:0;
        d.volumeRatio=volRatio;
        double support20=rollingLowExcludingLast(low,Math.min(20,n));
        double support60=rollingLowExcludingLast(low,Math.min(60,n));
        double resistance20=rollingHighExcludingLast(high,Math.min(20,n));
        double resistance60=rollingHighExcludingLast(high,Math.min(60,n));
        double swingLow10=rollingLowExcludingLast(low,Math.min(10,n));
        double swingHigh10=rollingHighExcludingLast(high,Math.min(10,n));

        boolean ema20Rising=slopePercent(ema20,10)>0.15;
        boolean ema50Rising=slopePercent(ema50,15)>0;
        boolean ema50Falling=slopePercent(ema50,15)<0;
        boolean ema200Rising=slopePercent(ema200,30)>0;
        boolean macdBull=macdNow>macdSig && histNow>=macd.hist[Math.max(0,n-2)];
        boolean macdBear=macdNow<macdSig && histNow<=macd.hist[Math.max(0,n-2)];
        boolean upTrend=price>ema20Now && ema20Now>ema50Now && ema50Rising;
        boolean downTrend=price<ema20Now && ema20Now<ema50Now && ema50Falling;

        WeeklyState weekly=weeklyState(prefix);
        d.stage=weekly.stage;
        d.marketRegime=benchmarkUsable?weeklyMarketState(benchmark,bars.get(n-1).time):"Piyasa doğrulaması yok";
        d.marketOk=!benchmarkUsable || !"Riskli".equals(d.marketRegime);
        d.relativeStrengthPct=benchmarkUsable?alignedRelativeStrength(bars,benchmark,60):0;
        // Relative strength is a leadership filter, but a small temporary lag versus the benchmark
        // should not automatically reject a technically strong setup. A modest -1% buffer reduces
        // over-filtering while still blocking meaningful underperformance.
        d.relativeStrengthOk=!benchmarkUsable || d.relativeStrengthPct>-1.0;

        ADX adx=adxLast(close,high,low,14);
        d.adx=adx.adx; d.diPlus=adx.diPlus; d.diMinus=adx.diMinus;
        // ADX lags a fresh breakout. Accept either a developed directional trend or a
        // very strong price/volume/OBV breakout that can precede a rising ADX.
        d.adxConfirmed=adx.adx>=16 && adx.diPlus>adx.diMinus;
        d.obvSlopePct=obvSlopePct(close,volume,20);
        d.obvConfirmed=d.obvSlopePct>0;

        boolean contraction=volatilityContraction(close,high,low);
        d.contractionConfirmed=contraction;
        double vol50=averageTail(volume,Math.min(50,n));
        boolean volumeExpansion=vol50>0 && volRatio>=1.25 && volume[n-1]>=vol50*1.10;
        boolean closeNearHigh=candleCloseLocation(bars.get(n-1))>=0.65;
        boolean bullishCandle=isBullishCandle(bars.get(n-1));
        d.candleConfirmed=bullishCandle && closeNearHigh;
        boolean distribution=price<prevClose && bars.get(n-1).close<=bars.get(n-1).open
                && volRatio>=1.50 && candleCloseLocation(bars.get(n-1))<=0.45 && price<ema20Now;
        d.distributionFlag=distribution;

        boolean breakoutStrengthOk=d.adxConfirmed || (volRatio>=1.80 && d.obvConfirmed && adx.diPlus>adx.diMinus);
        boolean breakout=price>resistance20+atr*0.10 && closeNearHigh && volumeExpansion && breakoutStrengthOk && (d.obvConfirmed || volRatio>=1.50);
        boolean breakoutStrong=breakout && volRatio>=1.50 && d.adx>=22;
        boolean pullbackNear=distance(price,ema20Now)<=atr*0.90 || distance(price,support20)<=atr*0.90;
        boolean pullback=upTrend && pullbackNear && bullishCandle && rsi>=40 && rsi<=68 && momentum5>-2.5 && d.adxConfirmed;
        boolean contractionBreak=contraction && price>resistance20 && closeNearHigh && volumeExpansion;
        boolean setupLong=breakout || pullback || contractionBreak;
        d.breakoutConfirmed=breakout || contractionBreak;
        d.pullbackConfirmed=pullback;
        d.volumeSetupOk=breakout || contractionBreak ? volRatio>=1.25 : volRatio>=0.90;

        double dailyGapPct=prevClose>0?(bars.get(n-1).open/prevClose-1)*100:0;
        d.dailyGapPct=dailyGapPct;
        d.overextended=price>ema20Now+atr*2.10 || (d.breakoutConfirmed && price>resistance20+atr*1.15) || dailyGapPct>MAX_GAP_ENTRY_PCT;
        if (Math.abs(dailyGapPct)>MAX_GAP_ENTRY_PCT) d.overextended=true;

        boolean rsiBull=(rsi>=48&&rsi<=72) || (pullback&&rsi>=40&&rsi<=65);
        boolean rsiBear=rsi<=48;
        boolean emaBull=ema20Now>ema50Now && price>ema200Now*0.98;
        boolean emaBear=ema20Now<ema50Now && price<ema200Now*1.02;
        boolean volBull=d.volumeSetupOk;
        boolean volBear=volRatio>=1.20 && price<prevClose && bars.get(n-1).close<=bars.get(n-1).open;
        boolean trendBull=upTrend && price>ema200Now && ema200Rising;
        boolean trendBear=downTrend && price<ema200Now;
        boolean supportBull=d.breakoutConfirmed || (price>support20 && distance(price,support20)<=Math.max(atr*1.7,price*0.035));
        boolean resistanceBear=price<resistance20 && distance(resistance20,price)<=Math.max(atr*1.7,price*0.035);
        boolean momentumBull=momentum20>0 && momentum5>-2.5;
        boolean momentumBear=momentum20<0 && momentum5<1.0;
        d.rsiOk=rsiBull;d.macdOk=macdBull;d.emaOk=emaBull;d.volumeOk=volBull;d.trendOk=trendBull;d.supportOk=supportBull;d.momentumOk=momentumBull;
        int bull=bool(rsiBull)+bool(macdBull)+bool(emaBull)+bool(volBull)+bool(trendBull)+bool(supportBull)+bool(momentumBull);
        int bear=bool(rsiBear)+bool(macdBear)+bool(emaBear)+bool(volBear)+bool(trendBear)+bool(resistanceBear)+bool(momentumBear);

        d.setupType=breakoutStrong?"Hacimli direnç kırılımı":d.breakoutConfirmed?"Direnç kırılımı":pullback?"Trend içi geri çekilme":contraction?"Sıkışma sonrası kırılım":"Kurulum yok";
        d.atrPct=atrPct;
        d.volatilityShock=atr>0 && atr50>0 && atr>Math.max(atr50*1.75,atr20*1.35);
        d.volatilityOk=atr>0 && atr50>0 && !d.volatilityShock && atr<=Math.max(atr50*1.60,atr20*1.20);
        buildLongPlan(d,prefix,price,atr,support20,support60,resistance20,resistance60,swingLow10,swingHigh10,weekly,dailyGapPct);
        d.dataQualityOk=true;
        d.risk=riskFor(atrPct,volRatio,d.marketRegime);

        double wb = bool(rsiBull)*LearningEngine.weight(learningStore,"rsi") + bool(macdBull)*LearningEngine.weight(learningStore,"macd")
                + bool(emaBull)*LearningEngine.weight(learningStore,"ema") + bool(volBull)*LearningEngine.weight(learningStore,"volume")
                + bool(trendBull)*LearningEngine.weight(learningStore,"trend") + bool(supportBull)*LearningEngine.weight(learningStore,"support")
                + bool(momentumBull)*LearningEngine.weight(learningStore,"momentum");
        double wr = bool(rsiBear)*LearningEngine.weight(learningStore,"rsi") + bool(macdBear)*LearningEngine.weight(learningStore,"macd")
                + bool(emaBear)*LearningEngine.weight(learningStore,"ema") + bool(volBear)*LearningEngine.weight(learningStore,"volume")
                + bool(trendBear)*LearningEngine.weight(learningStore,"trend") + bool(resistanceBear)*LearningEngine.weight(learningStore,"support")
                + bool(momentumBear)*LearningEngine.weight(learningStore,"momentum");
        double setupQuality=(d.setupType.startsWith("Hacimli")?12:d.setupType.startsWith("Direnç")?9:d.setupType.startsWith("Trend")?8:d.setupType.startsWith("Sıkışma")?7:0);
        double confidence=40 + wb*5 + setupQuality + (d.relativeStrengthOk?5:0) + (d.marketOk?4:-8) + (d.adxConfirmed?5:0)
                + (breakoutStrengthOk?3:0) + (d.obvConfirmed?3:0) + (d.contractionConfirmed?2:0)
                - (d.overextended?15:0) - (d.volatilityShock?10:0) - (d.rr1<MIN_RR_TARGET1?12:0)
                - (d.distributionFlag?8:0);
        if (adx.adx>35 && rsi>75) confidence-=6;
        confidence += (wb-wr)*1.5;
        d.confidence=clamp(confidence,0,100);
        d.score=d.confidence;

        String mode=strategy==null?"Dengeli":strategy;
        double threshold=mode.equals("Momentum")?76:mode.equals("Trend")?74:mode.equals("Kısa Vadeli")?73:74;
        boolean strongerMarketRequirement="Nötr".equals(d.marketRegime) && bull<6;
        boolean leadershipGate=d.relativeStrengthOk || (breakoutStrong && d.relativeStrengthPct>-4.0);
        boolean longGate=setupLong && !d.overextended && !d.distributionFlag && d.marketOk && leadershipGate && d.volumeSetupOk && d.volatilityOk
                && d.hardGateOk && d.entryZoneOk && !strongerMarketRequirement && d.rr1>=MIN_RR_TARGET1
                && d.stopPct>=MIN_INITIAL_STOP_PCT && d.stopPct<=MAX_INITIAL_STOP_PCT;
        boolean longSignal=bull>=5 && bull>=bear+2 && d.confidence>=threshold && longGate;
        boolean bearSignal=(bear>=5 && bear>=bull+2 && (downTrend||"Stage 4".equals(weekly.stage)||macdBear) && d.confidence<=34)
                || (d.distributionFlag && macdBear && price<ema20Now && (d.relativeStrengthPct<0 || !benchmarkUsable) && bear>=4);
        if(longSignal)d.signal="AL"; else if(bearSignal)d.signal="SAT"; else d.signal="BEKLE";
        d.met="SAT".equals(d.signal)?bear:bull;
        d.management=managementText(d.signal,d.setupType);
        d.reason=buildReason(d,bull,bear);
        d.safety=buildSafety(d);
        return d;
    }

    private static void buildLongPlan(Decision d,List<Candle> bars,double price,double atr,double support20,double support60,
                                      double resistance20,double resistance60,double swingLow10,double swingHigh10,
                                      WeeklyState weekly,double gapPct){
        if(atr<=0||price<=0){d.hardGateOk=false;return;}
        boolean breakout=d.breakoutConfirmed;
        double entryLow,entryHigh;
        if(breakout){
            entryLow=resistance20+atr*0.03;
            entryHigh=resistance20+atr*0.32;
        }else if(d.pullbackConfirmed){
            double center=emaLast(bars,20);
            entryLow=Math.max(support20,center-atr*0.40);
            entryHigh=Math.min(center+atr*0.40,price+atr*0.15);
        }else{
            double center=emaLast(bars,20);
            entryLow=Math.max(support20,center-atr*0.40);
            entryHigh=center+atr*0.40;
        }
        if(entryHigh<entryLow){double x=entryLow;entryLow=entryHigh;entryHigh=x;}
        d.entryLow=Math.max(0.01,entryLow);d.entryHigh=Math.max(d.entryLow,entryHigh);
        double entry=(d.entryLow+d.entryHigh)/2.0;
        // Never chase a signal far beyond its intended setup zone.
        double maxAllowed=d.entryHigh + atr*0.45;
        d.entryZoneOk=price>=d.entryLow-atr*0.50 && price<=maxAllowed;
        if (gapPct>MAX_GAP_ENTRY_PCT) d.entryZoneOk=false;

        double structureStop;
        if(breakout) structureStop=Math.min(swingLow10-atr*0.15,resistance20-atr*0.55);
        else structureStop=Math.min(swingLow10-atr*0.20,support20-atr*0.20);
        double atrStop=entry-atr*(weekly.stage.equals("Stage 2")?1.20:1.30);
        double stop=Math.min(structureStop,atrStop);
        if(stop<=0||stop>=entry) stop=Math.max(0.01,entry-atr*1.35);
        d.stop=stop;
        d.riskPerShare=Math.max(0.01,entry-stop);
        d.stopPct=d.riskPerShare/entry*100.0;

        double res1=nearestResistanceAbove(bars,entry,160);
        double res2=secondResistanceAbove(bars,entry,res1,220);
        double minT1=entry+d.riskPerShare*MIN_RR_TARGET1;
        double t1=minT1;
        if(valid(res1)){
            double justBelow=res1*0.995;
            if(justBelow>=minT1) t1=Math.min(minT1,justBelow); // prefer the first target at 2R, unless a nearer resistance is still above 2R.
            else if(justBelow>entry+d.riskPerShare*1.85) t1=justBelow;
        }
        double minT2=entry+d.riskPerShare*MIN_RR_TARGET2;
        double t2=minT2;
        if(valid(res2) && res2*0.995>t1+d.riskPerShare*0.60) t2=Math.max(minT2,Math.min(minT2+atr,res2*0.995));
        if(t2<=t1) t2=Math.max(t1+d.riskPerShare*0.80,minT2);
        d.target1=t1;d.target2=t2;
        d.rr1=d.riskPerShare>0?(d.target1-entry)/d.riskPerShare:0;
        d.rr2=d.riskPerShare>0?(d.target2-entry)/d.riskPerShare:0;
        double emaTrail=emaLast(bars,20)-atr*1.15;
        double chandelier=highestHigh(bars,22)-atr*3.0;
        double trailRaw=Math.max(emaTrail,chandelier);
        double trailCap=price-atr*0.20;
        d.trailingStop=Math.max(d.stop,Math.min(trailCap,trailRaw));
        d.suggestedQty=(int)Math.floor(500.0/d.riskPerShare); // model convention: 0.5% risk on the 100,000 TL paper account.
        int maxQty=(int)Math.floor(25000.0/Math.max(0.01,entry)); // model cap: <=25% paper-account notional.
        if(d.suggestedQty>maxQty)d.suggestedQty=Math.max(0,maxQty);
        d.suggestedPositionPct=entry>0?d.suggestedQty*entry/100000.0*100.0:0;
        d.hardGateOk=d.rr1>=MIN_RR_TARGET1 && d.rr2>=MIN_RR_TARGET2 && d.stopPct>=MIN_INITIAL_STOP_PCT
                && d.stopPct<=MAX_INITIAL_STOP_PCT && d.suggestedQty>0 && valid(d.stop) && valid(d.target1) && valid(d.target2);
        if(valid(res1) && res1<minT1)d.hardGateOk=false;
        if(valid(res2) && res2<minT2*0.98)d.hardGateOk=false;
        if(price>support60*1.30 && "Stage 1".equals(weekly.stage)) d.hardGateOk=false;
    }

    private static String buildReason(Decision d,int bull,int bear){
        StringBuilder sb=new StringBuilder();
        sb.append("7 koşul ").append(d.met).append('/').append(TOTAL_CONDITIONS);
        sb.append(" • Kurulum: ").append(d.setupType);
        sb.append(" • Haftalık: ").append(d.stage);
        sb.append(" • Piyasa: ").append(d.marketRegime);
        sb.append(" • RS(BIST100): ").append(String.format(Locale.US,"%+.1f%%",d.relativeStrengthPct));
        sb.append(" • ADX: ").append(String.format(Locale.US,"%.1f",d.adx));
        sb.append(" • ATR: ").append(String.format(Locale.US,"%.2f%%",d.atrPct));
        sb.append(" • Hacim: ").append(String.format(Locale.US,"%.2fx",d.volumeRatio));
        if(d.contractionConfirmed)sb.append(" • Sıkışma");
        if(d.overextended)sb.append(" • Uzamış/fiyat boşluğu");
        if(!d.marketOk)sb.append(" • Piyasa filtresi");
        if(!d.relativeStrengthOk)sb.append(" • RS zayıf");
        if(d.volatilityShock)sb.append(" • Volatilite şoku");
        else if(!d.volatilityOk)sb.append(" • Volatilite filtresi");
        if(d.distributionFlag)sb.append(" • Dağıtım/arz baskısı");
        if(!d.entryZoneOk)sb.append(" • Giriş bölgesi dışında");
        if(!d.hardGateOk)sb.append(" • Stop/RR güvenlik kapısı");
        sb.append(" • Stop ").append(String.format(Locale.US,"%.2f%%",d.stopPct));
        sb.append(" • R/R ").append(String.format(Locale.US,"%.2f/%.2f",d.rr1,d.rr2));
        return sb.toString();
    }

    private static String buildSafety(Decision d){
        if("AL".equals(d.signal)&&d.hardGateOk){
            return String.format(Locale.US,"Güvenlik geçti • stop %.1f%% • R/R T1 %.2f • T2 %.2f",d.stopPct,d.rr1,d.rr2);
        }
        if(!d.hardGateOk)return "İşlem planı stop/RR/giriş/piyasa filtresinden geçmedi; BEKLE varsayılandır.";
        return "SAT yeni short emri değildir; mevcut long pozisyon için risk azaltma/çıkış sinyali olarak yorumlanır.";
    }

    public static String conditionSummary(Stock s){
        if(s==null||!s.analysisReady)return "Analiz bekleniyor.";
        boolean bull=!"SAT".equals(s.signal);
        String ema=bull?"EMA20>50":"EMA20<50";
        String sr=bull?"Destek":"Direnç";
        return "RSI "+mark(s.rsiOk)+" • MACD "+mark(s.macdOk)+" • "+ema+" "+mark(s.emaOk)
                +" • Hacim "+mark(s.volumeOk)+" • Trend "+mark(s.trendOk)+" • "+sr+" "+mark(s.supportOk)
                +" • Momentum "+mark(s.momentumOk)+" • Sinyal koşulları: "+s.conditionsMet+"/"+s.conditionsTotal
                +" • Model güveni "+String.format(Locale.US,"%.0f/100",s.confidence);
    }

    private static String mark(boolean b){return b?"✓":"—";}

    private static String managementText(String signal,String setup){
        if("AL".equals(signal))return "T1'de %50 kâr realize et • T1 sonrası stopu başa başın biraz üstüne taşı • kalan pozisyonu EMA20 + ATR trailing ile yönet • T2'de kalan kısmı kapat.";
        if("SAT".equals(signal))return "Mevcut long pozisyon için çıkış/riski azaltma sinyali • yeni short açma varsayımı yok.";
        return "Kurulum teyit edilene kadar bekle • stop/RR uygun değilse işlem açma • giriş bölgesinin dışına taşan fiyatı kovalamama.";
    }

    public static String liveRisk(double dailyPct){
        double a=Math.abs(dailyPct);
        if(a<2)return "Düşük Risk";
        if(a<5)return "Orta Risk";
        return "Yüksek Risk";
    }

    private static String riskFor(double atrPct,double volRatio,String marketRegime){
        if("Riskli".equals(marketRegime))return "Yüksek Risk";
        if(atrPct<2.5 && volRatio>=0.8)return "Düşük Risk";
        if(atrPct<5)return "Orta Risk";
        return "Yüksek Risk";
    }

    private static String weeklyMarketState(List<Candle> benchmark,long time){
        if(benchmark==null||benchmark.size()<MIN_DEEP_BARS)return "Piyasa doğrulaması yok";
        int bi=floorIndex(benchmark,time);
        if(bi<MIN_DEEP_BARS-1)return "Piyasa doğrulaması yok";
        WeeklyState w=weeklyState(benchmark.subList(0,bi+1));
        if("Stage 4".equals(w.stage))return "Riskli";
        if("Stage 2".equals(w.stage))return "Olumlu";
        return "Nötr";
    }

    private static double alignedRelativeStrength(List<Candle> stockBars,List<Candle> benchBars,int lookback){
        if(stockBars==null||benchBars==null||stockBars.size()<=lookback||benchBars.size()<lookback+1)return 0;
        long now=stockBars.get(stockBars.size()-1).time;
        long then=stockBars.get(stockBars.size()-1-lookback).time;
        int nowB=floorIndex(benchBars,now), thenB=floorIndex(benchBars,then);
        if(nowB<0||thenB<0||nowB<=thenB)return 0;
        double sr=stockBars.get(stockBars.size()-1).close/stockBars.get(stockBars.size()-1-lookback).close-1;
        double br=benchBars.get(nowB).close/benchBars.get(thenB).close-1;
        return (sr-br)*100;
    }

    private static WeeklyState weeklyState(List<Candle> daily){
        WeeklyState w=new WeeklyState();
        if(daily==null||daily.size()<MIN_DEEP_BARS)return w;
        ArrayList<Candle> weeks=new ArrayList<>();
        Calendar cal=Calendar.getInstance(new Locale("tr","TR"));
        cal.setFirstDayOfWeek(Calendar.MONDAY);cal.setMinimalDaysInFirstWeek(4);
        String currentKey=null;long lastTime=0;String lastDate="";double open=0,hi=0,lo=Double.MAX_VALUE,close=0,vol=0;
        for(Candle c:daily){
            cal.setTimeInMillis(c.time);
            String key=cal.get(Calendar.YEAR)+"-"+cal.get(Calendar.WEEK_OF_YEAR);
            if(currentKey!=null&&!key.equals(currentKey)){
                weeks.add(new Candle(lastTime,lastDate,open,hi,lo,close,vol,true));
                open=0;hi=0;lo=Double.MAX_VALUE;close=0;vol=0;
            }
            if(open==0)open=c.open;
            hi=Math.max(hi,c.high);lo=Math.min(lo,c.low);close=c.close;vol+=c.volume;lastTime=c.time;lastDate=c.date;currentKey=key;
        }
        if(open>0)weeks.add(new Candle(lastTime,lastDate,open,hi,lo,close,vol,true));
        if(weeks.size()<31)return w;
        double[] c=closes(weeks);
        double ma30=smaAt(c,c.length-1,30);
        double older=smaAt(c,c.length-5,30);
        double ret6=pctAgo(c,Math.min(6,c.length-1));
        boolean above=c[c.length-1]>ma30, below=c[c.length-1]<ma30;
        if(above&&ma30>older&&ret6>0)w.stage="Stage 2";
        else if(below&&ma30<older&&ret6<0)w.stage="Stage 4";
        else if(Math.abs(ret6)<8&&Math.abs(ma30/smaAt(c,Math.max(29,c.length-10),30)-1)<0.03)w.stage="Stage 1";
        else w.stage="Stage 3";
        w.ma30=ma30;w.close=c[c.length-1];w.slopePct=older>0?(ma30/older-1)*100:0;
        return w;
    }

    private static boolean volatilityContraction(double[] close,double[] high,double[] low){
        if(close.length<80)return false;
        double a14=atrLast(close,high,low,14),a50=atrLast(close,high,low,50);
        double bw=bbWidth(close,20),bw50=bbWidthAverage(close,50);
        return a50>0&&a14<=a50*0.92&&bw50>0&&bw<=bw50*0.92;
    }

    private static ADX adxLast(double[] close,double[] high,double[] low,int period){
        ADX out=new ADX();
        if(close.length<period*2){out.adx=0;return out;}
        double trSm=0,plusSm=0,minusSm=0;ArrayList<Double> adxs=new ArrayList<>();
        for(int i=1;i<=period;i++){
            double tr=trueRange(close,high,low,i);double up=high[i]-high[i-1],down=low[i-1]-low[i];
            trSm+=tr;plusSm+=(up>down&&up>0?up:0);minusSm+=(down>up&&down>0?down:0);
        }
        double dx=0;
        for(int i=period;i<close.length;i++){
            if(i>period){
                double tr=trueRange(close,high,low,i);double up=high[i]-high[i-1],down=low[i-1]-low[i];
                trSm=trSm-trSm/period+tr;plusSm=plusSm-plusSm/period+(up>down&&up>0?up:0);minusSm=minusSm-minusSm/period+(down>up&&down>0?down:0);
            }
            double dip=trSm>0?100*plusSm/trSm:0,din=trSm>0?100*minusSm/trSm:0;
            dx=(dip+din)>0?100*Math.abs(dip-din)/(dip+din):0;
            adxs.add(dx);
            out.diPlus=dip;out.diMinus=din;
        }
        if(adxs.size()<period){out.adx=dx;return out;}
        double a=0;for(int i=adxs.size()-period;i<adxs.size();i++)a+=adxs.get(i);out.adx=a/period;return out;
    }

    private static double obvSlopePct(double[] close,double[] volume,int lookback){
        if(close.length<=lookback)return 0;
        double obv=0;double[] vals=new double[close.length];
        vals[0]=0;
        for(int i=1;i<close.length;i++){
            if(close[i]>close[i-1])obv+=volume[i]; else if(close[i]<close[i-1])obv-=volume[i];
            vals[i]=obv;
        }
        double old=vals[vals.length-1-lookback],now=vals[vals.length-1];
        double denom=averageAbs(vals,Math.min(50,vals.length));
        return denom>0?(now-old)/denom*100:0;
    }

    private static boolean isBullishCandle(Candle c){
        if(c==null||c.high<=c.low)return false;
        double body=Math.abs(c.close-c.open),range=c.high-c.low,lower=Math.min(c.open,c.close)-c.low;
        double loc=(c.close-c.low)/range;
        return c.close>=c.open&&loc>=0.62&&(lower>=body*0.6||body/range>=0.55);
    }
    private static double candleCloseLocation(Candle c){return c==null||c.high<=c.low?0.5:(c.close-c.low)/(c.high-c.low);}

    private static double nearestResistanceAbove(List<Candle> bars,double entry,int lookback){
        int start=Math.max(1,bars.size()-Math.min(lookback,bars.size()));double best=Double.MAX_VALUE;
        for(int i=start;i<bars.size()-1;i++){
            double h=bars.get(i).high;
            if(h>entry&&h>=bars.get(i-1).high&&h>=bars.get(i+1).high&&h<best)best=h;
        }
        return best==Double.MAX_VALUE?0:best;
    }
    private static double secondResistanceAbove(List<Candle> bars,double entry,double first,int lookback){
        int start=Math.max(1,bars.size()-Math.min(lookback,bars.size()));double best=Double.MAX_VALUE;
        for(int i=start;i<bars.size()-1;i++){
            double h=bars.get(i).high;
            if(h>Math.max(entry,first>0?first*1.01:entry)&&h>=bars.get(i-1).high&&h>=bars.get(i+1).high&&h<best)best=h;
        }
        return best==Double.MAX_VALUE?0:best;
    }

    private static ArrayList<Candle> cleanBars(List<Candle> src){
        ArrayList<Candle> out=new ArrayList<>();if(src==null)return out;long prev=Long.MIN_VALUE;
        for(Candle c:src){
            if(c==null||!valid(c.open)||!valid(c.high)||!valid(c.low)||!valid(c.close)||c.low<=0)continue;
            if(c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close))continue;
            if(c.time<=prev)continue;
            out.add(c);prev=c.time;
        }
        return out;
    }

    public static boolean hasFullOhlcv(List<Candle> bars){
        if(bars==null||bars.isEmpty())return false;int full=0;
        for(Candle c:bars){
            if(c!=null&&c.fullOhlc&&valid(c.open)&&valid(c.high)&&valid(c.low)&&valid(c.close)
                    &&c.high>=Math.max(c.open,c.close)&&c.low<=Math.min(c.open,c.close))full++;
        }
        return full>=Math.max(20,(int)Math.ceil(bars.size()*0.92));
    }

    private static double trueRange(double[] close,double[] high,double[] low,int i){
        if(i<=0)return high[0]-low[0];
        return Math.max(high[i]-low[i],Math.max(Math.abs(high[i]-close[i-1]),Math.abs(low[i]-close[i-1])));
    }
    private static double atrLast(double[] c,double[] h,double[] l,int p){
        int n=c.length;int start=Math.max(1,n-p);double sum=0;int cnt=0;for(int i=start;i<n;i++){sum+=trueRange(c,h,l,i);cnt++;}return cnt==0?0:sum/cnt;
    }
    private static double atrPctLast(double[] c,double[] h,double[] l,int p){double a=atrLast(c,h,l,p),px=c[c.length-1];return px>0?a/px*100:0;}

    private static MacdSeries macdSeries(double[] c,int fast,int slow,int signal){
        MacdSeries out=new MacdSeries(c.length);double[] ef=emaSeries(c,fast),es=emaSeries(c,slow);double k=2.0/(signal+1);out.signal[0]=0;
        for(int i=0;i<c.length;i++){out.macd[i]=ef[i]-es[i];out.hist[i]=out.macd[i]-(i==0?out.macd[i]:out.signal[i-1]);out.signal[i]=i==0?out.macd[i]:out.macd[i]*k+out.signal[i-1]*(1-k);out.hist[i]=out.macd[i]-out.signal[i];}
        return out;
    }

    private static double rsiLast(double[] c,int p){
        if(c.length<=p)return 50;
        double gain=0,loss=0;for(int i=1;i<=p;i++){double d=c[i]-c[i-1];if(d>0)gain+=d;else loss-=d;}
        gain/=p;loss/=p;
        for(int i=p+1;i<c.length;i++){double d=c[i]-c[i-1];gain=(gain*(p-1)+(d>0?d:0))/p;loss=(loss*(p-1)+(d<0?-d:0))/p;}
        if(loss==0)return 100;double rs=gain/loss;return 100-(100/(1+rs));
    }
    private static double pctAgo(double[] c,int p){if(c.length<=p||c[c.length-1-p]==0)return 0;return(c[c.length-1]/c[c.length-1-p]-1)*100;}
    private static double[] emaSeries(double[] a,int period){double[] out=new double[a.length];if(a.length==0)return out;double e=a[0],k=2.0/(period+1);out[0]=e;for(int i=1;i<a.length;i++){e=a[i]*k+e*(1-k);out[i]=e;}return out;}
    private static double emaLast(List<Candle> bars,int p){return emaSeries(closes(bars),p)[bars.size()-1];}
    private static double smaAt(double[] a,int end,int p){if(a.length==0)return 0;int e=Math.min(end,a.length-1),s=Math.max(0,e-p+1);double sum=0;int n=0;for(int i=s;i<=e;i++){sum+=a[i];n++;}return n==0?0:sum/n;}
    private static double averageTail(double[] a,int n){if(a==null||a.length==0)return 0;int s=Math.max(0,a.length-Math.max(1,n));double sum=0;int c=0;for(int i=s;i<a.length;i++){sum+=a[i];c++;}return c==0?0:sum/c;}
    private static double stddevLast(double[] a,int n){int s=Math.max(0,a.length-n);double m=averageTail(a,n),sum=0;int c=0;for(int i=s;i<a.length;i++){double d=a[i]-m;sum+=d*d;c++;}return c==0?0:Math.sqrt(sum/c);}
    private static double averageAbs(double[] a,int n){int s=Math.max(0,a.length-n);double sum=0;int c=0;for(int i=s;i<a.length;i++){sum+=Math.abs(a[i]);c++;}return c==0?0:sum/c;}
    private static double slopePercent(double[] a,int lookback){if(a.length<=lookback)return 0;double old=a[a.length-1-lookback];return old==0?0:(a[a.length-1]/old-1)*100;}
    private static double rollingLowExcludingLast(double[] a,int p){if(a.length<=1)return a.length==0?0:a[0];int end=a.length-2,start=Math.max(0,end-p+1);double x=Double.MAX_VALUE;for(int i=start;i<=end;i++)x=Math.min(x,a[i]);return x==Double.MAX_VALUE?0:x;}
    private static double rollingHighExcludingLast(double[] a,int p){if(a.length<=1)return a.length==0?0:a[0];int end=a.length-2,start=Math.max(0,end-p+1);double x=0;for(int i=start;i<=end;i++)x=Math.max(x,a[i]);return x;}
    private static double bbWidth(double[] c,int p){if(c.length<p)return 0;double m=averageTail(c,p),sd=stddevLast(c,p);return m==0?0:(4*sd/m*100);}
    private static double bbWidthAverage(double[] c,int lookback){if(c.length<lookback+25)return bbWidth(c,20);int start=Math.max(20,c.length-lookback),count=0;double sum=0;for(int end=start;end<c.length;end++){double[] x=Arrays.copyOf(c,end+1);sum+=bbWidth(x,20);count++;}return count==0?0:sum/count;}
    private static double distance(double a,double b){return Math.abs(a-b);}
    private static double highestHigh(List<Candle> bars,int lookback){
        if(bars==null||bars.isEmpty())return 0;
        int end=bars.size()-1,start=Math.max(0,end-Math.max(1,lookback)+1);
        double h=0;for(int i=start;i<=end;i++)h=Math.max(h,bars.get(i).high);return h;
    }
    private static double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    private static int bool(boolean v){return v?1:0;}
    private static boolean valid(double d){return !Double.isNaN(d)&&!Double.isInfinite(d)&&d>0;}
    private static double[] closes(List<Candle> bars){double[] a=new double[bars.size()];for(int i=0;i<bars.size();i++)a[i]=bars.get(i).close;return a;}
    private static int floorIndex(List<Candle> bars,long time){
        if(bars==null||bars.isEmpty())return -1;int lo=0,hi=bars.size()-1,ans=-1;
        while(lo<=hi){int mid=(lo+hi)>>>1;if(bars.get(mid).time<=time){ans=mid;lo=mid+1;}else hi=mid-1;}return ans;
    }

    private static final class MacdSeries {double[] macd,signal,hist;MacdSeries(int n){macd=new double[n];signal=new double[n];hist=new double[n];}}
    private static final class ADX {double adx,diPlus,diMinus;}
    private static final class WeeklyState {String stage="Belirsiz";double ma30,close,slopePct;}
}
