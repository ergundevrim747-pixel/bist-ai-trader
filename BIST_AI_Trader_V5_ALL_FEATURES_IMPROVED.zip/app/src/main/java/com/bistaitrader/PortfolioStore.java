package com.bistaitrader;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Persistent virtual-portfolio ledger plus position-management metadata. */
public class PortfolioStore {
    private final android.content.SharedPreferences sp;
    public PortfolioStore(Context c){sp=c.getApplicationContext().getSharedPreferences("portfolio",Context.MODE_PRIVATE);}
    public double cash(){return Double.longBitsToDouble(sp.getLong("cash",Double.doubleToLongBits(100000.0)));}
    public void setCash(double v){sp.edit().putLong("cash",Double.doubleToLongBits(Math.max(0,v))).apply();}
    public int qty(String sym){return sp.getInt("q_"+sym,0);}
    public void setQty(String sym,int q){sp.edit().putInt("q_"+sym,Math.max(0,q)).apply();}
    public double avgCost(String sym){return Double.longBitsToDouble(sp.getLong("avg_"+sym,Double.doubleToLongBits(0)));}
    private void setAvgCost(String sym,double v){sp.edit().putLong("avg_"+sym,Double.doubleToLongBits(Math.max(0,v))).apply();}
    public Set<String> symbols(){String raw=sp.getString("symbols","");Set<String> out=new LinkedHashSet<>();if(!raw.isEmpty())out.addAll(Arrays.asList(raw.split(",")));return out;}
    private void addSymbol(String sym){Set<String>s=symbols();s.add(sym);sp.edit().putString("symbols",String.join(",",s)).apply();}
    private double commissionRate(){return 0.002;}

    public double peakPrice(String sym){return Double.longBitsToDouble(sp.getLong("peak_"+sym,Double.doubleToLongBits(0)));}
    public synchronized double observePeak(String sym,double price){
        if(sym==null||sym.isEmpty()||price<=0)return peakPrice(sym);
        double old=peakPrice(sym), next=Math.max(old,price);
        if(next>old)sp.edit().putLong("peak_"+sym,Double.doubleToLongBits(next)).apply();
        return next;
    }
    public void clearPeak(String sym){if(sym!=null)sp.edit().remove("peak_"+sym).apply();}

    public double planStop(String sym){return Double.longBitsToDouble(sp.getLong("plan_stop_"+sym,Double.doubleToLongBits(0)));}
    public double planTarget1(String sym){return Double.longBitsToDouble(sp.getLong("plan_t1_"+sym,Double.doubleToLongBits(0)));}
    public double planTarget2(String sym){return Double.longBitsToDouble(sp.getLong("plan_t2_"+sym,Double.doubleToLongBits(0)));}
    public synchronized void updatePlan(String sym,double stop,double t1,double t2){
        if(sym==null||sym.isEmpty())return;
        android.content.SharedPreferences.Editor e=sp.edit();
        if(stop>0)e.putLong("plan_stop_"+sym,Double.doubleToLongBits(stop)); else e.remove("plan_stop_"+sym);
        if(t1>0)e.putLong("plan_t1_"+sym,Double.doubleToLongBits(t1)); else e.remove("plan_t1_"+sym);
        if(t2>0)e.putLong("plan_t2_"+sym,Double.doubleToLongBits(t2)); else e.remove("plan_t2_"+sym);
        e.apply();
    }
    public void clearPlan(String sym){if(sym!=null)sp.edit().remove("plan_stop_"+sym).remove("plan_t1_"+sym).remove("plan_t2_"+sym).apply();}

    public boolean buy(String sym,double price,int q){
        if(sym==null||q<=0||price<=0)return false;
        double gross=price*q, fee=gross*commissionRate(), total=gross+fee;
        if(total>cash())return false;
        int oldQ=qty(sym);double oldAvg=avgCost(sym);int newQ=oldQ+q;
        double newAvg=(oldQ*oldAvg+total)/newQ;
        setCash(cash()-total);setQty(sym,newQ);setAvgCost(sym,newAvg);addSymbol(sym);observePeak(sym,price);logTrade(sym,"AL",price,q,fee);return true;
    }
    public boolean sell(String sym,double price,int q){
        if(sym==null||q<=0||price<=0||qty(sym)<q)return false;
        double gross=price*q,fee=gross*commissionRate(),net=gross-fee;
        int left=qty(sym)-q;
        setCash(cash()+net);setQty(sym,left);if(left==0){setAvgCost(sym,0);clearPeak(sym);clearPlan(sym);}logTrade(sym,"SAT",price,q,fee);return true;
    }
    private void logTrade(String sym,String side,double price,int qty,double fee){
        String raw=sp.getString("trades","[]");JSONArray a;try{a=new JSONArray(raw);}catch(Exception e){a=new JSONArray();}
        try{JSONObject o=new JSONObject();o.put("symbol",sym);o.put("side",side);o.put("price",price);o.put("qty",qty);o.put("fee",fee);o.put("time",System.currentTimeMillis());a.put(o);}catch(Exception ignored){}
        while(a.length()>300)a.remove(0);sp.edit().putString("trades",a.toString()).apply();
    }
    public JSONArray tradeHistory(){try{return new JSONArray(sp.getString("trades","[]"));}catch(Exception e){return new JSONArray();}}
    public boolean hasPositions(){for(String s:symbols())if(qty(s)>0)return true;return false;}
    public void reset(){sp.edit().clear().apply();setCash(100000);}
}
