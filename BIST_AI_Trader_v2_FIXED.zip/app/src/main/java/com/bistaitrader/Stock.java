package com.bistaitrader;

public class Stock {
    public String symbol = "";
    public String name = "";
    public String sector = "";
    public double price = 0;
    public double previousClose = 0;
    public double changePct = 0;
    public double volume = 0;
    public double avgVolume = 0;
    public double rsi = 50;
    public double macd = 0;
    public double ema20 = 0;
    public double ema50 = 0;
    public double atrPct = 0;
    public double score = 50;
    public double newsScore = 0;
    public String signal = "BEKLE";
    public String risk = "Orta Risk";
    public double support1 = 0, support2 = 0, resistance1 = 0, resistance2 = 0;
    public long updatedAt = System.currentTimeMillis();
    public boolean live = false;

    public Stock copy() {
        Stock s = new Stock();
        s.symbol=symbol; s.name=name; s.sector=sector; s.price=price; s.previousClose=previousClose;
        s.changePct=changePct; s.volume=volume; s.avgVolume=avgVolume; s.rsi=rsi; s.macd=macd;
        s.ema20=ema20; s.ema50=ema50; s.atrPct=atrPct; s.score=score; s.newsScore=newsScore;
        s.signal=signal; s.risk=risk; s.support1=support1; s.support2=support2; s.resistance1=resistance1;
        s.resistance2=resistance2; s.updatedAt=updatedAt; s.live=live;
        return s;
    }
}
