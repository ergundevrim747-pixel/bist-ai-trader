package com.bistaitrader;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/**
 * Dynamic BIST equity universe. The embedded list is an offline safety net only.
 * Runtime discovery from İş Yatırım can add newly listed symbols and metadata
 * without an app update.
 */
public final class StockUniverse {
    private StockUniverse() {}

    private static final String[] FALLBACK_SYMBOLS = {
        "ATATR","BESTE","AKHAN","NETCD","ZGYO","MEYSU","ARFYE","ZERGY","PAHOL","ECOGR","MARMR","DOFRB","BULGS","BALSU","KLYPV","ENDAE","VSNMD","DSTKF","BIGEN","SERNT","MOPAS","AKFIS","GLRMK","EGEGY","ARMGD","SMRVA","CGCAM","BINBN","DURKN","CEMZY","OZATD","AHSGY","GUNDG","TCKRC","BAHKM","DCTTR","SEGMN","EFOR","HOROZ","YIGIT","ALKLC","OZYSR","ONRYT","HRKET","KOCMT","ALTNY","KOTON","LILAK","RGYAS","ENTRA","ODINE","MOGAN","ARTMS","OBAMS","ALVES","LMKDC","BORSK","PATEK","AVPGY","MEGMT","KBORU","SURGY","CATES","SKYMD","BEGYO","AGROT","EKOS","BINHO","MARBL","TABGD","VRGYO","MHRGY","BORLS","DOFER","MEKAG","DMRGD","ADGYO","HATSN","REEDR","GIPTA","TARKM","EBEBK","KZGYO","ENERY","TATEN","OFSYM","IZENR","ASGYO","KLSER","FZLGY","ATAKP","FORTE","A1CAP","PASEU","KTLEV","BIENY","KAYSE","BIGCH","CWENE","GRTHO","EUPWR","CVKMD","KOPOL","EKSUN","AKFYE","GOKNR","BVSAN","MACKO","ASTOR","TNZTP","SOKE","SDTTR","ONCSM","EYGYO","TERA","AHGAZ","BRKVY","PLTUR","OZSUB","SNICA","ALFAS","AZTEK","HKTM","BARMA","KRPLS","KLRHO","RUBNS","KCAER","PRDGS","MAKIM","EUREN","SEGYO","SUNTK","YYLGD","BMSTL","IMASM","KMPUR","CONSE","SUWEN","LIDER","SMRTG","ENSRI","GRSEL","GZNMI","KLSYN","HTTBT","INVES","DAPGM","HUNER","PNLSN","ERCB","PSGYO","PCILT","GMTAS","KONKA","MOBTL","MIATK","ISSEN","ELITE","ARASE","ULUFA","IHAAS","ANGEN","HEDEF","GLCVY","MAGEN","KIMMR","TEZOL","YEOTK","EGEPO","BRLSM","GESAN","KZBGY","GENIL","MANAS","A1YEN","ESCAR","VBTYZ","KTSKR","EDATA","MEDTR","SELVA","BASGZ","OYYAT","BMSCH","UNLU","BOBET","ATATP","MERCN","KLKIM","PENTA","ZRGYO","CANTE","AYDEM","BIOEN","GWIND","TUREX","QUAGR","MTRKS","NTGAZ","TRILC","ISKPL","ARZUM","KRVGD","KONTR","ESEN","DNISI","BAYRK","ARDYZ","PAPIL","YKSLN","NATEN","DERHL","CEOEM","SMART","FORMT","KFEIN","SOKM","PEKGY","MPARK","ENJSA","TLMAN","SAFKR","MAVI","FONET","MSGYO","ISDMR","VERTU","BNTAS","HDFGS","AGESA","ULUUN","ULUSE","IZFAS","LIDFA","PAMEL","TUCLK","RTALB","KRGYO","POLTK","GEDZA","TMPOL","YAYLA","VERUS","YGGYO","TURGG","SAYAS","OTTO","PAGYO","ODAS","PGSUS","SRVGY","HLGYO","AKSGY","AVHOL","TMSN","BERA","LYDYE","KUYAS","JANTS","DENGE","ETILR","ACSEL","TGSAS","POLHO","OSTIM","TKNSA","ORGE","SANFM","BEYAZ","NIBAS","OSMEN","OZKGY","AVOD","ADESE","INFO","GLRYH","DAGI","KRONT","BLCYT","YAPRK","AKFGY","KLGYO","ZEDUR","LKMNH","HATEK","DESPC","DOCO","EKGYO","KATMR","IHYAY","TRGYO","MRGYO","GEDIK","RYGYO","CEMAS","ANELE","IHGZT","AKSEN","TSGYO","TRALT","GOZDE","LRSHO","TTKOM","TKFEN","ALBRK","SNGYO","ISMEN","HALKB","TAVHL","UFUK","KAREL","INGRM","CCOLA","SELEC","VESBE","DGATE","RYSAS","VAKBN","BIMAS","MARKA","TSPOR","ISGSY","INDES","DOAS","TTRAK","DESA","YESIL","FENER","GEREL","TRMET","BLUME","GSRAY","BJKAS","ALKA","ARENA","LINK","TEKTU","MNDRS","ESCOM","TCELL","ICUGS","AKENR","AYEN","TRENJ","RUZYE","ZOREN","LOGO","BSOKE","BIGTK","ISFIN","ALKIM","ANHYT","NUHCM","KARSN","AGHOL","AKSUE","NUGYO","IHLGM","ISGYO","GSDHO","INVEO","ECZYT","IEYHO","ARSAN","DUNYH","KGYO","KRDMD","EMKEL","PENGD","VAKKO","METRO","CMBTN","PRKME","KLMSN","KRSTL","RAYSG","DMSAS","SAHOL","ASUZU","SKBNK","VKGYO","ALGYO","CLEBI","BRYAT","SASA","RALYH","ULKER","YATAS","KNFRT","AVGYO","ADEL","AKCNS","DZGYO","KAPLM","BOSSA","GLYHO","OTKAR","FRIGO","SKTAS","BTCIM","GOLTS","GSDDE","CEMTS","AKGRT","TUKAS","AEFES","TURSG","MERKO","BRSAN","OZGYO","DARDL","BESLR","EPLAS","IHLAS","GARFA","BFREN","EGPRO","ANSGR","LYDHO","TATGD","DOHOL","NETAS","BANVT","BURCE","TRCAS","HURGZ","ALARK","ALCAR","TEHOL","PKENT","DITAS","DURDO","CRFSA","TUPRS","VAKFN","AFYON","MGROS","MNDTR","EDIP","TOASO","THYAO","USAK","MRSHL","KONYA","PARSN","KUTPO","FMIZP","ASELS","DGNMO","AKBNK","PETKM","VESTL","ECILC","GARAN","ICBCT","YUNSA","INTEM","MARTI","GENTS","NTHOL","TBORG","BUCIM","ALCTL","AYGAZ","PINSU","AYCES","MAALT","DYOBY","OYAKC","YKBNK","EGEEN","TSKB","DEVA","PETUN","PNSUT","MAKTK","BAGFS","IZMDC","ARCLK","PRKAB","GOODY","AKSA","FROTO","SISE","EREGL","HEKTS","DOKTA","KARTN","KCHOL","CIMSA","ISCTR","BRISA","EGGUB","KORDS","GUBRF","CELHA","ENKAI","SARKY","MERIT"
    };

    private static final LinkedHashSet<String> symbols = new LinkedHashSet<>();
    private static final Map<String,String> names = new HashMap<>();
    private static final Map<String,String> sectors = new HashMap<>();

    private static final String PREFS = "stock_universe";
    private static final String KEY_ROWS = "rows";

    static {
        Collections.addAll(symbols, FALLBACK_SYMBOLS);
    }

    public static synchronized void loadPersisted(Context context) {
        if (context == null) return;
        try {
            String raw=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_ROWS,"");
            if(raw==null||raw.isEmpty()) return;
            JSONArray a=new JSONArray(raw);
            LinkedHashMap<String,String[]> found=new LinkedHashMap<>();
            for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i); if(o==null) continue;
                String sym=o.optString("s","").trim().toUpperCase(Locale.ROOT);
                String name=o.optString("n","").trim();
                String sector=o.optString("c","").trim();
                if(sym.matches("[A-Z0-9]{3,8}")&&!name.isEmpty()) found.put(sym,new String[]{name,sector});
            }
            if(found.size()>=300) replaceAll(found);
        } catch(Exception ignored) {}
    }

    public static synchronized void savePersisted(Context context) {
        if (context == null || symbols.isEmpty()) return;
        try {
            JSONArray a=new JSONArray();
            for(String sym:symbols){
                JSONObject o=new JSONObject();
                o.put("s",sym);o.put("n",names.getOrDefault(sym,""));o.put("c",sectors.getOrDefault(sym,""));a.put(o);
            }
            context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY_ROWS,a.toString()).apply();
        } catch(Exception ignored) {}
    }

    public static synchronized List<String> allSymbols() { return new ArrayList<>(symbols); }
    public static synchronized boolean contains(String symbol) { return symbol != null && symbols.contains(symbol.toUpperCase(Locale.ROOT)); }
    public static synchronized int size() { return symbols.size(); }

    public static synchronized void merge(String symbol, String name, String sector) {
        if (symbol == null) return;
        String sym = symbol.trim().toUpperCase(Locale.ROOT);
        if (!sym.matches("[A-Z0-9]{3,8}")) return;
        symbols.add(sym);
        if (name != null && !name.trim().isEmpty()) names.put(sym, name.trim());
        if (sector != null && !sector.trim().isEmpty()) sectors.put(sym, sector.trim());
    }

    public static synchronized void replaceAll(Map<String,String[]> discovered) {
        if (discovered == null || discovered.isEmpty()) return;
        symbols.clear(); names.clear(); sectors.clear();
        for (Map.Entry<String,String[]> e : discovered.entrySet()) {
            String sym=e.getKey();
            String[] meta=e.getValue();
            if (sym==null || !sym.matches("[A-Z0-9]{3,8}")) continue;
            symbols.add(sym.toUpperCase(Locale.ROOT));
            if(meta!=null && meta.length>0 && meta[0]!=null && !meta[0].trim().isEmpty()) names.put(sym,meta[0].trim());
            if(meta!=null && meta.length>1 && meta[1]!=null && !meta[1].trim().isEmpty()) sectors.put(sym,meta[1].trim());
        }
    }

    public static synchronized String nameOf(String symbol) {
        if (symbol == null) return "";
        return names.getOrDefault(symbol.toUpperCase(Locale.ROOT), "");
    }
    public static synchronized String sectorOf(String symbol) {
        if (symbol == null) return "";
        return sectors.getOrDefault(symbol.toUpperCase(Locale.ROOT), "");
    }
    public static synchronized int metadataCount() { return names.size(); }
}
