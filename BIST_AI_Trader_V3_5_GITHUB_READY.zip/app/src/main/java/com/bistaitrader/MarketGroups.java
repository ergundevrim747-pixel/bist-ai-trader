package com.bistaitrader;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * BIST 30/50/100/500 membership.
 * The embedded sets are only an offline safety net. At runtime they are replaced
 * by the current constituent pages, so index changes do not require an app update.
 */
public final class MarketGroups {
    private MarketGroups() {}

    private static final String PREFS = "index_groups";
    private static final String KEY_30 = "bist30";
    private static final String KEY_50 = "bist50";
    private static final String KEY_100 = "bist100";
    private static final String KEY_500 = "bist500";
    private static final String KEY_LAST_SYNC = "last_sync";
    private static final String KEY_LAST_MESSAGE = "last_message";

    private static Set<String> bist30 = set("AEFES AKBNK ASELS ASTOR BIMAS DSTKF EKGYO ENKAI EREGL FROTO GARAN GUBRF ISCTR KCHOL KRDMD MGROS PETKM PGSUS SAHOL SASA SISE TAVHL TCELL THYAO TOASO TRALT TTKOM TUPRS VAKBN YKBNK");
    private static Set<String> bist50 = set("AEFES AKBNK AKSA AKSEN ALARK ASELS ASTOR BIMAS BRSAN CCOLA CIMSA EKGYO EFOR ECILC ENKAI EREGL FROTO GARAN GUBRF HALKB HEKTS ISCTR KCHOL KRDMD MGROS MPARK OYAKC PETKM PGSUS RALYH SAHOL SARKY SASA SISE SKBNK SOKM TAVHL TCELL TKFEN TOASO TTRAK TTKOM TUPRS ULKER VAKBN YKBNK GLRMK KTLEV DOAS MAVI TSKB");
    private static Set<String> bist100 = set("AEFES AKBNK AKSA AKSEN ALARK ALBRK ANSGR ARCLK ASELS ASTOR AGESA BERA BIMAS BIOEN BRSAN BRYAT BSOKE BTCIM CCOLA CANTE CIMSA CVKMD DAPGM DCTTR DEVA DGNMO DOAS DOHOL DOCO DSTKF EFOR EKGYO ENJSA ENKAI ENERY EREGL ESEN EUPWR FENER FROTO GARAN GESAN GLRMK GUBRF GRSEL GRTHO HALKB HEKTS IEYHO ISCTR ISMEN KCHOL KLRHO KRDMD KUYAS MAGEN MAVI MIATK MGROS MPARK ODAS ODINE OYAKC OBAMS PASEU PAHOL PATEK PETKM PGSUS PSGYO RALYH REEDR SAHOL SARKY SASA SISE SKBNK SOKM TAVHL TCELL TKFEN TOASO TSKB TTKOM TTRAK TUPRS TURSG TUKAS ULKER VAKBN VESTL YKBNK ZOREN");
    private static Set<String> bist500 = new LinkedHashSet<>();

    // Sanity-only: the fallback above may contain a few historical/typo tokens, so the
    // runtime sync is considered valid only when the parsed current page is large enough.
    private static boolean loaded = false;

    public static synchronized void load(Context context) {
        if (loaded) return;
        if (bist500.isEmpty()) bist500 = new LinkedHashSet<>(StockUniverse.allSymbols());
        try {
            android.content.SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            loadSet(p, KEY_30, s -> bist30 = s);
            loadSet(p, KEY_50, s -> bist50 = s);
            loadSet(p, KEY_100, s -> bist100 = s);
            loadSet(p, KEY_500, s -> bist500 = s);
        } catch (Exception ignored) {}
        loaded = true;
    }

    private interface SetConsumer { void accept(Set<String> set); }
    private static void loadSet(android.content.SharedPreferences p, String key, SetConsumer consumer) {
        String raw = p.getString(key, "");
        if (raw == null || raw.isEmpty()) return;
        Set<String> s = fromJson(raw);
        if (!s.isEmpty()) consumer.accept(s);
    }

    public static synchronized boolean syncFromHtml(Context context, String category, String html, Set<String> knownSymbols) {
        load(context);
        String marker = category == null ? "" : category;
        Set<String> parsed = extractSymbols(html, marker, knownSymbols);
        int min = minimumExpected(marker);
        if (parsed.size() < min) return false;
        if ("BIST 30".equals(marker)) bist30 = parsed;
        else if ("BIST 50".equals(marker)) bist50 = parsed;
        else if ("BIST 100".equals(marker)) bist100 = parsed;
        else if ("BIST 500".equals(marker)) bist500 = parsed;
        else return false;
        save(context);
        return true;
    }

    private static int minimumExpected(String category) {
        if ("BIST 30".equals(category)) return 20;
        if ("BIST 50".equals(category)) return 35;
        if ("BIST 100".equals(category)) return 75;
        if ("BIST 500".equals(category)) return 400;
        return Integer.MAX_VALUE;
    }

    /** Extracts symbol slugs only from the stock table section of the category page. */
    private static Set<String> extractSymbols(String html, String category, Set<String> knownSymbols) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (html == null || html.isEmpty()) return out;
        String lower = html.toLowerCase(Locale.ROOT);
        String heading = category.toLowerCase(Locale.ROOT) + " hisseleri";
        int start = lower.indexOf(heading);
        if (start < 0) start = lower.indexOf(category.toLowerCase(Locale.ROOT));
        if (start < 0) start = 0;
        int end = lower.indexOf("endeksler", Math.min(lower.length(), start + 1));
        if (end < 0) end = html.length();
        String area = html.substring(start, Math.min(end, html.length()));

        Pattern href = Pattern.compile("/borsa/hisseler/([a-z0-9]{3,8})(?:-|[\\\"'?/#])", Pattern.CASE_INSENSITIVE);
        Matcher m = href.matcher(area);
        while (m.find()) {
            String sym = m.group(1).toUpperCase(Locale.ROOT);
            if (knownSymbols == null || knownSymbols.contains(sym)) out.add(sym);
        }
        return out;
    }

    public static synchronized String status(Context context) {
        load(context);
        long t = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_SYNC, 0L);
        String msg = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_MESSAGE, "Endeks üyelikleri otomatik güncellenecek");
        if (t > 0) return msg + " • " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(t));
        return msg;
    }

    public static synchronized void setStatus(Context context, String message) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).putString(KEY_LAST_MESSAGE, message).apply();
    }

    private static void save(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_30, toJson(bist30))
                .putString(KEY_50, toJson(bist50))
                .putString(KEY_100, toJson(bist100))
                .putString(KEY_500, toJson(bist500))
                .putLong(KEY_LAST_SYNC, System.currentTimeMillis())
                .putString(KEY_LAST_MESSAGE, "Endeks üyelikleri otomatik güncellendi")
                .apply();
    }

    private static String toJson(Set<String> set) {
        JSONArray a = new JSONArray();
        for (String s : set) a.put(s);
        return a.toString();
    }
    private static Set<String> fromJson(String raw) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(raw); for (int i=0;i<a.length();i++){String x=a.optString(i,"").trim().toUpperCase(Locale.ROOT); if(!x.isEmpty()) s.add(x);} } catch(Exception ignored) {}
        return s;
    }
    private static Set<String> set(String raw){
        LinkedHashSet<String> s = new LinkedHashSet<>();
        if (raw == null) return s;
        for(String x: raw.trim().split("\\s+")) if(x.matches("[A-Z0-9]{3,8}")) s.add(x);
        return Collections.unmodifiableSet(s);
    }

    public static boolean matches(Context context, String category, Stock s) {
        load(context);
        if (category == null || category.equals("Tümü")) return true;
        if (category.equals("Takip")) return false;
        if (category.equals("BIST 30")) return bist30.contains(s.symbol);
        if (category.equals("BIST 50")) return bist50.contains(s.symbol);
        if (category.equals("BIST 100")) return bist100.contains(s.symbol);
        if (category.equals("BIST 500")) return bist500.contains(s.symbol);
        return true;
    }

    public static int count(Context context, String category) {
        load(context);
        if ("BIST 30".equals(category)) return bist30.size();
        if ("BIST 50".equals(category)) return bist50.size();
        if ("BIST 100".equals(category)) return bist100.size();
        if ("BIST 500".equals(category)) return bist500.size();
        return 0;
    }
}
