package com.bistaitrader;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;

import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements DataService.Listener, NewsService.Listener, HistoryService.Listener {
    private static final int BG=Color.rgb(7,14,26), SURFACE=Color.rgb(14,24,40), SURFACE2=Color.rgb(20,34,54), LINE=Color.rgb(38,56,81), TEXT=Color.rgb(244,247,251), MUTED=Color.rgb(145,164,186), BLUE=Color.rgb(84,145,255), GREEN=Color.rgb(48,209,88), YELLOW=Color.rgb(255,204,0), RED=Color.rgb(255,79,91), CYAN=Color.rgb(72,211,255);
    private enum Screen { HOME, MARKET, WATCH, PORTFOLIO, SETTINGS, DETAIL, HISTORY, BACKTEST, COMPARE, SIGNALS }
    private Screen screen=Screen.HOME;
    private LinearLayout root,content,nav,listHost;
    private TextView status,statusMessage,homeDataInfo,homeLastDataInfo,homeCatalogInfo,homeIndexInfo,homeMarketInfo,homeLearningInfo,detailPriceView,detailQuoteMeta;
    private EditText search;
    private final ArrayList<Stock> all=new ArrayList<>();
    private final LinkedHashSet<String> compareSet=new LinkedHashSet<>();
    private String marketCategory="POPULAR 20", riskFilter="", sort="Hacim", historyRange="6A", historyMode="Mum", strategy="Dengeli";
    private String homeSignalFilter="AL";
    private String detailHorizon=HorizonAnalysis.MEDIUM;
    private int listLimit=20;
    private Stock current;
    private Screen detailReturnScreen=Screen.MARKET;
    private DataService data; private HistoryService history; private NewsService news; private PortfolioStore portfolio; private AlertStore alerts; private SignalStore signals; private LearningStore learning;
    private HistoryChartView historyChart; private TextView historyInfo,scanStatus;
    private LinearLayout detailNewsList,homeQuickHost,detailHorizonHost;
    private final LinkedHashMap<String,HorizonAnalysis.Result> horizonResults=new LinkedHashMap<>();
    private List<Candle> detailHistoryBars=Collections.emptyList();
    private List<Candle> detailBenchmarkBars=Collections.emptyList();
    private Handler timer=new Handler(Looper.getMainLooper()); private Runnable refreshTask;
    private final ExecutorService analysisExecutor=Executors.newSingleThreadExecutor();
    private boolean live=false;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),LINE);return g;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(15),dp(16),dp(15));l.setBackground(bg(SURFACE,18));return l;}
    Button chip(String text,boolean selected){Button b=new Button(this);b.setText(text);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(selected?Color.BLACK:TEXT);b.setMinHeight(0);b.setMinimumHeight(dp(38));b.setStateListAnimator(null);b.setBackground(bg(selected?BLUE:SURFACE2,14));return b;}
    Button action(String text,int color){Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(color==YELLOW?Color.BLACK:Color.WHITE);b.setTypeface(null,Typeface.BOLD);b.setMinHeight(0);b.setMinimumHeight(dp(44));b.setStateListAnimator(null);b.setBackground(bg(color,14));return b;}
    TextView pill(String text,int color){TextView t=tv(text,10,Color.WHITE);t.setGravity(Gravity.CENTER);t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(8),dp(4),dp(8),dp(4));t.setBackground(bg(color,13));return t;}
    void spacer(int h){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void spacerIn(LinearLayout l,int h){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void spaceH(LinearLayout l,int w){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(w),1));}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        portfolio=new PortfolioStore(this);alerts=new AlertStore(this);signals=new SignalStore(this);learning=new LearningStore(this);AnalysisEngine.setLearningStore(learning);data=new DataService(this,this);news=new NewsService(this,this);history=new HistoryService(this);
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
        buildShell();showDashboard();startRefresh();SelfLearningScheduler.schedule(this);
    }
    @Override public void onBackPressed(){handleBack();}
    private void handleBack(){
        if(screen==Screen.HISTORY||screen==Screen.BACKTEST){showDetail(current);return;}
        if(screen==Screen.COMPARE||screen==Screen.SIGNALS){showDashboard();return;}
        if(screen==Screen.DETAIL){returnFromDetail();return;}
        if(screen==Screen.MARKET||screen==Screen.WATCH||screen==Screen.PORTFOLIO||screen==Screen.SETTINGS){showDashboard();return;}
        Toast.makeText(this,"Ana sayfadasın",Toast.LENGTH_SHORT).show();
    }

    private void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(16),dp(11),dp(16),dp(8));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);TextView a=tv("BIST AI TRADER",19,TEXT);a.setTypeface(null,Typeface.BOLD);brand.addView(a);statusMessage=tv("Veri • teknik analiz • sanal portföy",10,MUTED);brand.addView(statusMessage);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        status=tv("● HAZIR",11,YELLOW);status.setGravity(Gravity.RIGHT);status.setTypeface(null,Typeface.BOLD);top.addView(status,new LinearLayout.LayoutParams(dp(110),-2));root.addView(top);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(4),dp(12),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(4),dp(4),dp(4),dp(4));nav.setBackgroundColor(SURFACE);
        TextView h=navBtn("⌂\nAna"),m=navBtn("▦\nPiyasa"),w=navBtn("☆\nTakip"),p=navBtn("₺\nPortföy"),s=navBtn("⚙\nAyar");
        for(TextView x:new TextView[]{h,m,w,p,s})nav.addView(x,new LinearLayout.LayoutParams(0,dp(56),1));root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
        h.setOnClickListener(v->showDashboard());m.setOnClickListener(v->showMarket());w.setOnClickListener(v->showWatchlist());p.setOnClickListener(v->showPortfolio());s.setOnClickListener(v->showSettings());setContentView(root);
    }
    TextView navBtn(String s){TextView t=tv(s,10,MUTED);t.setGravity(Gravity.CENTER);t.setTypeface(null,Typeface.BOLD);t.setClickable(true);return t;}
    void selectNav(String label){for(int i=0;i<nav.getChildCount();i++)((TextView)nav.getChildAt(i)).setTextColor(MUTED);int idx=label.equals("Ana")?0:label.equals("Piyasa")?1:label.equals("Takip")?2:label.equals("Portföy")?3:4;((TextView)nav.getChildAt(idx)).setTextColor(TEXT);}
    void clear(){content.removeAllViews();search=null;listHost=null;detailNewsList=null;historyChart=null;historyInfo=null;scanStatus=null;homeDataInfo=null;homeLastDataInfo=null;homeCatalogInfo=null;homeIndexInfo=null;homeMarketInfo=null;homeLearningInfo=null;homeQuickHost=null;detailPriceView=null;detailQuoteMeta=null;detailHorizonHost=null;horizonResults.clear();detailHistoryBars=Collections.emptyList();detailBenchmarkBars=Collections.emptyList();}


    void showDashboard(){screen=Screen.HOME;selectNav("Ana");current=null;clear();
        content.addView(tv("Piyasa özeti",27,TEXT));
        content.addView(tv("Sanal portföy • canlı durum • seçilmiş sinyaller",12,MUTED));
        spacer(12);

        LinearLayout pf=card();
        pf.addView(tv("Sanal portföy",17,TEXT));
        double val=portfolioValue();
        pf.addView(tv(String.format(Locale.US,"%.2f ₺",val),26,TEXT));
        pf.addView(tv(String.format(Locale.US,"K/Z %+.2f ₺",val-100000),11,val>=100000?GREEN:RED));
        Button go=action("Portföye git",BLUE);go.setOnClickListener(v->showPortfolio());pf.addView(go);
        content.addView(pf);spacer(12);

        LinearLayout statusBox=card();
        LinearLayout hr=new LinearLayout(this);hr.setGravity(Gravity.CENTER_VERTICAL);
        hr.addView(tv("PİYASA VERİSİ",11,MUTED),new LinearLayout.LayoutParams(0,-2,1));
        hr.addView(pill(live?"CANLI":"BEKLENİYOR",live?GREEN:YELLOW),new LinearLayout.LayoutParams(dp(115),dp(30)));
        statusBox.addView(hr);
        statusBox.addView(tv("Kaynak: "+dataSourceLabel()+" • Son veri: "+lastDataLabel(),11,TEXT));
        statusBox.addView(tv("Endeks üyelikleri: "+MarketGroups.status(this),10,MUTED));
        statusBox.addView(tv("AI öğrenme: "+learning.sampleCount()+" örnek • "+(learning.active()?"AKTİF":"PASİF"),10,MUTED));
        content.addView(statusBox);spacer(12);

        LinearLayout quick=card();
        quick.addView(tv("Öne çıkan hisseler",18,TEXT));
        quick.addView(tv("Öncelik: AL sinyali • en fazla 20 hisse",10,MUTED));
        LinearLayout filters=new LinearLayout(this);
        for(String f:new String[]{"AL","BEKLE","SAT"}){Button b=chip(f,f.equals(homeSignalFilter));b.setOnClickListener(v->{homeSignalFilter=f;renderHomeQuickStocks();});filters.addView(b,new LinearLayout.LayoutParams(0,dp(40),1));spaceH(filters,5);}
        quick.addView(filters);
        homeQuickHost=new LinearLayout(this);homeQuickHost.setOrientation(LinearLayout.VERTICAL);quick.addView(homeQuickHost);
        renderHomeQuickStocks();
        content.addView(quick);spacer(12);

        LinearLayout tools=card();tools.addView(tv("Hızlı araçlar",17,TEXT));
        addToolButton(tools,"📊 Sinyal geçmişi",v->showSignals());
        addToolButton(tools,"⚖ Hisse karşılaştır",v->showCompare());
        addToolButton(tools,"🧪 Backtest",v->{if(current!=null)showBacktest(current);else toast("Önce bir hisse aç" );});
        addToolButton(tools,"🧠 AI Öğrenme",v->showLearning());
        content.addView(tools);spacer(12);

        LinearLayout note=card();
        note.addView(tv("Analiz mantığı",17,TEXT));
        note.addView(tv("Bir hisseyi açtığında geçmiş günlük verisi yalnızca o hisse için yüklenir ve 3 ayrı vade birlikte değerlendirilir: Uzun Vade Yatırım, Orta Vade ve Kısa Vade. Canlı fiyat, son tarihsel kapanışın üzerine ayrıca uygulanır.",10,MUTED));
        note.addView(tv("AL için artık yalnızca 5/7 yeterli değildir: en az 6/7 teknik teyit + model puanı + giriş/stop/RR/piyasa kapıları gerekir.",10,MUTED));
        content.addView(note);
    }

    void renderHomeQuickStocks(){
        if(homeQuickHost==null)return;
        homeQuickHost.removeAllViews();
        ArrayList<Stock> list=new ArrayList<>(all);
        list.removeIf(x->!x.analysisReady||x.price<=0||!homeSignalFilter.equals(x.signal));
        if("AL".equals(homeSignalFilter)) list.sort(Comparator.comparingDouble((Stock x)->-x.score));
        else if("SAT".equals(homeSignalFilter)) list.sort(Comparator.comparingDouble((Stock x)->x.score));
        else list.sort(Comparator.comparingDouble((Stock x)->-Math.abs(x.changePct)));
        int shown=Math.min(listLimit,list.size());
        if(shown==0){homeQuickHost.addView(tv("Bu filtrede şu anda doğrulanmış sinyal yok. Zorla AL üretilmiyor.",11,MUTED));return;}
        for(int i=0;i<shown;i++)homeQuickHost.addView(stockRow(list.get(i)));
    }


    void addToolButton(LinearLayout parent,String text,View.OnClickListener l){Button b=chip(text,false);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));lp.topMargin=dp(6);parent.addView(b,lp);}
    void addCategoryButtons(LinearLayout parent){
        String[] cats={"BIST 30","BIST 50","BIST 100","BIST 500"};
        for(String c:cats){
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(9),dp(10),dp(9));row.setBackground(bg(SURFACE2,13));
            TextView t=tv(c,15,TEXT);t.setTypeface(null,Typeface.BOLD);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(tv("›",24,MUTED));
            row.setOnClickListener(v->showMarketIndex(c));
            parent.addView(row,new LinearLayout.LayoutParams(-1,dp(52)));spacerIn(parent,6);
        }
    }

    void addRiskButtons(LinearLayout parent,String index){
        TextView title=tv(index+" • risk filtreleri",14,TEXT);title.setTypeface(null,Typeface.BOLD);parent.addView(title);
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout r=new LinearLayout(this);
        String[] rs={"Tümü","Düşük Risk","Orta Risk","Yüksek Risk"};
        for(String x:rs){Button b=chip(x,(x.equals("Tümü")&&riskFilter.isEmpty())||x.equals(riskFilter));b.setOnClickListener(v->{riskFilter="Tümü".equals(x)?"":x;listLimit=20;renderList();});r.addView(b,new LinearLayout.LayoutParams(-2,dp(40)));spaceH(r,6);}
        hs.addView(r);parent.addView(hs);
    }


    void showMarket(){
        screen=Screen.MARKET;selectNav("Piyasa");marketCategory="POPULAR 20";riskFilter="";listLimit=20;clear();
        content.addView(tv("Piyasa",27,TEXT));
        content.addView(tv("İlk ekran: günün aktif/popüler 20 hissesi • kategori seçince ayrı endeks sayfası",12,MUTED));
        spacer(8);
        buildSearch();
        LinearLayout indexBox=card();
        indexBox.addView(tv("Endeksler",16,TEXT));
        addCategoryButtons(indexBox);
        content.addView(indexBox);spacer(8);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);
        Button scan=action("🤖 AI Tarama",BLUE);scan.setOnClickListener(v->startScan());tools.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(tools,8);
        Button refresh=chip("↻ Yenile",false);refresh.setOnClickListener(v->data.refresh());tools.addView(refresh,new LinearLayout.LayoutParams(dp(110),dp(44)));
        content.addView(tools);
        scanStatus=tv("AI tarama: hazır",10,MUTED);content.addView(scanStatus);spacer(8);
        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }

    void showMarketIndex(String index){
        screen=Screen.MARKET;selectNav("Piyasa");marketCategory=index;listLimit=20;clear();
        content.addView(tv(index,27,TEXT));
        content.addView(tv(MarketGroups.count(this,index)+" üyelik • bu sayfaya özel risk filtreleri",12,MUTED));
        spacer(8);
        buildSearch();
        LinearLayout risk=card();addRiskButtons(risk,index);content.addView(risk);spacer(8);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);
        Button scan=action("🤖 Bu endeksi tara",BLUE);scan.setOnClickListener(v->startScan());tools.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(tools,8);
        Button home=chip("Piyasa ana sayfa",false);home.setOnClickListener(v->showMarket());tools.addView(home,new LinearLayout.LayoutParams(dp(130),dp(44)));
        content.addView(tools);scanStatus=tv("AI tarama: hazır",10,MUTED);content.addView(scanStatus);spacer(8);
        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }

    void showWatchlist(){screen=Screen.WATCH;selectNav("Takip");marketCategory="Takip";riskFilter="";clear();content.addView(tv("Takip",27,TEXT));content.addView(tv("Yıldızladığın hisseler",12,MUTED));spacer(10);buildSearch();listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();}
    void buildSearch(){search=new EditText(this);search.setSingleLine(true);search.setHint("BIST'te ara: THYAO, ASELS, şirket adı...");search.setHintTextColor(MUTED);search.setTextColor(TEXT);search.setTextSize(13);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(SURFACE2,14));content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){listLimit=60;renderList();}public void afterTextChanged(Editable e){}});spacer(8);}

    void chooseSort(Button b){String[] ops={"Sinyal","Günlük %","Hacim","Skor","Fiyat"};new AlertDialog.Builder(this).setTitle("Sıralama").setItems(ops,(d,w)->{sort=ops[w];b.setText("Sıralama: "+sort);renderList();}).show();}

    void renderList(){
        if(listHost==null)return;listHost.removeAllViews();
        List<Stock> list=new ArrayList<>(all);
        String q=search==null?"":search.getText().toString().trim().toUpperCase(Locale.US);
        if(!q.isEmpty()) list.removeIf(x->!x.symbol.contains(q)&&!x.name.toUpperCase(Locale.US).contains(q));
        if("Takip".equals(marketCategory)) list.removeIf(x->!isFavorite(x.symbol));
        else if(marketCategory.startsWith("BIST")) list.removeIf(x->!MarketGroups.matches(this,marketCategory,x));
        if(!riskFilter.isEmpty()) list.removeIf(x->!riskFilter.equals(x.risk));

        if("POPULAR 20".equals(marketCategory) && q.isEmpty()){
            list.sort(Comparator.comparingDouble((Stock x)->-x.volume));
        }else{
            Comparator<Stock> cmp=Comparator.comparingDouble((Stock x)->x.analysisReady?-x.score:999999);
            if(sort.equals("Günlük %"))cmp=Comparator.comparingDouble(x->-x.changePct);
            if(sort.equals("Hacim"))cmp=Comparator.comparingDouble(x->-x.volume);
            if(sort.equals("Fiyat"))cmp=Comparator.comparingDouble(x->x.price<=0?Double.MAX_VALUE:x.price);
            list.sort(cmp);
        }

        int total=list.size();
        int preview=Math.min(listLimit,total);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(tv(total+" sonuç",11,MUTED),new LinearLayout.LayoutParams(0,-2,1));
        head.addView(tv("Gösterilen "+preview,10,live?GREEN:YELLOW));
        listHost.addView(head);spacerIn(listHost,6);
        if(list.isEmpty()){LinearLayout e=card();e.addView(tv("Hisse bulunamadı",15,TEXT));e.addView(tv(q.isEmpty()?"Bu filtreden geçen veri yok.":"Aramayı sembol veya şirket adıyla daralt.",11,MUTED));listHost.addView(e);return;}
        int shown=Math.min(listLimit,list.size());
        for(int i=0;i<shown;i++)listHost.addView(stockRow(list.get(i)));
        if(shown<list.size()){Button more=chip("Daha fazla göster • "+shown+" / "+list.size(),false);more.setOnClickListener(v->{listLimit=Math.min(listLimit+20,list.size());renderList();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(8);listHost.addView(more,lp);}
    }

    View stockRow(Stock s){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(8),dp(8),dp(8));row.setBackground(bg(SURFACE,14));
        TextView star=tv(isFavorite(s.symbol)?"★":"☆",22,isFavorite(s.symbol)?YELLOW:MUTED);star.setGravity(Gravity.CENTER);star.setOnClickListener(v->{toggleFavorite(s.symbol);renderList();});row.addView(star,new LinearLayout.LayoutParams(dp(28),dp(72)));
        LinearLayout name=new LinearLayout(this);name.setOrientation(LinearLayout.VERTICAL);
        TextView sy=tv(s.symbol,14,TEXT);sy.setTypeface(null,Typeface.BOLD);
        TextView nm=tv(s.name.isEmpty()?s.symbol:s.name,9,MUTED);nm.setSingleLine(true);nm.setEllipsize(TextUtils.TruncateAt.END);name.addView(sy);name.addView(nm);
        if(s.analysisReady)name.addView(tv(s.conditionsMet+"/"+s.conditionsTotal+" teyit • "+s.risk,9,CYAN));else name.addView(tv("Detayda çoklu vade analizi",9,MUTED));
        row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT);
        right.addView(tv(s.price>0?formatPrice(s.price):"—",14,TEXT));
        right.addView(tv(s.price>0?String.format(Locale.US,"%+.2f%%",s.changePct):"—",10,s.changePct>=0?GREEN:RED));
        if(s.analysisReady)right.addView(pill(s.signal,s.signal.equals("AL")?GREEN:s.signal.equals("SAT")?RED:YELLOW),new LinearLayout.LayoutParams(dp(70),dp(28)));
        row.addView(right,new LinearLayout.LayoutParams(dp(88),-2));
        row.setOnClickListener(v->openDetailFromCurrentScreen(s));return row;
    }


    void startScan(){
        if(all.isEmpty()){toast("Önce fiyat verisini yenile");return;}
        final ArrayList<String> symbols=new ArrayList<>();String q=search==null?"":search.getText().toString().trim();
        if(!q.isEmpty()){for(Stock x:all)if(x.symbol.equalsIgnoreCase(q)||x.name.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT)))symbols.add(x.symbol);}
        if(symbols.isEmpty()){
            for(Stock x:all){
                boolean ok;
                if("Takip".equals(marketCategory))ok=isFavorite(x.symbol);
                else if(marketCategory.startsWith("BIST"))ok=MarketGroups.matches(this,marketCategory,x);
                else if("POPULAR 20".equals(marketCategory))ok=true;
                else ok=false;
                if(!riskFilter.isEmpty())ok=ok&&riskFilter.equals(x.risk);
                if(ok)symbols.add(x.symbol);
            }
            if("POPULAR 20".equals(marketCategory)){symbols.sort((a,b)->Double.compare(volumeOf(b),volumeOf(a)));if(symbols.size()>20)symbols.subList(20,symbols.size()).clear();}
        }
        if(symbols.isEmpty()){toast("Tarama listesi boş");return;}
        if(scanStatus!=null)scanStatus.setText("AI tarama başladı: 0/"+symbols.size());
        history.scan(symbols,"1Y","Dengeli",new HistoryService.ScanListener(){public void onScanProgress(int done,int total,Stock st){Stock target=find(st.symbol);if(target!=null&&st.analysisReady){double livePrice=target.price;copyAnalysis(st,target);if(livePrice>0)target.price=livePrice;}if(scanStatus!=null)scanStatus.setText("AI tarama: "+done+"/"+total);if(listHost!=null)renderList();}
            public void onScanFinished(int done,int total){if(scanStatus!=null)scanStatus.setText("AI tarama tamamlandı: "+total+" hisse");signals.recordTransitions(all);renderList();}});
    }

    double volumeOf(String sym){Stock x=find(sym);return x==null?0:x.volume;}


    void showDetail(Stock s){
        if(s==null)return;screen=Screen.DETAIL;current=s;clear();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        Button back=chip("‹ Geri",false);back.setOnClickListener(v->returnFromDetail());top.addView(back,new LinearLayout.LayoutParams(dp(78),dp(40)));
        LinearLayout title=new LinearLayout(this);title.setOrientation(LinearLayout.VERTICAL);TextView head=tv(s.symbol,21,TEXT);head.setTypeface(null,Typeface.BOLD);title.addView(head);
        TextView full=tv((s.name.isEmpty()?s.symbol:s.name).toUpperCase(new Locale("tr","TR")),12,MUTED);full.setSingleLine(true);full.setEllipsize(TextUtils.TruncateAt.END);title.addView(full);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=tv(isFavorite(s.symbol)?"★":"☆",25,isFavorite(s.symbol)?YELLOW:MUTED);fav.setGravity(Gravity.CENTER);fav.setOnClickListener(v->{toggleFavorite(s.symbol);showDetail(find(s.symbol));});top.addView(fav,new LinearLayout.LayoutParams(dp(45),dp(50)));content.addView(top);
        content.addView(tv("Sektör: "+(s.sector.isEmpty()?"BIST Hisse":s.sector),10,MUTED));spacer(8);

        LinearLayout quote=card();LinearLayout qr=new LinearLayout(this);qr.setGravity(Gravity.CENTER_VERTICAL);
        detailPriceView=tv(s.price>0?formatPrice(s.price):"—",29,TEXT);detailPriceView.setTypeface(null,Typeface.BOLD);qr.addView(detailPriceView,new LinearLayout.LayoutParams(0,-2,1));
        qr.addView(pill(s.analysisReady?s.signal:"ÇOKLU ANALİZ",s.analysisReady?(s.signal.equals("AL")?GREEN:s.signal.equals("SAT")?RED:YELLOW):SURFACE2),new LinearLayout.LayoutParams(dp(120),dp(34)));
        quote.addView(qr);
        detailQuoteMeta=tv(s.price>0?String.format(Locale.US,"%+.2f%% bugün • canlı fiyat dahil",s.changePct):"Canlı fiyat bekleniyor…",11,s.changePct>=0?GREEN:MUTED);quote.addView(detailQuoteMeta);
        content.addView(quote);spacer(10);

        LinearLayout hz=card();hz.addView(tv("Vade bazlı analiz",16,TEXT));hz.addView(tv("Her vade kendi geçmiş dönemini kullanır; canlı fiyat son kapanışa ayrıca uygulanır.",10,MUTED));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);
        for(String h:new String[]{HorizonAnalysis.LONG,HorizonAnalysis.MEDIUM,HorizonAnalysis.SHORT}){Button b=chip(h,h.equals(detailHorizon));b.setOnClickListener(v->{detailHorizon=h;renderDetailHorizon();});r.addView(b,new LinearLayout.LayoutParams(-2,dp(42)));spaceH(r,6);}hs.addView(r);hz.addView(hs);content.addView(hz);spacer(8);
        detailHorizonHost=new LinearLayout(this);detailHorizonHost.setOrientation(LinearLayout.VERTICAL);content.addView(detailHorizonHost);
        renderDetailHorizon();

        LinearLayout overall=card();overall.addView(tv("3 vadenin özeti",16,TEXT));
        addHorizonSummaryRow(overall, HorizonAnalysis.LONG, "Yıllık", "1Y");
        addHorizonSummaryRow(overall, HorizonAnalysis.MEDIUM, "Aylık", "1A");
        addHorizonSummaryRow(overall, HorizonAnalysis.SHORT, "Kısa", "5-20G");
        overall.addView(tv("Canlı fiyat etkisi yalnızca bu hisse detay ekranında uygulanır. Veri güncellemesi geçmiş günlük veriyi baştan indirmek yerine önceden yüklenen 3 yıllık veriyi yerelde değerlendirir.",9,MUTED));
        content.addView(overall);spacer(10);

        LinearLayout actions=card();actions.addView(tv("İşlemler",16,TEXT));LinearLayout ab=new LinearLayout(this);Button buy=action("SANAL AL",GREEN),sell=action("SANAL SAT",RED),alarm=action("FİYAT ALARMI",BLUE);ab.addView(buy,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(ab,6);ab.addView(sell,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(ab,6);ab.addView(alarm,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(ab);
        EditText qty=new EditText(this);qty.setSingleLine(true);qty.setText("1");qty.setInputType(2);qty.setTextColor(TEXT);qty.setBackground(bg(SURFACE2,12));actions.addView(qty,new LinearLayout.LayoutParams(-1,dp(44)));buy.setOnClickListener(v->tradeNow(s.symbol,qty,true));sell.setOnClickListener(v->tradeNow(s.symbol,qty,false));alarm.setOnClickListener(v->setPriceAlert(s));content.addView(actions);spacer(10);

        LinearLayout more=card();more.addView(tv("Araçlar",16,TEXT));Button hist=action("Grafik & Geçmiş",BLUE);hist.setOnClickListener(v->showHistory(s));more.addView(hist);Button bt=action("Backtest çalıştır",SURFACE2);bt.setOnClickListener(v->showBacktest(s));more.addView(bt);Button cmp=action(compareSet.contains(s.symbol)?"Karşılaştırmadan çıkar":"Karşılaştırmaya ekle",SURFACE2);cmp.setOnClickListener(v->{if(compareSet.contains(s.symbol))compareSet.remove(s.symbol);else if(compareSet.size()<3)compareSet.add(s.symbol);else {toast("En fazla 3 hisse karşılaştırılabilir");return;}showDetail(s);});more.addView(cmp);content.addView(more);spacer(10);

        LinearLayout newsBox=card();newsBox.addView(tv("Haberler / KAP",16,TEXT));detailNewsList=new LinearLayout(this);detailNewsList.setOrientation(LinearLayout.VERTICAL);newsBox.addView(detailNewsList);content.addView(newsBox);news.refresh(s.symbol);

        // Only one stock-history request is made on detail entry. The 3Y data is sliced locally
        // into long/medium/short windows, which keeps the screen responsive and reduces traffic.
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){public void onBenchmarkReady(List<Candle> b,String src,String msg){detailBenchmarkBars=new ArrayList<>(b);if(!detailHistoryBars.isEmpty())computeDetailHorizons(s.symbol,src);renderDetailHorizon();}});
        history.load(s.symbol,"3Y",this);
    }

    void addHorizonSummaryRow(LinearLayout host,String horizon,String label,String code){
        HorizonAnalysis.Result x=horizonResults.get(horizon);
        String text=label+" • "+(x==null||!x.ready?"Hazırlanıyor":x.signal+" • "+String.format(Locale.US,"%.0f/100",x.score)+" • dönem "+String.format(Locale.US,"%+.1f%%",x.periodReturnPct)+" • hedef baz "+String.format(Locale.US,"%+.1f%%",x.upsidePct)));
        TextView t=tv(text,11,TEXT);
        host.addView(t);
        t.setPadding(dp(4),dp(6),dp(4),dp(6));
    }

    void renderDetailHorizon(){
        if(detailHorizonHost==null)return;
        detailHorizonHost.removeAllViews();
        HorizonAnalysis.Result r=horizonResults.get(detailHorizon);
        if(r==null||!r.ready){detailHorizonHost.addView(tv("Geçmiş veri yükleniyor…",12,MUTED));return;}

        LinearLayout c=card();
        TextView big=tv(r.signal,r.signal.equals("AL")?22:r.signal.equals("SAT")?22:20,r.signal.equals("AL")?GREEN:r.signal.equals("SAT")?RED:YELLOW);big.setTypeface(null,Typeface.BOLD);c.addView(big);
        c.addView(tv(r.strength+" • Teknik puan "+String.format(Locale.US,"%.0f/100",r.score)+" • Güven "+String.format(Locale.US,"%.0f/100",r.confidence),11,TEXT));
        c.addView(tv(r.periodLabel+" • "+r.conditionsMet+"/"+r.conditionsTotal+" teknik teyit • Risk: "+r.risk+" • Trend: "+r.trend,10,CYAN));
        c.addView(tv("Dönem getirisi: "+String.format(Locale.US,"%+.2f%%",r.periodReturnPct)+" • Canlı fiyat: "+formatPrice(r.livePrice)+" • Son kapanış: "+formatPrice(r.historicalLast)+" • Tepki: "+String.format(Locale.US,"%+.2f%%",r.liveReactionPct)+" • Canlı etki: "+String.format(Locale.US,"%+.0f",r.liveScoreAdjustment),10,MUTED));
        c.addView(tv(r.reason,10,MUTED));

        LinearLayout targets=card();targets.setPadding(dp(12),dp(12),dp(12),dp(12));targets.addView(tv("Model fiyat potansiyeli",15,TEXT));
        targets.addView(tv("Alt band   "+formatPrice(r.modelLow),11,TEXT));
        targets.addView(tv("Baz hedef  "+formatPrice(r.modelBase)+"   ("+String.format(Locale.US,"%+.1f%%",r.upsidePct)+")",12,TEXT));
        targets.addView(tv("Üst band   "+formatPrice(r.modelHigh)+"   ("+String.format(Locale.US,"%+.1f%%",r.upsideHighPct)+")",11,TEXT));
        if(r.support>0)targets.addView(tv("Destek: "+formatPrice(r.support)+(r.resistance>0?" • Direnç: "+formatPrice(r.resistance):""),10,MUTED));
        if(r.entryLow>0 && r.entryHigh>0)targets.addView(tv("Canlı giriş bölgesi: "+formatPrice(r.entryLow)+" – "+formatPrice(r.entryHigh),10,MUTED));
        if(r.stop>0)targets.addView(tv("Teknik stop: "+formatPrice(r.stop)+" • T1: "+formatPrice(r.target1)+" • T2: "+formatPrice(r.target2),10,MUTED));
        targets.addView(tv("Bu hedefler uygulamanın teknik model bantlarıdır; TradingView'deki analist konsensüsü gibi dış kurum tahmini değildir.",9,MUTED));
        detailHorizonHost.addView(c);spacerIn(detailHorizonHost,8);detailHorizonHost.addView(targets);
    }

    void addSignalCard(Stock s){LinearLayout c=card();c.addView(tv("AI SİNYALİ",16,TEXT));if(!s.analysisReady){c.addView(tv("Geçmiş tam OHLCV verisi gelmeden sinyal üretilmez.",11,MUTED));}else{TextView big=tv(s.signal,s.signal.equals("AL")?21:s.signal.equals("SAT")?21:19,s.signal.equals("AL")?GREEN:s.signal.equals("SAT")?RED:YELLOW);big.setTypeface(null,Typeface.BOLD);c.addView(big);c.addView(tv(AnalysisEngine.conditionSummary(s),11,TEXT));c.addView(tv("Kurulum: "+s.setupType+" • Haftalık: "+s.stage+" • Piyasa: "+s.marketRegime,11,TEXT));c.addView(tv(String.format(Locale.US,"ADX %.1f • +DI %.1f / -DI %.1f • RS(BIST100) %+.1f%% • Günlük gap %+.1f%%",s.adx,s.diPlus,s.diMinus,s.relativeStrengthPct,s.dailyGapPct),10,MUTED));c.addView(tv("Hacim oranı: "+String.format(Locale.US,"%.2fx",s.volumeRatio)+" • OBV: "+String.format(Locale.US,"%+.1f%%",s.obvSlopePct)+" • "+(s.distributionFlag?"Dağıtım baskısı tespit edildi":"Dağıtım baskısı yok")+" • "+(s.volatilityShock?"Volatilite şoku":"Volatilite normal"),10,MUTED));c.addView(tv("Strateji: "+strategy,10,MUTED));c.addView(tv(s.reason,10,MUTED));c.addView(tv("Yönetim: "+s.management,10,MUTED));}content.addView(c);}
    void addPricePlanCard(Stock s){LinearLayout c=card();c.addView(tv("Fiyat planı",16,TEXT));if(!s.analysisReady){c.addView(tv("Analiz hazır olduğunda giriş, zarar durdur ve hedef seviyeleri burada görünür.",11,MUTED));}else{c.addView(metricLine("Önerilen giriş aralığı",s.entryLow,s.entryHigh));c.addView(metricLine("Zarar durdur",s.stopPrice));c.addView(metricLine("Hedef 1 • %50",s.targetPrice));c.addView(metricLine("Hedef 2 • kalan",s.targetPrice2));c.addView(metricLine("ATR trailing stop",s.trailingStop));c.addView(tv(String.format(Locale.US,"Stop riski %.2f%% • R/R T1 %.2f • T2 %.2f",s.stopPct,s.rr1,s.rr2),10,MUTED));c.addView(tv(String.format(Locale.US,"Model pozisyon boyutu: %d adet • ≈ %%%.1f nominal",s.suggestedQty,s.suggestedPositionPct),10,MUTED));c.addView(tv("Giriş bölgesi: "+(s.entryZoneOk?"uygun":"bekle/kovalama yapma")+" • Plan: "+s.management,10,MUTED));c.addView(tv("Güvenlik: "+s.safety,10,MUTED));c.addView(tv("Bunlar algoritmik seviyelerdir; kesin emir veya getiri garantisi değildir. İşlem sinyali oluşsa bile emir gerçekleşme fiyatı farklı olabilir.",9,MUTED));}content.addView(c);}
    TextView metricLine(String label,double val){return tv(label+"   "+formatPrice(val),12,TEXT);}
    TextView metricLine(String label,double a,double b){return tv(label+"   "+formatPrice(a)+" – "+formatPrice(b),12,TEXT);}

    void showHistory(Stock s){if(s==null)return;screen=Screen.HISTORY;current=s;clear();content.addView(tv(s.symbol+" • Grafik & Geçmiş",25,TEXT));content.addView(tv("Günlük OHLCV • mum/çizgi • dokunarak tarih ve kapanış",11,MUTED));spacer(8);LinearLayout modes=new LinearLayout(this);Button mum=chip("Mum",historyMode.equals("Mum")),line=chip("Çizgi",historyMode.equals("Çizgi"));modes.addView(mum,new LinearLayout.LayoutParams(0,dp(40),1));spaceH(modes,6);modes.addView(line,new LinearLayout.LayoutParams(0,dp(40),1));content.addView(modes);mum.setOnClickListener(v->{historyMode="Mum";historyChart.setMode(HistoryChartView.Mode.CANDLE);});line.setOnClickListener(v->{historyMode="Çizgi";historyChart.setMode(HistoryChartView.Mode.LINE);});spacer(8);
        LinearLayout ranges=card();ranges.addView(tv("Dönem",15,TEXT));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);for(String x:new String[]{"1A","3A","6A","1Y","3Y","5Y"}){Button b=chip(x,x.equals(historyRange));r.addView(b,new LinearLayout.LayoutParams(-2,dp(38)));spaceH(r,5);b.setOnClickListener(v->{historyRange=x;history.load(s.symbol,x,this);});}hs.addView(r);ranges.addView(hs);content.addView(ranges);spacer(8);
        historyChart=new HistoryChartView(this);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);content.addView(historyChart,new LinearLayout.LayoutParams(-1,dp(355)));historyInfo=tv("Geçmiş veri yükleniyor…",10,MUTED);content.addView(historyInfo);history.load(s.symbol,historyRange,this);
    }

    void showBacktest(Stock s){
        if(s==null)return;
        screen=Screen.BACKTEST;
        selectNav("Piyasa");
        clear();
        content.addView(tv(s.symbol+" • Backtest",25,TEXT));
        content.addView(tv("Aynı sinyal motorunu geçmiş günlük veride sınar",11,MUTED));
        spacer(10);
        TextView info=tv("Dönem: 3Y • başlangıç 100.000 ₺ • komisyon %0,20 • tahmini kayma %0,05/yan • T1 %50 + trailing",11,MUTED);
        content.addView(info);
        spacer(8);
        Button run=action("Backtesti çalıştır",BLUE);
        content.addView(run);
        LinearLayout box=card();
        box.addView(tv("Sonuç",16,TEXT));
        box.addView(tv("Henüz çalıştırılmadı.",11,MUTED));
        content.addView(box);
        run.setOnClickListener(v->runBacktest(s,box));
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){
            public void onBenchmarkReady(List<Candle> b,String src,String msg){
                history.load(s.symbol,"3Y",new HistoryService.Listener(){
                    public void onHistory(String sym,String range,List<Candle> bars,String source,String msg2){
                        if(bars.size()>=35){
                            info.setText("Dönem: "+bars.size()+" günlük veri • kaynak: "+source+" • %0,20 komisyon • tahmini kayma %0,05/yan • benchmark "+(b.isEmpty()?"yok":"XU100"));
                        } else info.setText(msg2);
                    }
                });
            }
        });
    }

    void runBacktest(Stock s,LinearLayout box){
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){
            public void onBenchmarkReady(List<Candle> bench,String bs,String bm){
                history.load(s.symbol,"3Y",new HistoryService.Listener(){
                    public void onHistory(String sym,String range,List<Candle> bars,String source,String msg){
                        box.removeAllViews();
                        if(bars.size()<AnalysisEngine.MIN_DEEP_BARS+2||!AnalysisEngine.hasFullOhlcv(bars)){
                            box.addView(tv("Backtest için yeterli tam OHLCV veri yok.",12,MUTED));
                            return;
                        }
                        BacktestEngine.Result r=BacktestEngine.run(bars,strategy,bench);
                        box.addView(tv(String.format(Locale.US,"Başlangıç %.2f ₺",r.startCash),12,TEXT));
                        box.addView(tv(String.format(Locale.US,"Bitiş %.2f ₺",r.endCash),20,TEXT));
                        box.addView(tv(String.format(Locale.US,"Getiri %+.2f%%",r.returnPct),14,r.returnPct>=0?GREEN:RED));
                        box.addView(tv("İşlem "+r.trades+" • Kazanan "+r.wins+" • Kaybeden "+r.losses,12,TEXT));
                        box.addView(tv(String.format(Locale.US,"Kazanma %.1f%% • Maks. düşüş %.1f%% • Kâr faktörü %.2f",r.winRate,r.maxDrawdownPct,r.profitFactor),11,MUTED));
                        box.addView(tv(String.format(Locale.US,"T1 %d • T2 %d • Stop %d • Sinyal çıkışı %d • Atlanan %d",r.target1Hits,r.target2Hits,r.stopHits,r.signalExits,r.skippedPlans),11,TEXT));
                        box.addView(tv(String.format(Locale.US,"Ortalama kazanç %+.2f%% • Ortalama kayıp -%.2f%% • Beklenti %+.2f%% • Max ardışık kayıp %d",r.avgWinPct,r.avgLossPct,r.expectancyPct,r.maxConsecutiveLosses),11,MUTED));
                        if(!bench.isEmpty())box.addView(tv("Piyasa filtresi: XU100 kullanıldı • "+bs,10,MUTED));
                        for(int i=Math.max(0,r.log.size()-10);i<r.log.size();i++)box.addView(tv(r.log.get(i),10,TEXT));
                    }
                });
            }
        });
    }

    void showCompare(){screen=Screen.COMPARE;selectNav("Ana");clear();content.addView(tv("Hisse karşılaştırma",25,TEXT));content.addView(tv("En fazla 3 hisse",11,MUTED));spacer(10);if(compareSet.isEmpty()){content.addView(tv("Henüz hisse seçilmedi.",12,MUTED));content.addView(tv("Bir hissenin detayında “Karşılaştırmaya ekle” butonunu kullan.",11,MUTED));return;}for(String sym:compareSet){Stock s=find(sym);if(s==null)continue;LinearLayout c=card();c.addView(tv(sym+" • "+formatPrice(s.price),16,TEXT));c.addView(tv("Sinyal: "+(s.analysisReady?s.signal:"BEKLE")+" • RSI "+String.format(Locale.US,"%.1f",s.rsi)+" • MACD "+(s.macd>s.macdSignal?"✓":"—"),11,MUTED));c.addView(tv("EMA20/50 "+(s.ema20>s.ema50?"✓":"—")+" • Trend "+s.trend+" • Hacim "+String.format(Locale.US,"%.2fx",s.volumeRatio),11,TEXT));content.addView(c);spacer(6);}}

    void showSignals(){
        screen=Screen.SIGNALS;clear();content.addView(tv("Sinyal geçmişi",25,TEXT));content.addView(tv("Sinyal değişimleri ve bugünkü fiyata göre görünüm",11,MUTED));spacer(10);
        JSONArray a=signals.history();
        if(a.length()==0){content.addView(tv("Henüz kayıt yok. Önce AI Tarama çalıştır.",12,MUTED));return;}
        int al=0,sat=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String n=o.optString("new");if("AL".equals(n))al++;if("SAT".equals(n))sat++;}
        LinearLayout summary=card();summary.addView(tv("Özet",16,TEXT));summary.addView(tv("Toplam "+a.length()+" değişim • AL "+al+" • SAT "+sat,12,TEXT));content.addView(summary);spacer(8);
        for(int i=a.length()-1;i>=0;i--){JSONObject o=a.optJSONObject(i);if(o==null)continue;String sym=o.optString("symbol");double px=o.optDouble("price",0),now=find(sym)!=null?find(sym).price:0,perf=0;if(px>0&&now>0)perf="AL".equals(o.optString("new"))?(now/px-1)*100:(px/now-1)*100;LinearLayout c=card();c.addView(tv(sym+" • "+o.optString("new"),15,TEXT));c.addView(tv(formatPrice(px)+" • "+o.optInt("met")+"/"+AnalysisEngine.TOTAL_CONDITIONS+" koşul • "+time(o.optLong("time")),10,MUTED));if(now>0)c.addView(tv(String.format(Locale.US,"Sinyal fiyatından bugüne: %+.2f%%",perf),10,perf>=0?GREEN:RED));content.addView(c);spacer(6);}
    }

    void showPortfolio(){screen=Screen.PORTFOLIO;selectNav("Portföy");clear();content.addView(tv("Sanal portföy",27,TEXT));content.addView(tv("100.000 ₺ başlangıç • komisyon dahil",11,MUTED));spacer(10);double value=portfolioValue();LinearLayout box=card();box.addView(tv("Toplam değer",11,MUTED));box.addView(tv(String.format(Locale.US,"%.2f ₺",value),27,TEXT));box.addView(tv(String.format(Locale.US,"K/Z %+.2f ₺",value-100000),13,value>=100000?GREEN:RED));box.addView(tv(String.format(Locale.US,"Nakit %.2f ₺ • Komisyon %.2f%%",portfolio.cash(),.2),10,MUTED));content.addView(box);spacer(10);LinearLayout pos=card();pos.addView(tv("Pozisyonlar",16,TEXT));boolean any=false;for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);if(q<=0)continue;any=true;Stock s=find(sym);double px=s!=null?s.price:0, avg=portfolio.avgCost(sym), pnl=avg>0?(px-avg)*q:0;pos.addView(tv(String.format(Locale.US,"%s • %d adet • değer %.2f ₺ • K/Z %+.2f ₺",sym,q,px*q,pnl),12,TEXT));}if(!any)pos.addView(tv("Henüz pozisyon yok.",11,MUTED));content.addView(pos);spacer(8);LinearLayout tr=card();tr.addView(tv("Son işlemler",16,TEXT));JSONArray a=portfolio.tradeHistory();if(a.length()==0)tr.addView(tv("İşlem geçmişi boş.",11,MUTED));else for(int i=a.length()-1;i>=0&&i>=a.length()-8;i--){JSONObject o=a.optJSONObject(i);tr.addView(tv(o.optString("symbol")+" "+o.optString("side")+" "+o.optInt("qty")+" @ "+formatPrice(o.optDouble("price"))+" • komisyon "+formatPrice(o.optDouble("fee")),10,TEXT));}content.addView(tr);spacer(8);Button reset=action("Portföyü sıfırla",YELLOW);reset.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Portföy sıfırlansın mı?").setMessage("100.000 ₺ ile yeniden başlatılacak.").setNegativeButton("Vazgeç",null).setPositiveButton("Sıfırla",(d,w)->{portfolio.reset();showPortfolio();}).show();});content.addView(reset);}
    double portfolioValue(){double v=portfolio.cash();for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);Stock s=find(sym);if(s!=null&&s.price>0)v+=s.price*q;}return v;}

    void showLearning(){
        screen=Screen.SIGNALS;selectNav("Ayar");clear();content.addView(tv("AI Öğrenme Motoru",27,TEXT));content.addView(tv("Hataları ölçer • yeni kuralları gölgede test eder • doğrulanmayan değişikliği aktif etmez",11,MUTED));spacer(10);
        LearningEngine.Report r=LearningEngine.learn(learning);LinearLayout box=card();box.addView(tv("Durum",16,TEXT));box.addView(tv(r.status,13,r.status.contains("aktif")?GREEN:YELLOW));box.addView(tv(String.format(Locale.US,"Toplam sonuç: %d • Kazanan: %d • Kaybeden: %d",r.samples,r.wins,r.losses),11,TEXT));box.addView(tv(String.format(Locale.US,"Mevcut profil: %s • Öğrenilmiş ağırlıklar 0,75–1,25 aralığında",learning.active()?"AKTİF":"PASİF",r.weights.toString()),10,MUTED));box.addView(tv(String.format(Locale.US,"Gözlem win rate: %.1f%% • Gözlem beklenti: %+.2f%%",r.baselineWinRate,r.baselineExpectancy),11,TEXT));content.addView(box);spacer(8);
        LinearLayout fs=card();fs.addView(tv("Koşul öğrenme istatistikleri",16,TEXT));for(String k:r.featureStats.keySet())fs.addView(tv(k.toUpperCase(Locale.US)+"  •  "+r.featureStats.get(k),11,TEXT));content.addView(fs);spacer(8);
        PredictionStore.Report pr=new PredictionStore(this).report();LinearLayout pred=card();pred.addView(tv("Sürekli sanal tahmin hafızası",16,TEXT));pred.addView(tv(String.format(Locale.US,"Açık %d • Sonuçlanan %d • Pozitif %d • Negatif %d • Başarı %.1f%%",pr.open,pr.closed,pr.wins,pr.losses,pr.winRate),11,TEXT));long lm=new PredictionStore(this).lastMonitor();pred.addView(tv("Son derin tarama: "+(lm>0?time(lm):"henüz yok")+" • "+new PredictionStore(this).monitorStatus(),10,MUTED));if(!pr.reasons.isEmpty()){pred.addView(tv("En sık başarısızlık nedenleri",13,TEXT));ArrayList<Map.Entry<String,Integer>> entries=new ArrayList<>(pr.reasons.entrySet());entries.sort((a,b)->Integer.compare(b.getValue(),a.getValue()));for(int i=0;i<Math.min(6,entries.size());i++){Map.Entry<String,Integer> e=entries.get(i);pred.addView(tv("• "+e.getKey()+" — "+e.getValue()+" kez",10,TEXT));}}content.addView(pred);spacer(8);
        LinearLayout info=card();info.addView(tv("Nasıl öğreniyor?",16,TEXT));info.addView(tv("1) AI taraması tüm BIST kataloğundaki günlük veriyi toplar.\n2) Kullanıcı yatırım yapmasa da AL kurulumlarını sanal tahmin olarak kaydeder.\n3) Sonraki OHLCV hareketiyle stop, T1, T2 veya süre dolumu sonucunu etiketler.\n4) Kaybın nedenini sınıflandırır ve bu sonucu öğrenme verisine ekler.\n5) Ağırlıkları sınırlı biçimde günceller; yeni profil güvenlik testini geçmezse eskisi korunur.",10,MUTED));content.addView(info);spacer(8);
        Button scan=action("Piyasayı tara + tahminleri değerlendir + öğren",BLUE);scan.setOnClickListener(v->{SelfLearningScheduler.runNow(this);toast("Arka plan öğrenme taraması kuyruğa alındı");showLearning();});content.addView(scan);
    }

    void showSettings(){screen=Screen.SETTINGS;selectNav("Ayar");clear();content.addView(tv("Ayarlar",27,TEXT));content.addView(tv("Veri, strateji, alarm ve uygulama davranışı",11,MUTED));spacer(10);LinearLayout c=card();c.addView(tv("Analiz stratejisi",16,TEXT));Spinner sp=new Spinner(this);String[] opts={"Dengeli","Trend","Momentum","Kısa Vadeli"};ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts){public View getView(int pos,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,v,parent);t.setTextColor(TEXT);t.setPadding(dp(8),0,dp(8),0);return t;}};sp.setAdapter(ad);sp.setSelection(Math.max(0,Arrays.asList(opts).indexOf(strategy)));c.addView(sp);content.addView(c);spacer(8);
        LinearLayout dataBox=card();dataBox.addView(tv("Veri bağlantısı",16,TEXT));dataBox.addView(tv("Varsayılan fiyat kaynağı: İş Yatırım halka açık hisse ekranı. Şirket adı/sektör/katalog da İş Yatırım veri tablosundan otomatik keşfedilir. Endeks üyelikleri ayrıca otomatik güncellenir. Çok kısa aralıklar kaynak tarafından sınırlandırılabilir.",10,MUTED));Switch alertsS=new Switch(this);alertsS.setText("AL/SAT sinyal değişim bildirimi");alertsS.setTextColor(TEXT);alertsS.setChecked(getSharedPreferences("settings",0).getBoolean("alerts",false));dataBox.addView(alertsS);
        EditText url=field("Harici Quote API URL (opsiyonel)",getSharedPreferences("settings",0).getString("base_url",""));EditText token=field("API Token (opsiyonel)",getSharedPreferences("settings",0).getString("token",""));EditText newsUrl=field("Haber/KAP JSON URL (opsiyonel)",getSharedPreferences("settings",0).getString("news_url",""));
        dataBox.addView(url);dataBox.addView(token);dataBox.addView(newsUrl);
        dataBox.addView(tv("Fiyat yenileme aralığı",12,TEXT));
        Spinner refreshSp=new Spinner(this);String[] refreshLabels={"1 sn","2 sn","3 sn","5 sn","10 sn","15 sn","20 sn","25 sn","30 sn","45 sn","60 sn","120 sn","300 sn"};int[] refreshValues={1,2,3,5,10,15,20,25,30,45,60,120,300};ArrayAdapter<String> rad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,refreshLabels){public View getView(int pos,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,v,parent);t.setTextColor(TEXT);t.setPadding(dp(8),0,dp(8),0);return t;}};refreshSp.setAdapter(rad);int savedRefresh=getSharedPreferences("settings",0).getInt("refresh_sec",30);int refreshPos=8;for(int i=0;i<refreshValues.length;i++)if(refreshValues[i]==savedRefresh){refreshPos=i;break;}refreshSp.setSelection(refreshPos);dataBox.addView(refreshSp);
        Switch learningS=new Switch(this);learningS.setText("Sürekli AI öğrenme (yatırım yapmasan bile)");learningS.setTextColor(TEXT);learningS.setChecked(getSharedPreferences("settings",0).getBoolean("self_learning",true));dataBox.addView(learningS);
        dataBox.addView(tv("Açıkken uygulama BIST kataloğunu arka planda periyodik olarak tarar. AL planlarını gerçek işlem yapmadan sanal tahmin olarak izler; stop/hedef sonuçlarını günlük OHLCV ile doğrular ve neden kaybettiğini sınıflandırıp öğrenme verisine ekler. Android arka plan kuralları nedeniyle bu derin tarama en erken yaklaşık 15 dk aralıklarla çalıştırılabilir; uygulama açıkken fiyat yenilemesi seçtiğin saniye aralığında devam eder.",10,MUTED));
        Button save=action("Kaydet ve yenile",GREEN);save.setOnClickListener(v->{strategy=opts[sp.getSelectedItemPosition()];int selectedRefresh=refreshValues[refreshSp.getSelectedItemPosition()];boolean sl=learningS.isChecked();getSharedPreferences("settings",0).edit().putBoolean("alerts",alertsS.isChecked()).putString("base_url",url.getText().toString().trim()).putString("token",token.getText().toString().trim()).putString("news_url",newsUrl.getText().toString().trim()).putInt("refresh_sec",selectedRefresh).putString("strategy",strategy).putBoolean("self_learning",sl).apply();if(sl)SelfLearningScheduler.schedule(this);else SelfLearningScheduler.cancel(this);toast("Ayarlar kaydedildi: "+selectedRefresh+" sn • AI öğrenme "+(sl?"AKTİF":"KAPALI"));restartRefresh();data.refresh();});dataBox.addView(save);content.addView(dataBox);spacer(8);LinearLayout research=card();research.addView(tv("Analiz motoru • araştırma temeli",16,TEXT));research.addView(tv("Tek indikatöre bağlı değildir. Haftalık trend/aşama filtresi, günlük momentum ve kurulum, hacim + OBV, ADX, BIST100 göreli güç, volatilite/sıkışma, destek-direnç, mum kalitesi, gap/uzama filtresi ve minimum R/R birlikte değerlendirilir.",10,MUTED));research.addView(tv("Plan yönetimi: yapısal stop + ATR, ilk hedef en az 2R, ikinci hedef en az 2,8R; T1'de kısmi kâr ve kalan pozisyonda izleyen stop. Veri eksikse plan üretilmez.",10,MUTED));research.addView(tv("Bu kuralların amacı hatalı işlemleri azaltmak ve backtest ile ölçülebilir bir disiplin oluşturmaktır; hiçbir yöntem gelecekteki sonucu garanti etmez.",10,MUTED));content.addView(research);spacer(8);LinearLayout learnBox=card();learnBox.addView(tv("🧠 Kendi hatalarından öğrenme",16,TEXT));learnBox.addView(tv("Sistem AI taramalarında gerçekleşmiş sinyal sonuçlarını toplar; RSI, MACD, EMA, hacim, trend, destek ve momentum koşullarının hangi kombinasyonlarda daha başarılı olduğunu ölçer. Yeni ağırlıklar sınırlandırılır ve eski profil ancak güvenlik testini geçerse değiştirilir.",10,MUTED));JSONObject lp=learning.profile();learnBox.addView(tv("Örnek sayısı: "+learning.sampleCount()+" • Profil sürümü: "+lp.optInt("version",0)+" • Son güncelleme: "+(learning.lastRun()>0?time(learning.lastRun()):"henüz yok"),10,TEXT));Button learnNow=action("Öğrenmeyi şimdi çalıştır",BLUE);learnNow.setOnClickListener(v->showLearning());learnBox.addView(learnNow);Button resetLearn=chip("Öğrenme profilini sıfırla",false);resetLearn.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("AI öğrenme sıfırlansın mı?").setMessage("Toplanan örnekler ve öğrenilmiş ağırlıklar silinecek. Analiz motoru nötr ağırlıklara dönecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sıfırla",(d,w)->{learning.clear();AnalysisEngine.setLearningStore(learning);showSettings();}).show());learnBox.addView(resetLearn);content.addView(learnBox);spacer(8);Button note=action("Bildirim iznini kontrol et",BLUE);note.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);else toast("Bildirim izni açık");});content.addView(note);spacer(8);content.addView(tv("Risk sınıfları göreli volatilite/likidite ölçümüdür. Garanti veya risksiz getiri anlamına gelmez.",10,MUTED));}
    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(bg(SURFACE2,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(7);e.setLayoutParams(lp);return e;}

    void setPriceAlert(Stock s){if(s==null||s.price<=0){toast("Fiyat verisi yok");return;}final EditText f=field("Hedef fiyat",formatPlain(s.price));new AlertDialog.Builder(this).setTitle(s.symbol+" fiyat alarmı").setView(f).setNegativeButton("Kapat",null).setPositiveButton("Kaydet",(d,w)->{double p=parseDouble(f.getText().toString(),0);if(p<=0){toast("Geçersiz fiyat");return;}alerts.set(s.symbol,p);toast("Alarm kaydedildi: "+formatPrice(p));}).setNeutralButton("Alarmı sil",(d,w)->{alerts.clear(s.symbol);toast("Alarm silindi");}).show();}
    void tradeNow(String sym,EditText q,boolean buy){int qty=parseInt(q.getText().toString(),0);if(qty<=0){toast("Geçerli adet gir");return;}Stock s=find(sym);if(s==null||s.price<=0){toast("Güncel fiyat yok");return;}boolean ok=buy?portfolio.buy(sym,s.price,qty):portfolio.sell(sym,s.price,qty);toast(ok?(buy?"Sanal alış yapıldı":"Sanal satış yapıldı"):"İşlem yapılamadı");if(ok)showDetail(s);}

    @Override public void onData(List<Stock> stocks,boolean isLive,String msg){
        HashMap<String,Double> oldPrices=new HashMap<>();for(Stock s:all)oldPrices.put(s.symbol,s.price);
        all.clear();all.addAll(stocks);if(isLive)getSharedPreferences("runtime",0).edit().putLong("last_update",System.currentTimeMillis()).apply();live=isLive;status.setText(isLive?"● VERİ BAĞLI":"● VERİ YOK");status.setTextColor(isLive?GREEN:YELLOW);statusMessage.setText(msg+(isLive?" • "+time(lastUpdate()):""));
        for(Stock x:all){double old=oldPrices.containsKey(x.symbol)?oldPrices.get(x.symbol):x.price;if(alerts.checkAndClear(x.symbol,old,x.price))sendPriceAlert(x);}
        signals.recordTransitions(all);if(listHost!=null)renderList();if(homeQuickHost!=null)renderHomeQuickStocks();
        if(current!=null){Stock u=find(current.symbol);if(u!=null){current=u;updateDetailStatus();renderDetailHorizon();}}
        updateHomeStatus();
    }

    @Override public void onNews(List<NewsItem> items,String msg){if(detailNewsList==null)return;detailNewsList.removeAllViews();if(items.isEmpty()){detailNewsList.addView(tv(msg,11,MUTED));return;}for(NewsItem n:items){TextView h=tv(n.title,12,TEXT);h.setTypeface(null,Typeface.BOLD);detailNewsList.addView(h);detailNewsList.addView(tv(n.source+" • "+n.time,9,MUTED));spacerIn(detailNewsList,6);}}
    @Override public void onHistory(String sym,String range,List<Candle> bars,String source,String msg){
        if(current==null||!sym.equals(current.symbol))return;
        if(screen==Screen.DETAIL && "3Y".equals(range)){
            detailHistoryBars=new ArrayList<>(bars);
            computeDetailHorizons(sym,source,msg);
            return;
        }
        if(screen==Screen.HISTORY){
            if(historyChart!=null){historyChart.setCandles(bars);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);}
            if(historyInfo!=null)historyInfo.setText(bars.isEmpty()?msg:source+" • "+bars.size()+" günlük veri • "+msg);
        }
    }

    void computeDetailHorizons(String sym,String source,String msg){
        if(current==null||detailHistoryBars.isEmpty())return;
        final Stock liveStock=current.copy();
        final List<Candle> sourceBars=new ArrayList<>(detailHistoryBars);
        final List<Candle> benchmark=new ArrayList<>(detailBenchmarkBars);
        final String symbol=sym;
        analysisExecutor.execute(()->{
            List<Candle> longBars=new ArrayList<>(sourceBars);
            List<Candle> midBars=sliceDays(sourceBars,370);
            List<Candle> shortBars=sliceDays(sourceBars,190);
            HorizonAnalysis.Result lr=HorizonAnalysis.analyze(liveStock,longBars,benchmark,HorizonAnalysis.LONG);
            HorizonAnalysis.Result mr=HorizonAnalysis.analyze(liveStock,midBars,benchmark,HorizonAnalysis.MEDIUM);
            HorizonAnalysis.Result sr=HorizonAnalysis.analyze(liveStock,shortBars,benchmark,HorizonAnalysis.SHORT);
            runOnUiThread(()->{
                if(current==null||!symbol.equalsIgnoreCase(current.symbol)||screen!=Screen.DETAIL)return;
                horizonResults.put(HorizonAnalysis.LONG,lr);
                horizonResults.put(HorizonAnalysis.MEDIUM,mr);
                horizonResults.put(HorizonAnalysis.SHORT,sr);
                current.longTermAnalysis=lr;current.mediumTermAnalysis=mr;current.shortTermAnalysis=sr;
                renderDetailHorizon();
            });
        });
    }

    List<Candle> sliceDays(List<Candle> bars,long days){
        if(bars==null||bars.isEmpty())return Collections.emptyList();long cutoff=bars.get(bars.size()-1).time-days*86400000L;ArrayList<Candle> out=new ArrayList<>();for(Candle c:bars)if(c.time>=cutoff)out.add(c);return out;
    }

    void copyAnalysis(Stock a,Stock b){b.rsi=a.rsi;b.macd=a.macd;b.macdSignal=a.macdSignal;b.ema20=a.ema20;b.ema50=a.ema50;b.ema200=a.ema200;b.atrPct=a.atrPct;b.momentumPct=a.momentumPct;b.avgVolume=a.avgVolume;b.volumeRatio=a.volumeRatio;b.bollingerUpper=a.bollingerUpper;b.bollingerLower=a.bollingerLower;b.support1=a.support1;b.support2=a.support2;b.resistance1=a.resistance1;b.resistance2=a.resistance2;b.stopPrice=a.stopPrice;b.targetPrice=a.targetPrice;b.targetPrice2=a.targetPrice2;b.entryLow=a.entryLow;b.entryHigh=a.entryHigh;b.trailingStop=a.trailingStop;b.adx=a.adx;b.diPlus=a.diPlus;b.diMinus=a.diMinus;b.obvSlopePct=a.obvSlopePct;b.dailyGapPct=a.dailyGapPct;b.relativeStrengthPct=a.relativeStrengthPct;b.stopPct=a.stopPct;b.rr1=a.rr1;b.rr2=a.rr2;b.riskPerShare=a.riskPerShare;b.suggestedQty=a.suggestedQty;b.suggestedPositionPct=a.suggestedPositionPct;b.setupType=a.setupType;b.stage=a.stage;b.marketRegime=a.marketRegime;b.management=a.management;b.safety=a.safety;b.dataQualityOk=a.dataQualityOk;b.marketOk=a.marketOk;b.relativeStrengthOk=a.relativeStrengthOk;b.volumeSetupOk=a.volumeSetupOk;b.volatilityOk=a.volatilityOk;b.overextended=a.overextended;b.breakoutConfirmed=a.breakoutConfirmed;b.pullbackConfirmed=a.pullbackConfirmed;b.contractionConfirmed=a.contractionConfirmed;b.candleConfirmed=a.candleConfirmed;b.adxConfirmed=a.adxConfirmed;b.obvConfirmed=a.obvConfirmed;b.entryZoneOk=a.entryZoneOk;b.volatilityShock=a.volatilityShock;b.distributionFlag=a.distributionFlag;b.hardGateOk=a.hardGateOk;b.score=a.score;b.confidence=a.confidence;b.signal=a.signal;b.risk=a.risk;b.conditionsMet=a.conditionsMet;b.conditionsTotal=a.conditionsTotal;b.bullConditions=a.bullConditions;b.bearConditions=a.bearConditions;b.weightedBull=a.weightedBull;b.weightedBear=a.weightedBear;b.signalBalance=a.signalBalance;b.entryQuality=a.entryQuality;b.decisionTier=a.decisionTier;b.nearbyResistanceConflict=a.nearbyResistanceConflict;b.stageOneExtensionRisk=a.stageOneExtensionRisk;b.rsiOk=a.rsiOk;b.macdOk=a.macdOk;b.emaOk=a.emaOk;b.volumeOk=a.volumeOk;b.trendOk=a.trendOk;b.supportOk=a.supportOk;b.momentumOk=a.momentumOk;b.trend=a.trend;b.reason=a.reason;b.analysisReady=a.analysisReady;b.longTermAnalysis=a.longTermAnalysis;b.mediumTermAnalysis=a.mediumTermAnalysis;b.shortTermAnalysis=a.shortTermAnalysis;}

    void sendPriceAlert(Stock s){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("price","Fiyat Alarmları",NotificationManager.IMPORTANCE_DEFAULT));}Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"price"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("BIST AI Trader • "+s.symbol).setContentText("Fiyat alarmı: "+formatPrice(s.price)).setAutoCancel(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(Math.abs(s.symbol.hashCode()),b.build());}
    private void startRefresh(){strategy=getSharedPreferences("settings",0).getString("strategy","Dengeli");refreshTask=()->{data.refresh();timer.postDelayed(refreshTask,Math.max(15,getSharedPreferences("settings",0).getInt("refresh_sec",30))*1000L);};timer.post(refreshTask);}
    private void restartRefresh(){if(refreshTask!=null)timer.removeCallbacks(refreshTask);startRefresh();}
    long lastUpdate(){return getSharedPreferences("runtime",0).getLong("last_update",0L);}
    String lastDataLabel(){long t=lastUpdate();return t<=0?"—":time(t);}
    void openDetailFromCurrentScreen(Stock s){if(s==null)return;detailReturnScreen=screen;current=s;showDetail(s);}
    void returnFromDetail(){if(detailReturnScreen==Screen.HOME){showDashboard();return;}if(detailReturnScreen==Screen.WATCH){showWatchlist();return;}if(detailReturnScreen==Screen.PORTFOLIO){showPortfolio();return;}if(detailReturnScreen==Screen.SETTINGS){showSettings();return;}showMarket();}
    String dataSourceLabel(){String base=getSharedPreferences("settings",0).getString("base_url","").trim();return base.isEmpty()?"İş Yatırım":"Özel veri sağlayıcı";}
    String refreshIntervalLabel(){int sec=Math.max(1,getSharedPreferences("settings",0).getInt("refresh_sec",30));return sec+" sn";}
    String homeMarketRegime(){for(Stock s:all)if(s.analysisReady&&!s.marketRegime.equals("Piyasa doğrulaması yok")&&!s.marketRegime.equals("Belirsiz"))return s.marketRegime;return "XU100 bekleniyor";}

    void updateHomeStatus(){if(homeDataInfo!=null){homeDataInfo.setText("Veri kaynağı: "+dataSourceLabel());}if(homeLastDataInfo!=null){homeLastDataInfo.setText("Son veri: "+lastDataLabel());}if(homeCatalogInfo!=null){homeCatalogInfo.setText("Hisse kataloğu: "+StockUniverse.size()+" sembol • otomatik keşif");}if(homeIndexInfo!=null){homeIndexInfo.setText("Endeks üyelikleri: "+MarketGroups.status(this));}if(homeMarketInfo!=null){homeMarketInfo.setText("Piyasa filtresi: "+homeMarketRegime());}if(homeLearningInfo!=null){PredictionStore.Report pr=new PredictionStore(this).report();homeLearningInfo.setText("AI öğrenme: "+learning.sampleCount()+" sonuç • "+(learning.active()?"AKTİF":"PASİF")+" • "+pr.open+" açık tahmin • arka plan 15 dk");}}
    void updateDetailStatus(){if(current==null)return;Stock s=find(current.symbol);if(s==null)return;if(detailPriceView!=null)detailPriceView.setText(s.price>0?formatPrice(s.price):"—");if(detailQuoteMeta!=null)detailQuoteMeta.setText(s.price>0?String.format(Locale.US,"%+.2f%% bugün • %s",s.changePct,s.risk):"Geçmiş OHLCV verisi yükleniyor…");}

    void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
    String time(long t){return new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t));}
    @Override protected void onDestroy(){if(refreshTask!=null)timer.removeCallbacks(refreshTask);if(history!=null)history.shutdown();if(data!=null)data.shutdown();analysisExecutor.shutdownNow();super.onDestroy();}
    String formatPrice(double v){return v<=0?"—":String.format(Locale.US,"%.2f ₺",v);}
    String formatPlain(double v){return v<=0?"":String.format(Locale.US,"%.2f",v);}
    int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    double parseDouble(String s,double d){try{return Double.parseDouble(s.trim().replace(",","."));}catch(Exception e){return d;}}
    boolean isFavorite(String sym){return getSharedPreferences("favorites",0).getBoolean(sym,false);}
    void toggleFavorite(String sym){getSharedPreferences("favorites",0).edit().putBoolean(sym,!isFavorite(sym)).apply();}
    Stock find(String sym){for(Stock s:all)if(s.symbol.equalsIgnoreCase(sym))return s;return null;}
}
