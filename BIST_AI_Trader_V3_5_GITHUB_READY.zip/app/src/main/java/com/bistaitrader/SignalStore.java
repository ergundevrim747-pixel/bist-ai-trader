package com.bistaitrader;

import android.content.Context;
import org.json.*;
import java.util.*;

public class SignalStore {
    private final android.content.SharedPreferences sp;
    public SignalStore(Context c){sp=c.getApplicationContext().getSharedPreferences("signals",Context.MODE_PRIVATE);}
    public void recordTransitions(List<Stock> stocks){
        JSONArray a=readArray("history");
        android.content.SharedPreferences.Editor e=sp.edit();
        for(Stock s:stocks){
            if(s==null||!s.analysisReady)continue;
            String old=sp.getString("last_"+s.symbol,"");
            if(!old.equals(s.signal) && (!old.isEmpty() || !"BEKLE".equals(s.signal))){
                try{JSONObject o=new JSONObject();o.put("symbol",s.symbol);o.put("old",old);o.put("new",s.signal);o.put("price",s.price);o.put("time",System.currentTimeMillis());o.put("score",s.score);o.put("met",s.conditionsMet);a.put(o);}catch(Exception ignored){}
            }
            e.putString("last_"+s.symbol,s.signal);
        }
        while(a.length()>500)a.remove(0);
        e.putString("history",a.toString()).apply();
    }
    public JSONArray history(){return readArray("history");}
    public void clear(){sp.edit().clear().apply();}
    private JSONArray readArray(String key){try{return new JSONArray(sp.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
}
