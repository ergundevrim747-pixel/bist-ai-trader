package com.bistaitrader;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * iTick Turkey/BIST real-time quote adapter.
 * Uses only documented REST endpoints and keeps the API token local in app settings.
 * The caller controls polling frequency; this class never silently fabricates prices.
 */
public final class ITickQuoteProvider {
    public static final class Quote {
        public String symbol;
        public double price;
        public double previousClose;
        public double changePct;
        public double volume;
        public long quoteTime;
        public boolean valid;
    }

    public static final class Result {
        public final LinkedHashMap<String, Quote> quotes = new LinkedHashMap<>();
        public boolean ok;
        public String message = "";
        public long serverTime = 0L;
    }

    private ITickQuoteProvider() {}
    private static final Object RATE_LOCK = new Object();
    private static long lastRequestAt = 0L;
    private static final long MIN_REQUEST_GAP_MS = 12500L;

    public static Result fetch(List<String> symbols, String token) throws Exception {
        if (symbols == null || symbols.isEmpty()) throw new Exception("iTick için sembol yok");
        if (token == null || token.trim().isEmpty()) throw new Exception("iTick API token girilmemiş");

        LinkedHashSet<String> unique = new LinkedHashSet<>();
        for (String s : symbols) {
            if (s == null) continue;
            String x = s.trim().toUpperCase(Locale.ROOT);
            if (x.matches("[A-Z0-9]{3,8}")) unique.add(x);
        }
        if (unique.isEmpty()) throw new Exception("Geçerli BIST sembolü yok");

        Result out = new Result();
        ArrayList<String> list = new ArrayList<>(unique);

        // A conservative first choice for the free tier. If the provider rejects the
        // batch size, fetchRecursive() automatically retries with smaller batches.
        final int batchSize = 10;
        for (int i = 0; i < list.size(); i += batchSize) {
            List<String> batch = list.subList(i, Math.min(i + batchSize, list.size()));
            fetchRecursive(batch, token, out, 0);
        }
        out.ok = !out.quotes.isEmpty();
        if (!out.ok) throw new Exception("iTick hiçbir geçerli BIST kotasyonu döndürmedi");
        out.message = out.quotes.size() + " BIST kotasyonu alındı";
        return out;
    }

    private static void fetchRecursive(List<String> batch, String token, Result out, int depth) throws Exception {
        try {
            String base = "https://api-free.itick.org";
            JSONObject root = request(base, batch, token);
            parse(root, out);
            if (containsAll(batch, out)) return;
            // The response can legitimately omit halted/invalid symbols. Do not split in
            // that case unless there is an explicit provider error.
        } catch (Exception first) {
            String msg = String.valueOf(first.getMessage()).toLowerCase(Locale.ROOT);
            boolean looksLikeBatchLimit = msg.contains("maximum") || msg.contains("limit") || msg.contains("batch") || msg.contains("subscription");
            if (batch.size() <= 1 || depth >= 2 || !looksLikeBatchLimit) {
                // The free API hostname is used by iTick's own SDK documentation as an
                // alternate free endpoint. Retry the same batch there before giving up.
                try {
                    JSONObject root = request("https://api.itick.org", batch, token);
                    parse(root, out);
                    return;
                } catch (Exception ignored) {
                    throw first;
                }
            }
            int mid = Math.max(1, batch.size() / 2);
            fetchRecursive(batch.subList(0, mid), token, out, depth + 1);
            fetchRecursive(batch.subList(mid, batch.size()), token, out, depth + 1);
        }
    }

    private static boolean containsAll(List<String> batch, Result out) {
        for (String s : batch) if (!out.quotes.containsKey(s)) return false;
        return true;
    }

    private static JSONObject request(String base, List<String> batch, String token) throws Exception {
        String codes = URLEncoder.encode(String.join(",", batch), "UTF-8");
        String urlText = base + "/stock/quotes?region=TR&codes=" + codes;
        synchronized(RATE_LOCK){
            long wait=MIN_REQUEST_GAP_MS-(System.currentTimeMillis()-lastRequestAt);
            if(wait>0){try{Thread.sleep(wait);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new Exception("iTick istek zamanlaması kesildi");}}
            lastRequestAt=System.currentTimeMillis();
        }
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "BIST-AI-Trader/4.5");
        c.setRequestProperty("token", token.trim());
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) {
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("iTick HTTP " + code + " " + sb);
        JSONObject root = new JSONObject(sb.toString());
        int apiCode = root.optInt("code", 0);
        if (apiCode != 0) throw new Exception("iTick " + root.optString("msg", "API hatası"));
        return root;
    }

    private static void parse(JSONObject root, Result out) throws Exception {
        JSONObject data = root.optJSONObject("data");
        if (data == null) return;
        Iterator<String> keys = data.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject q = data.optJSONObject(key);
            if (q == null) continue;
            String sym = q.optString("s", key).trim().toUpperCase(Locale.ROOT);
            double price = q.optDouble("ld", 0);
            if (!sym.matches("[A-Z0-9]{3,8}") || price <= 0) continue;
            Quote x = new Quote();
            x.symbol = sym;
            x.price = price;
            x.previousClose = q.optDouble("p", 0);
            x.volume = q.optDouble("v", 0);
            x.changePct = q.optDouble("chp", x.previousClose > 0 ? (price / x.previousClose - 1) * 100.0 : 0);
            x.quoteTime = q.optLong("t", System.currentTimeMillis());
            x.valid = true;
            out.quotes.put(sym, x);
            out.serverTime = Math.max(out.serverTime, x.quoteTime);
        }
    }
}
