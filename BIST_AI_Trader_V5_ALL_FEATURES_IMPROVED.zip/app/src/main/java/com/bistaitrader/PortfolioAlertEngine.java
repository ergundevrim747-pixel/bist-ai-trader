package com.bistaitrader;

import android.content.Context;
import java.util.Locale;

/** Separates position management from entry signals. It never sells automatically. */
public final class PortfolioAlertEngine {
    public static final int HEALTHY=0, WEAK=1, PROFIT=2, TRAILING=3, STOP=4, BREAKDOWN=5;
    public static final class Decision {
        public String symbol=""; public int level=HEALTHY; public String key="HEALTHY"; public String title=""; public String message=""; public boolean notify;
        public double entry, price, returnPct, peak, peakProfitPct, drawdownPct, stopLevel, targetLevel, protectionLevel;
        public String compact(){return levelName(level)+" • "+String.format(Locale.US,"%+.2f%%",returnPct);}
    }
    private PortfolioAlertEngine(){}

    public static Decision preview(Context context,String symbol,double price,Stock stock){return evaluateInternal(context,symbol,price,stock,false);}
    public static Decision evaluate(Context context,String symbol,double price,Stock stock){return evaluateInternal(context,symbol,price,stock,true);}

    private static Decision evaluateInternal(Context context,String symbol,double price,Stock stock,boolean persist){
        Context c=context.getApplicationContext(); PortfolioStore p=new PortfolioStore(c);
        Decision d=new Decision(); d.symbol=symbol==null?"":symbol.toUpperCase(Locale.ROOT); d.price=price;
        int qty=p.qty(d.symbol); if(qty<=0||price<=0)return d;
        d.entry=p.avgCost(d.symbol); if(d.entry<=0)return d;
        d.returnPct=(price/d.entry-1)*100.0;
        d.peak=p.observePeak(d.symbol,price);
        d.peakProfitPct=(d.peak/d.entry-1)*100.0;
        d.drawdownPct=d.peak>0?(price/d.peak-1)*100.0:0;

        android.content.SharedPreferences sp=c.getSharedPreferences("settings",0);
        double maxLoss=clamp(sp.getFloat("max_loss_pct",7f),1,30);
        double activate=clamp(sp.getFloat("profit_protect_activate_pct",10f),1,100);
        double trail=clamp(sp.getFloat("peak_drawdown_pct",20f),5,60);
        double profitTarget=clamp(sp.getFloat("profit_target_pct",20f),1,200);

        double hardStop=d.entry*(1-maxLoss/100.0);
        double technicalStop=p.planStop(d.symbol);
        d.stopLevel=technicalStop>0?Math.max(hardStop,technicalStop):hardStop;
        double technicalTarget=p.planTarget1(d.symbol);
        d.targetLevel=technicalTarget>0?technicalTarget:d.entry*(1+profitTarget/100.0);
        d.protectionLevel=d.peakProfitPct>=activate?d.peak*(1-trail/100.0):0;

        int level=HEALTHY; String key="HEALTHY";
        if(price<=d.stopLevel || d.returnPct<=-maxLoss){
            level=STOP; key="STOP_LOSS"; d.title="ZARAR DURDUR UYARISI";
            d.message=String.format(Locale.US,"%s • Alış %.2f • Son %.2f • K/Z %+.2f%%\nZarar koruma seviyesi %.2f. Satışı değerlendir.",d.symbol,d.entry,price,d.returnPct,d.stopLevel);
        }else if(d.peakProfitPct>=activate && d.drawdownPct<=-trail){
            level=TRAILING; key="TRAILING_PROTECT"; d.title="KÂR KORUMA UYARISI";
            d.message=String.format(Locale.US,"%s • Alış %.2f • Tepe %.2f • Son %.2f\nK/Z %+.2f%% • Tepeden geri çekilme %+.2f%%\nKâr koruma seviyesi %.2f. Kârın önemli kısmı geri veriliyor; satışı değerlendir.",d.symbol,d.entry,d.peak,price,d.returnPct,d.drawdownPct,d.protectionLevel);
        }else if(price>=d.targetLevel || d.returnPct>=profitTarget){
            level=PROFIT; key="PROFIT_TAKE"; d.title="KÂR SATIŞI UYARISI";
            d.message=String.format(Locale.US,"%s • Alış %.2f • Son %.2f • K/Z %+.2f%%\nKâr hedefi %.2f seviyesinde. Kâr realize etmeyi değerlendir.",d.symbol,d.entry,price,d.returnPct,d.targetLevel);
        }else if(stock!=null && stock.analysisReady && "SAT".equals(stock.aiSignal)
                && "GÜÇLÜ SAT".equals(stock.technicalRatingLabel) && stock.distributionFlag
                && stock.diMinus>stock.diPlus){
            level=BREAKDOWN; key="STRONG_BREAKDOWN"; d.title="GÜÇLÜ BOZULMA UYARISI";
            d.message=String.format(Locale.US,"%s • Alış %.2f • Son %.2f • K/Z %+.2f%%\nAI: SAT • Teknik: GÜÇLÜ SAT • Dağıtım ve -DI üstünlüğü var. Pozisyon riskini azaltmayı değerlendir.",d.symbol,d.entry,price,d.returnPct);
        }else if(stock!=null && stock.analysisReady && "SAT".equals(stock.aiSignal)
                && ("SAT".equals(stock.technicalRatingLabel)||"GÜÇLÜ SAT".equals(stock.technicalRatingLabel))){
            level=WEAK; key="TECHNICAL_WEAK"; d.title="TEKNİK ZAYIFLAMA UYARISI";
            d.message=String.format(Locale.US,"%s • Alış %.2f • Son %.2f • K/Z %+.2f%%\nAI: SAT • Teknik: %s. Pozisyonu yakından izle.",d.symbol,d.entry,price,d.returnPct,stock.technicalRatingLabel);
        }
        d.level=level; d.key=key;

        if(persist){
            PortfolioAlertStore as=new PortfolioAlertStore(c);
            int prev=as.state(d.symbol); long now=System.currentTimeMillis();
            long repeatMinutes=Math.max(5,sp.getInt("alert_repeat_min",60));
            boolean enteredRisk=level>0 && (prev==HEALTHY || level>prev);
            boolean periodicCritical=level>=TRAILING && prev==level && now-as.lastNotified(d.symbol)>=repeatMinutes*60_000L;
            d.notify=(level>0)&&(enteredRisk||periodicCritical);
            as.setState(d.symbol,level);
            if(d.notify){as.setNotified(d.symbol,now);as.addHistory(d.symbol,key,d.title,d.message,now);}
        }
        return d;
    }
    private static double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    public static String levelName(int level){switch(level){case STOP:return "ZARAR DURDUR";case TRAILING:return "KÂR KORUMA";case PROFIT:return "KÂR SATIŞI";case WEAK:return "TEKNİK ZAYIF";case BREAKDOWN:return "GÜÇLÜ BOZULMA";default:return "NORMAL";}}
}
