package com.bistaitrader;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;

import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements DataService.Listener, NewsService.Listener, HistoryService.Listener {
    private static final int BG=Color.rgb(7,14,26), SURFACE=Color.rgb(14,24,40), SURFACE2=Color.rgb(20,34,54), LINE=Color.rgb(38,56,81), TEXT=Color.rgb(244,247,251), MUTED=Color.rgb(145,164,186), BLUE=Color.rgb(84,145,255), GREEN=Color.rgb(48,209,88), YELLOW=Color.rgb(255,204,0), RED=Color.rgb(255,79,91), CYAN=Color.rgb(72,211,255);
    private enum Screen { HOME, MARKET, WATCH, PORTFOLIO, DATA, SETTINGS, DETAIL, HISTORY, BACKTEST, COMPARE, SIGNALS }
    private Screen screen=Screen.HOME;
    private LinearLayout root,content,nav,listHost;
    private TextView status,statusMessage,homeDataInfo,homeLastDataInfo,homeCatalogInfo,homeIndexInfo,homeMarketInfo,homeLearningInfo,detailPriceView,detailQuoteMeta;
    private EditText search;
    private final ArrayList<Stock> all=new ArrayList<>();
    private final LinkedHashSet<String> compareSet=new LinkedHashSet<>();
    private String marketCategory="POPULAR 20", riskFilter="", sort="Hacim", historyRange="6A", historyMode="Mum", strategy="Dengeli";
    private String homeSignalFilter="AL";
    private String detailHorizon=HorizonAnalysis.MEDIUM;
    private int listLimit=20;
    private Stock current;
    private Screen detailReturnScreen=Screen.MARKET;
    private DataService data; private HistoryService history; private NewsService news; private PortfolioStore portfolio; private AlertStore alerts; private SignalStore signals; private LearningStore learning;
    private HistoryChartView historyChart; private TextView historyInfo,scanStatus;
    private LinearLayout detailNewsList,homeQuickHost,detailHorizonHost,detailHorizonSummaryHost,dataHost;
    private final LinkedHashMap<String,HorizonAnalysis.Result> horizonResults=new LinkedHashMap<>();
    private List<Candle> detailHistoryBars=Collections.emptyList();
    private List<Candle> detailBenchmarkBars=Collections.emptyList();
    private boolean detailHistoryFailed=false;
    private String detailHistoryError="";
    private Handler timer=new Handler(Looper.getMainLooper()); private Runnable refreshTask;
    private final ExecutorService analysisExecutor=Executors.newSingleThreadExecutor();
    private boolean live=false;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),LINE);return g;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(15),dp(16),dp(15));l.setBackground(bg(SURFACE,18));return l;}
    Button chip(String text,boolean selected){Button b=new Button(this);b.setText(text);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(selected?Color.BLACK:TEXT);b.setMinHeight(0);b.setMinimumHeight(dp(38));b.setStateListAnimator(null);b.setBackground(bg(selected?BLUE:SURFACE2,14));return b;}
    Button action(String text,int color){Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(color==YELLOW?Color.BLACK:Color.WHITE);b.setTypeface(null,Typeface.BOLD);b.setMinHeight(0);b.setMinimumHeight(dp(44));b.setStateListAnimator(null);b.setBackground(bg(color,14));return b;}
    TextView pill(String text,int color){TextView t=tv(text,10,Color.WHITE);t.setGravity(Gravity.CENTER);t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(8),dp(4),dp(8),dp(4));t.setBackground(bg(color,13));return t;}
    void spacer(int h){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void spacerIn(LinearLayout l,int h){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void spaceH(LinearLayout l,int w){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(w),1));}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        portfolio=new PortfolioStore(this);alerts=new AlertStore(this);signals=new SignalStore(this);learning=new LearningStore(this);AnalysisEngine.setLearningStore(learning);data=new DataService(this,this);news=new NewsService(this,this);history=new HistoryService(this);
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
        buildShell();showDashboard();ensureNotificationPermission();startRefresh();SelfLearningScheduler.schedule(this);startPortfolioMonitorIfConfigured();
    }
    @Override public void onBackPressed(){handleBack();}
    private void ensureNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            new Handler(Looper.getMainLooper()).postDelayed(()->{try{requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);}catch(Exception ignored){}},900);
        }
    }
    private void handleBack(){
        if(screen==Screen.HISTORY||screen==Screen.BACKTEST){showDetail(current);return;}
        if(screen==Screen.COMPARE||screen==Screen.SIGNALS){showDashboard();return;}
        if(screen==Screen.DETAIL){returnFromDetail();return;}
        if(screen==Screen.MARKET||screen==Screen.WATCH||screen==Screen.PORTFOLIO||screen==Screen.DATA||screen==Screen.SETTINGS){showDashboard();return;}
        Toast.makeText(this,"Ana sayfadasın",Toast.LENGTH_SHORT).show();
    }

    private void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(16),dp(11),dp(16),dp(8));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);TextView a=tv("BIST AI TRADER",19,TEXT);a.setTypeface(null,Typeface.BOLD);brand.addView(a);statusMessage=tv("Veri • teknik analiz • sanal portföy",10,MUTED);brand.addView(statusMessage);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        status=tv("● HAZIR",11,YELLOW);status.setGravity(Gravity.RIGHT);status.setTypeface(null,Typeface.BOLD);top.addView(status,new LinearLayout.LayoutParams(dp(110),-2));root.addView(top);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(4),dp(12),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(4),dp(4),dp(4),dp(4));nav.setBackgroundColor(SURFACE);
        TextView h=navBtn("⌂\nAna"),m=navBtn("▦\nPiyasa"),w=navBtn("☆\nTakip"),p=navBtn("₺\nPortföy"),d=navBtn("▣\nVeri"),s=navBtn("⚙\nAyar");
        for(TextView x:new TextView[]{h,m,w,p,d,s})nav.addView(x,new LinearLayout.LayoutParams(0,dp(56),1));root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
        h.setOnClickListener(v->showDashboard());m.setOnClickListener(v->showMarket());w.setOnClickListener(v->showWatchlist());p.setOnClickListener(v->showPortfolio());d.setOnClickListener(v->showData());s.setOnClickListener(v->showSettings());setContentView(root);
    }
    TextView navBtn(String s){TextView t=tv(s,10,MUTED);t.setGravity(Gravity.CENTER);t.setTypeface(null,Typeface.BOLD);t.setClickable(true);return t;}
    void selectNav(String label){for(int i=0;i<nav.getChildCount();i++)((TextView)nav.getChildAt(i)).setTextColor(MUTED);int idx=label.equals("Ana")?0:label.equals("Piyasa")?1:label.equals("Takip")?2:label.equals("Portföy")?3:label.equals("Veri")?4:5;((TextView)nav.getChildAt(idx)).setTextColor(TEXT);}
    void clear(){content.removeAllViews();search=null;listHost=null;detailNewsList=null;historyChart=null;historyInfo=null;scanStatus=null;homeDataInfo=null;homeLastDataInfo=null;homeCatalogInfo=null;homeIndexInfo=null;homeMarketInfo=null;homeLearningInfo=null;homeQuickHost=null;detailPriceView=null;detailQuoteMeta=null;detailHorizonHost=null;detailHorizonSummaryHost=null;dataHost=null;horizonResults.clear();detailHistoryBars=Collections.emptyList();detailBenchmarkBars=Collections.emptyList();detailHistoryFailed=false;detailHistoryError="";}


    void showDashboard(){screen=Screen.HOME;selectNav("Ana");current=null;clear();
        content.addView(tv("Piyasa özeti",27,TEXT));
        content.addView(tv("Sanal portföy • canlı durum • seçilmiş sinyaller",12,MUTED));
        spacer(12);

        LinearLayout pf=card();
        pf.addView(tv("Sanal portföy",17,TEXT));
        double val=portfolioValue();
        pf.addView(tv(String.format(Locale.US,"%.2f ₺",val),26,TEXT));
        pf.addView(tv(String.format(Locale.US,"K/Z %+.2f ₺",val-100000),11,val>=100000?GREEN:RED));
        Button go=action("Portföye git",BLUE);go.setOnClickListener(v->showPortfolio());pf.addView(go);
        content.addView(pf);spacer(12);

        LinearLayout statusBox=card();
        LinearLayout hr=new LinearLayout(this);hr.setGravity(Gravity.CENTER_VERTICAL);
        hr.addView(tv("PİYASA VERİSİ",11,MUTED),new LinearLayout.LayoutParams(0,-2,1));
        hr.addView(pill(live?"CANLI":"BEKLENİYOR",live?GREEN:YELLOW),new LinearLayout.LayoutParams(dp(115),dp(30)));
        statusBox.addView(hr);
        statusBox.addView(tv("Kaynak: "+dataSourceLabel()+" • Son veri: "+lastDataLabel(),11,TEXT));
        statusBox.addView(tv("Endeks üyelikleri: "+MarketGroups.status(this),10,MUTED));
        statusBox.addView(tv("AI öğrenme: "+learning.sampleCount()+" örnek • "+(learning.active()?"AKTİF":"PASİF"),10,MUTED));
        content.addView(statusBox);spacer(12);

        LinearLayout quick=card();
        quick.addView(tv("Öne çıkan hisseler",18,TEXT));
        quick.addView(tv("TradingView tarzı teknik puan • çoklu vade • en fazla 20 hisse",10,MUTED));
        LinearLayout filters=new LinearLayout(this);
        for(String f:new String[]{"AL","AL ADAYI","BEKLE","SAT"}){Button b=chip(f,f.equals(homeSignalFilter));b.setOnClickListener(v->{homeSignalFilter=f;renderHomeQuickStocks();});filters.addView(b,new LinearLayout.LayoutParams(0,dp(40),1));spaceH(filters,5);}
        quick.addView(filters);
        homeQuickHost=new LinearLayout(this);homeQuickHost.setOrientation(LinearLayout.VERTICAL);quick.addView(homeQuickHost);
        renderHomeQuickStocks();
        content.addView(quick);spacer(12);

        LinearLayout tools=card();tools.addView(tv("Hızlı araçlar",17,TEXT));
        addToolButton(tools,"📊 Sinyal geçmişi",v->showSignals());
        addToolButton(tools,"⚖ Hisse karşılaştır",v->showCompare());
        addToolButton(tools,"🧪 Backtest",v->{if(current!=null)showBacktest(current);else toast("Önce bir hisse aç" );});
        addToolButton(tools,"🧠 AI Öğrenme",v->showLearning());
        content.addView(tools);spacer(12);

        LinearLayout note=card();
        note.addView(tv("Analiz mantığı",17,TEXT));
        note.addView(tv("Bir hisseyi açtığında geçmiş günlük verisi yalnızca o hisse için yüklenir ve 3 ayrı vade birlikte değerlendirilir: Uzun Vade Yatırım, Orta Vade ve Kısa Vade. Canlı fiyat, son tarihsel kapanışın üzerine ayrıca uygulanır.",10,MUTED));
        note.addView(tv("AL adayı 5/7 ile başlayabilir. Final AL için teknik denge + giriş bölgesi + stop/RR + piyasa/volatilite güvenlikleri birlikte kontrol edilir. Hisse detayında kararın nedenini madde madde görebilirsin.",10,MUTED));
        content.addView(note);
    }

    void renderHomeQuickStocks(){
        if(homeQuickHost==null)return;
        homeQuickHost.removeAllViews();
        int al=0,candidate=0,bek=0,sat=0;
        for(Stock x:all){if("AL".equals(x.signal))al++;else if("AL ADAYI".equals(x.decisionTier))candidate++;else if("SAT".equals(x.signal))sat++;else bek++;}
        homeQuickHost.addView(tv("AL "+al+" • AL ADAYI "+candidate+" • BEKLE "+bek+" • SAT "+sat,10,CYAN));
        ArrayList<Stock> list=new ArrayList<>(all);
        list.removeIf(x->!x.analysisReady||x.price<=0||("AL ADAYI".equals(homeSignalFilter)?!"AL ADAYI".equals(x.decisionTier):!homeSignalFilter.equals(x.signal)));
        Comparator<Stock> cmp=Comparator.comparingDouble((Stock x)->-x.score);
        if("SAT".equals(homeSignalFilter))cmp=Comparator.comparingDouble(x->x.score);
        else if("BEKLE".equals(homeSignalFilter))cmp=Comparator.comparingDouble((Stock x)->-Math.abs(x.changePct));
        else if("AL ADAYI".equals(homeSignalFilter))cmp=Comparator.comparingDouble((Stock x)->-x.confidence);
        list.sort(cmp);
        int shown=Math.min(listLimit,list.size());
        if(shown==0){homeQuickHost.addView(tv("Bu filtrede hisse görünmüyor. AI taraması tamamlandıkça kararlar güncellenir.",11,MUTED));return;}
        for(int i=0;i<shown;i++)homeQuickHost.addView(stockRow(list.get(i)));
    }


    void addToolButton(LinearLayout parent,String text,View.OnClickListener l){Button b=chip(text,false);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));lp.topMargin=dp(6);parent.addView(b,lp);}
    void addCategoryButtons(LinearLayout parent){
        String[] cats={"BIST 30","BIST 50","BIST 100","BIST 500"};
        for(String c:cats){
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(9),dp(10),dp(9));row.setBackground(bg(SURFACE2,13));
            TextView t=tv(c,15,TEXT);t.setTypeface(null,Typeface.BOLD);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(tv("›",24,MUTED));
            row.setOnClickListener(v->showMarketIndex(c));
            parent.addView(row,new LinearLayout.LayoutParams(-1,dp(52)));spacerIn(parent,6);
        }
    }

    void addRiskButtons(LinearLayout parent,String index){
        TextView title=tv(index+" • risk filtreleri",14,TEXT);title.setTypeface(null,Typeface.BOLD);parent.addView(title);
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout r=new LinearLayout(this);
        String[] rs={"Düşük Risk","Orta Risk","Yüksek Risk"};
        for(String x:rs){Button b=chip(x,x.equals(riskFilter));b.setOnClickListener(v->{riskFilter=x;listLimit=20;renderList();});r.addView(b,new LinearLayout.LayoutParams(-2,dp(40)));spaceH(r,6);}
        hs.addView(r);parent.addView(hs);
    }


    void showMarket(){
        screen=Screen.MARKET;selectNav("Piyasa");marketCategory="POPULAR 20";riskFilter="";listLimit=20;clear();
        content.addView(tv("Piyasa",27,TEXT));
        content.addView(tv("İlk ekran: günün aktif/popüler 20 hissesi • kategori seçince ayrı endeks sayfası",12,MUTED));
        spacer(8);
        buildSearch();
        LinearLayout indexBox=card();
        indexBox.addView(tv("Endeksler",16,TEXT));
        addCategoryButtons(indexBox);
        content.addView(indexBox);spacer(8);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);
        Button scan=action("🤖 AI Tarama",BLUE);scan.setOnClickListener(v->startScan());tools.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(tools,8);
        Button refresh=chip("↻ Yenile",false);refresh.setOnClickListener(v->data.refresh());tools.addView(refresh,new LinearLayout.LayoutParams(dp(110),dp(44)));
        content.addView(tools);
        scanStatus=tv("AI tarama: hazır",10,MUTED);content.addView(scanStatus);spacer(8);
        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }

    void showMarketIndex(String index){
        screen=Screen.MARKET;selectNav("Piyasa");marketCategory=index;listLimit=20;clear();
        content.addView(tv(index,27,TEXT));
        content.addView(tv(MarketGroups.count(this,index)+" üyelik • bu sayfaya özel risk filtreleri",12,MUTED));
        spacer(8);
        buildSearch();
        LinearLayout risk=card();addRiskButtons(risk,index);content.addView(risk);spacer(8);
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);
        Button scan=action("🤖 Bu endeksi tara",BLUE);scan.setOnClickListener(v->startScan());tools.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(tools,8);
        Button home=chip("Piyasa ana sayfa",false);home.setOnClickListener(v->showMarket());tools.addView(home,new LinearLayout.LayoutParams(dp(130),dp(44)));
        content.addView(tools);scanStatus=tv("AI tarama: hazır",10,MUTED);content.addView(scanStatus);spacer(8);
        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }

    void showWatchlist(){screen=Screen.WATCH;selectNav("Takip");marketCategory="Takip";riskFilter="";clear();content.addView(tv("Takip",27,TEXT));content.addView(tv("Yıldızladığın hisseler",12,MUTED));spacer(10);buildSearch();listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();}
    void buildSearch(){search=new EditText(this);search.setSingleLine(true);search.setHint("BIST'te ara: THYAO, ASELS, şirket adı...");search.setHintTextColor(MUTED);search.setTextColor(TEXT);search.setTextSize(13);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(SURFACE2,14));content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){listLimit=60;renderList();}public void afterTextChanged(Editable e){}});spacer(8);}

    void chooseSort(Button b){String[] ops={"Sinyal","Günlük %","Hacim","Skor","Fiyat"};new AlertDialog.Builder(this).setTitle("Sıralama").setItems(ops,(d,w)->{sort=ops[w];b.setText("Sıralama: "+sort);renderList();}).show();}

    void renderList(){
        if(listHost==null)return;listHost.removeAllViews();
        List<Stock> list=new ArrayList<>(all);
        String q=search==null?"":search.getText().toString().trim().toUpperCase(Locale.US);
        if(!q.isEmpty()) list.removeIf(x->!x.symbol.contains(q)&&!x.name.toUpperCase(Locale.US).contains(q));
        if("Takip".equals(marketCategory)) list.removeIf(x->!isFavorite(x.symbol));
        else if(marketCategory.startsWith("BIST")) list.removeIf(x->!MarketGroups.matches(this,marketCategory,x));
        if(!riskFilter.isEmpty()) list.removeIf(x->!riskFilter.equals(x.risk));

        if("POPULAR 20".equals(marketCategory) && q.isEmpty()){
            list.sort(Comparator.comparingDouble((Stock x)->-x.volume));
        }else{
            Comparator<Stock> cmp=Comparator.comparingDouble((Stock x)->x.analysisReady?-x.score:999999);
            if(sort.equals("Günlük %"))cmp=Comparator.comparingDouble(x->-x.changePct);
            if(sort.equals("Hacim"))cmp=Comparator.comparingDouble(x->-x.volume);
            if(sort.equals("Fiyat"))cmp=Comparator.comparingDouble(x->x.price<=0?Double.MAX_VALUE:x.price);
            list.sort(cmp);
        }

        int total=list.size();
        int preview=Math.min(listLimit,total);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(tv(total+" sonuç",11,MUTED),new LinearLayout.LayoutParams(0,-2,1));
        head.addView(tv("Gösterilen "+preview,10,live?GREEN:YELLOW));
        listHost.addView(head);spacerIn(listHost,6);
        if(list.isEmpty()){LinearLayout e=card();e.addView(tv("Hisse bulunamadı",15,TEXT));e.addView(tv(q.isEmpty()?"Bu filtreden geçen veri yok.":"Aramayı sembol veya şirket adıyla daralt.",11,MUTED));listHost.addView(e);return;}
        int shown=Math.min(listLimit,list.size());
        for(int i=0;i<shown;i++)listHost.addView(stockRow(list.get(i)));
        if(shown<list.size()){Button more=chip("Daha fazla göster • "+shown+" / "+list.size(),false);more.setOnClickListener(v->{listLimit=Math.min(listLimit+20,list.size());renderList();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(8);listHost.addView(more,lp);}
    }

    View stockRow(Stock s){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));row.setBackground(bg(SURFACE,14));
        TextView star=tv(isFavorite(s.symbol)?"★":"☆",22,isFavorite(s.symbol)?YELLOW:MUTED);star.setGravity(Gravity.CENTER);star.setOnClickListener(v->{toggleFavorite(s.symbol);renderList();});row.addView(star,new LinearLayout.LayoutParams(dp(28),dp(82)));
        LinearLayout name=new LinearLayout(this);name.setOrientation(LinearLayout.VERTICAL);
        TextView sy=tv(s.symbol,14,TEXT);sy.setTypeface(null,Typeface.BOLD);
        TextView nm=tv(s.name.isEmpty()?s.symbol:s.name,9,MUTED);nm.setSingleLine(true);nm.setEllipsize(TextUtils.TruncateAt.END);name.addView(sy);name.addView(nm);
        if(s.analysisReady){
            String tr=s.technicalRatingLabel==null?"NÖTR":s.technicalRatingLabel;
            name.addView(tv("Teknik: "+tr+" • "+s.technicalBuyCount+" AL / "+s.technicalSellCount+" SAT",9,CYAN));
            name.addView(tv("U "+horizonCompact(s.longTermAnalysis)+" • O "+horizonCompact(s.mediumTermAnalysis)+" • K "+horizonCompact(s.shortTermAnalysis),9,MUTED));
        } else name.addView(tv("Teknik analiz bekleniyor",9,MUTED));
        row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT);
        right.addView(tv(s.price>0?formatPrice(s.price):"—",14,TEXT));
        right.addView(tv(s.price>0?String.format(Locale.US,"%+.2f%%",s.changePct):"—",10,s.changePct>=0?GREEN:RED));
        String displayDecision="AL ADAYI".equals(s.decisionTier)?"AL ADAYI":s.signal;
        int displayColor="AL".equals(displayDecision)?GREEN:"SAT".equals(displayDecision)?RED:"AL ADAYI".equals(displayDecision)?CYAN:YELLOW;
        right.addView(pill(displayDecision,displayColor),new LinearLayout.LayoutParams(dp(displayDecision.equals("AL ADAYI")?88:70),dp(28)));
        row.addView(right,new LinearLayout.LayoutParams(dp(88),-2));
        row.setOnClickListener(v->openDetailFromCurrentScreen(s));return row;
    }

    String horizonCompact(HorizonAnalysis.Result r){
        if(r==null||!r.ready)return "—";
        if("AL".equals(r.decisionTier)&&r.estimatedTargetDays>0)return r.estimatedTargetDays+"g AL";
        return r.decisionTier==null?r.signal:r.decisionTier;
    }



    void startScan(){
        if(scanActive){toast("Tarama zaten devam ediyor");return;}
        if(all.isEmpty()){toast("Önce fiyat verisini yenile");return;}
        final ArrayList<String> symbols=new ArrayList<>();String q=search==null?"":search.getText().toString().trim();
        if(!q.isEmpty()){for(Stock x:all)if(x.symbol.equalsIgnoreCase(q)||x.name.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT)))symbols.add(x.symbol);}
        if(symbols.isEmpty()){
            for(Stock x:all){
                boolean ok;
                if("Takip".equals(marketCategory))ok=isFavorite(x.symbol);
                else if(marketCategory.startsWith("BIST"))ok=MarketGroups.matches(this,marketCategory,x);
                else if("POPULAR 20".equals(marketCategory))ok=true;
                else ok=false;
                if(!riskFilter.isEmpty())ok=ok&&riskFilter.equals(x.risk);
                if(ok)symbols.add(x.symbol);
            }
            if("POPULAR 20".equals(marketCategory)){symbols.sort((a,b)->Double.compare(volumeOf(b),volumeOf(a)));if(symbols.size()>20)symbols.subList(20,symbols.size()).clear();}
        }
        if(symbols.isEmpty()){toast("Tarama listesi boş");return;}
        if(scanStatus!=null)scanStatus.setText("AI tarama başladı: 0/"+symbols.size());
        scanActive=true;
        history.scan(symbols,"1Y",strategy,new HistoryService.ScanListener(){public void onScanProgress(int done,int total,Stock st){Stock target=find(st.symbol);if(target!=null&&st.analysisReady){double livePrice=target.price;copyAnalysis(st,target);if(livePrice>0)target.price=livePrice;}if(scanStatus!=null)scanStatus.setText("AI tarama: "+done+"/"+total);if(listHost!=null)renderList();}
            public void onScanFinished(int done,int total){scanActive=false;if(scanStatus!=null)scanStatus.setText("AI tarama tamamlandı: "+total+" hisse");signals.recordTransitions(all);renderList();renderHomeQuickStocks();}});
    }

    double volumeOf(String sym){Stock x=find(sym);return x==null?0:x.volume;}


    void showDetail(Stock s){
        if(s==null)return;screen=Screen.DETAIL;current=s;clear();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        Button back=chip("‹ Geri",false);back.setOnClickListener(v->returnFromDetail());top.addView(back,new LinearLayout.LayoutParams(dp(78),dp(40)));
        LinearLayout title=new LinearLayout(this);title.setOrientation(LinearLayout.VERTICAL);TextView head=tv(s.symbol,21,TEXT);head.setTypeface(null,Typeface.BOLD);title.addView(head);
        TextView full=tv((s.name.isEmpty()?s.symbol:s.name).toUpperCase(new Locale("tr","TR")),12,MUTED);full.setSingleLine(true);full.setEllipsize(TextUtils.TruncateAt.END);title.addView(full);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=tv(isFavorite(s.symbol)?"★":"☆",25,isFavorite(s.symbol)?YELLOW:MUTED);fav.setGravity(Gravity.CENTER);fav.setOnClickListener(v->{toggleFavorite(s.symbol);showDetail(find(s.symbol));});top.addView(fav,new LinearLayout.LayoutParams(dp(45),dp(50)));content.addView(top);
        content.addView(tv("Sektör: "+(s.sector.isEmpty()?"BIST Hisse":s.sector),10,MUTED));spacer(8);

        LinearLayout quote=card();LinearLayout qr=new LinearLayout(this);qr.setGravity(Gravity.CENTER_VERTICAL);
        detailPriceView=tv(s.price>0?formatPrice(s.price):"—",29,TEXT);detailPriceView.setTypeface(null,Typeface.BOLD);qr.addView(detailPriceView,new LinearLayout.LayoutParams(0,-2,1));
        String topDecision=s.analysisReady?(s.decisionTier==null?s.signal:s.decisionTier):"ÇOKLU ANALİZ";
        qr.addView(pill(topDecision,s.analysisReady?decisionColor(topDecision):SURFACE2),new LinearLayout.LayoutParams(dp(120),dp(34)));
        quote.addView(qr);
        detailQuoteMeta=tv(s.price>0?String.format(Locale.US,"%+.2f%% bugün • canlı fiyat dahil",s.changePct):"Canlı fiyat bekleniyor…",11,s.changePct>=0?GREEN:MUTED);quote.addView(detailQuoteMeta);
        content.addView(quote);spacer(10);

        LinearLayout hz=card();hz.addView(tv("Vade bazlı analiz",16,TEXT));hz.addView(tv("Her vade kendi geçmiş dönemini kullanır; canlı fiyat son kapanışa ayrıca uygulanır.",10,MUTED));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);
        for(String h:new String[]{HorizonAnalysis.LONG,HorizonAnalysis.MEDIUM,HorizonAnalysis.SHORT}){Button b=chip(h,h.equals(detailHorizon));b.setOnClickListener(v->{detailHorizon=h;renderDetailHorizon();});r.addView(b,new LinearLayout.LayoutParams(-2,dp(42)));spaceH(r,6);}hs.addView(r);hz.addView(hs);content.addView(hz);spacer(8);
        detailHorizonHost=new LinearLayout(this);detailHorizonHost.setOrientation(LinearLayout.VERTICAL);content.addView(detailHorizonHost);
        renderDetailHorizon();

        LinearLayout overall=card();overall.addView(tv("3 vadenin özeti",16,TEXT));
        detailHorizonSummaryHost=new LinearLayout(this);detailHorizonSummaryHost.setOrientation(LinearLayout.VERTICAL);
        overall.addView(detailHorizonSummaryHost);
        overall.addView(tv("Canlı fiyat etkisi yalnızca bu hisse detay ekranında uygulanır. Veri güncellemesi geçmiş günlük veriyi baştan indirmek yerine önceden yüklenen 3 yıllık veriyi yerelde değerlendirir.",9,MUTED));
        content.addView(overall);
        renderHorizonSummary();
        spacer(10);

        LinearLayout actions=card();actions.addView(tv("İşlemler",16,TEXT));LinearLayout ab=new LinearLayout(this);Button buy=action("SANAL AL",GREEN),sell=action("SANAL SAT",RED),alarm=action("FİYAT ALARMI",BLUE);ab.addView(buy,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(ab,6);ab.addView(sell,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(ab,6);ab.addView(alarm,new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(ab);
        EditText qty=new EditText(this);qty.setSingleLine(true);qty.setText("1");qty.setInputType(2);qty.setTextColor(TEXT);qty.setBackground(bg(SURFACE2,12));actions.addView(qty,new LinearLayout.LayoutParams(-1,dp(44)));buy.setOnClickListener(v->tradeNow(s.symbol,qty,true));sell.setOnClickListener(v->tradeNow(s.symbol,qty,false));alarm.setOnClickListener(v->setPriceAlert(s));content.addView(actions);spacer(10);

        LinearLayout more=card();more.addView(tv("Araçlar",16,TEXT));Button hist=action("Grafik & Geçmiş",BLUE);hist.setOnClickListener(v->showHistory(s));more.addView(hist);Button bt=action("Backtest çalıştır",SURFACE2);bt.setOnClickListener(v->showBacktest(s));more.addView(bt);Button cmp=action(compareSet.contains(s.symbol)?"Karşılaştırmadan çıkar":"Karşılaştırmaya ekle",SURFACE2);cmp.setOnClickListener(v->{if(compareSet.contains(s.symbol))compareSet.remove(s.symbol);else if(compareSet.size()<3)compareSet.add(s.symbol);else {toast("En fazla 3 hisse karşılaştırılabilir");return;}showDetail(s);});more.addView(cmp);content.addView(more);spacer(10);

        LinearLayout newsBox=card();newsBox.addView(tv("Haberler / KAP",16,TEXT));detailNewsList=new LinearLayout(this);detailNewsList.setOrientation(LinearLayout.VERTICAL);newsBox.addView(detailNewsList);content.addView(newsBox);news.refresh(s.symbol);

        // Only one stock-history request is made on detail entry. The 3Y data is sliced locally
        // into long/medium/short windows, which keeps the screen responsive and reduces traffic.
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){public void onBenchmarkReady(List<Candle> b,String src,String msg){detailBenchmarkBars=new ArrayList<>(b);if(!detailHistoryBars.isEmpty()&&!detailHistoryFailed)computeDetailHorizons(s.symbol,src,msg);renderDetailHorizon();}});
        history.load(s.symbol,"3Y",this);
    }

    void addHorizonSummaryRow(LinearLayout host,String horizon,String label,String code){
        HorizonAnalysis.Result x=horizonResults.get(horizon);
        String text;
        if(x==null && detailHistoryFailed){
            text=label+" • Geçmiş veri alınamadı";
        }else if(x==null){
            text=label+" • Analiz hazırlanıyor…";
        }else if(!x.ready){
            text=label+" • Veri yetersiz/ulaşılamadı"+(x.reason==null||x.reason.isEmpty()?"":" • "+x.reason);
        }else{
            String decision=x.decisionTier==null?x.signal:x.decisionTier;
            text=label+" • "+decision+" • Teknik "+x.technicalRatingLabel+" ("+String.format(Locale.US,"%+.2f",x.technicalRating)+") • "+x.conditionsMet+"/"+x.conditionsTotal+" teyit • dönem "+String.format(Locale.US,"%+.1f%%",x.periodReturnPct)+(x.estimatedTargetDays>0?" • süre "+x.estimatedTargetTime:"");
        }
        TextView t=tv(text,11,TEXT);
        host.addView(t);
        t.setPadding(dp(4),dp(7),dp(4),dp(7));
    }

    void renderHorizonSummary(){
        if(detailHorizonSummaryHost==null)return;
        detailHorizonSummaryHost.removeAllViews();
        addHorizonSummaryRow(detailHorizonSummaryHost,HorizonAnalysis.LONG,"Yıllık","1Y");
        addHorizonSummaryRow(detailHorizonSummaryHost,HorizonAnalysis.MEDIUM,"Aylık","1A");
        addHorizonSummaryRow(detailHorizonSummaryHost,HorizonAnalysis.SHORT,"Kısa","5-20G");
    }

    int decisionColor(String decision){
        if("AL".equals(decision))return GREEN;
        if("SAT".equals(decision))return RED;
        if("AL ADAYI".equals(decision))return CYAN;
        return YELLOW;
    }

    void renderDetailHorizon(){
        if(detailHorizonHost==null)return;
        detailHorizonHost.removeAllViews();
        renderHorizonSummary();
        HorizonAnalysis.Result r=horizonResults.get(detailHorizon);
        if(r==null){
            if(detailHistoryFailed){
                LinearLayout e=card();
                e.addView(tv("GEÇMİŞ VERİ ALINAMADI",16,YELLOW));
                e.addView(tv(detailHistoryError==null||detailHistoryError.isEmpty()?"Bağlantı veya tarihsel veri kaynağı yanıt vermedi.":detailHistoryError,11,MUTED));
                detailHorizonHost.addView(e);
            }else{
                detailHorizonHost.addView(tv("Geçmiş 3 yıllık veri hazırlanıyor…",12,MUTED));
            }
            return;
        }
        if(!r.ready){
            LinearLayout wait=card();
            wait.addView(tv("VERİ YETERSİZ",18,YELLOW));
            wait.addView(tv(r.reason==null||r.reason.isEmpty()?"Bu vade için analiz üretilemedi.":r.reason,11,MUTED));
            detailHorizonHost.addView(wait);
            return;
        }

        LinearLayout c=card();
        String decision=r.decisionTier==null?r.signal:r.decisionTier;
        TextView big=tv("GİRİŞ KARARI: "+decision,20,decisionColor(decision));
        big.setTypeface(null,Typeface.BOLD);c.addView(big);
        c.addView(tv("Teknik rating: "+r.technicalRatingLabel+" • skor "+String.format(Locale.US,"%+.2f",r.technicalRating)+" • AI güven "+String.format(Locale.US,"%.0f/100",r.confidence),11,TEXT));
        c.addView(tv("7 koşul: "+r.conditionsMet+"/"+r.conditionsTotal+" • Teknik AL, final giriş kararı değildir. • Veri: "+r.barsUsed+" günlük",11,CYAN));
        c.addView(tv(r.periodLabel+" • Risk: "+r.risk+" • Trend: "+r.trend+" • Haftalık: "+r.stage,10,CYAN));
        c.addView(tv("Model hedef zamanı: "+(r.estimatedTargetDays>0?r.estimatedTargetTime+" (yaklaşık "+r.estimatedTargetDays+" işlem günü)":"Bu sinyalde hedef süre hesaplanmadı"),11,TEXT));
        c.addView(tv("Dönem getirisi: "+String.format(Locale.US,"%+.2f%%",r.periodReturnPct)+" • Canlı fiyat: "+formatPrice(r.livePrice)+" • Son kapanış: "+formatPrice(r.historicalLast)+" • Canlı etki: "+String.format(Locale.US,"%+.0f",r.liveScoreAdjustment),10,MUTED));

        if(r.decisionWhy!=null&&!r.decisionWhy.isEmpty()){
            c.addView(tv("NEDEN?",13,TEXT));
            c.addView(tv(r.decisionWhy,10,MUTED));
        }
        if("AL ADAYI".equals(decision)&&r.gateReasons!=null&&!r.gateReasons.isEmpty())
            c.addView(tv("AL'A KALAN: "+r.gateReasons,10,YELLOW));
        if("BEKLE".equals(decision)&&r.technicalRatingLabel!=null&&r.technicalRatingLabel.contains("AL"))
            c.addView(tv("NEDEN TEKNİK AL AMA GİRİŞ DEĞİL? "+r.conditionsMet+"/7 ana teyit var; fiyat/güvenlik kapıları tamamlanmadan yeni alım açılmıyor.",10,YELLOW));
        c.addView(tv(r.reason,10,MUTED));

        LinearLayout targets=card();targets.setPadding(dp(12),dp(12),dp(12),dp(12));targets.addView(tv("Model fiyat potansiyeli",15,TEXT));
        targets.addView(tv("Alt band   "+formatPrice(r.modelLow),11,TEXT));
        targets.addView(tv("Baz hedef  "+formatPrice(r.modelBase)+"   ("+String.format(Locale.US,"+%.1f%%",r.upsidePct)+")",12,TEXT));
        targets.addView(tv("Üst band   "+formatPrice(r.modelHigh)+"   ("+String.format(Locale.US,"+%.1f%%",r.upsideHighPct)+")",11,TEXT));
        if(r.support>0)targets.addView(tv("Destek: "+formatPrice(r.support)+(r.resistance>0?" • Direnç: "+formatPrice(r.resistance):""),10,MUTED));
        if(r.entryLow>0 && r.entryHigh>0)targets.addView(tv("Canlı giriş bölgesi: "+formatPrice(r.entryLow)+" – "+formatPrice(r.entryHigh),10,MUTED));
        if(r.stop>0)targets.addView(tv("Teknik stop: "+formatPrice(r.stop)+" • T1: "+formatPrice(r.target1)+" • T2: "+formatPrice(r.target2),10,MUTED));
        targets.addView(tv("Bu hedefler uygulamanın teknik model bantlarıdır; dış kurum analist konsensüsü değildir.",9,MUTED));
        detailHorizonHost.addView(c);spacerIn(detailHorizonHost,8);detailHorizonHost.addView(targets);
    }

    void addSignalCard(Stock s){
        LinearLayout c=card();
        c.addView(tv("KARAR VE TEKNİK DURUM",16,TEXT));
        if(!s.analysisReady){c.addView(tv("Geçmiş tam OHLCV verisi bekleniyor.",11,MUTED));content.addView(c);return;}
        String decision=s.decisionTier==null?s.signal:s.decisionTier;
        TextView big=tv("GİRİŞ KARARI: "+decision,20,decisionColor(decision));big.setTypeface(null,Typeface.BOLD);c.addView(big);
        c.addView(tv("Teknik rating: "+s.technicalRatingLabel+" • skor "+String.format(Locale.US,"%.2f",s.technicalRating)+" • "+s.technicalBuyCount+" AL / "+s.technicalNeutralCount+" NÖTR / "+s.technicalSellCount+" SAT",11,TEXT));
        LinearLayout checks=card();checks.setPadding(dp(12),dp(10),dp(12),dp(10));checks.addView(tv("Sinyal koşulları: "+s.conditionsMet+"/"+s.conditionsTotal+"  (5/7 adaydır; son karar piyasa, trend, giriş, stop ve R/R filtrelerinden geçer)",12,TEXT));
        String[] labels={"RSI","MACD","EMA20 > EMA50","Hacim","Trend","Destek","Momentum"};
        boolean[] ok={s.rsiOk,s.macdOk,s.emaOk,s.volumeOk,s.trendOk,s.supportOk,s.momentumOk};
        for(int i=0;i<labels.length;i++)checks.addView(tv((ok[i]?"✓ ":"✗ ")+labels[i],10,ok[i]?GREEN:RED));
        c.addView(checks);
        c.addView(tv("AI karar motoru: "+s.aiSignal+" • " + AnalysisEngine.conditionSummary(s),11,TEXT));
        c.addView(tv("Kurulum: "+s.setupType+" • Haftalık: "+s.stage+" • Piyasa: "+s.marketRegime,11,TEXT));
        c.addView(tv(String.format(Locale.US,"ADX %.1f • +DI %.1f / -DI %.1f • RS(BIST100) %+.1f%% • Gap %+.1f%%",s.adx,s.diPlus,s.diMinus,s.relativeStrengthPct,s.dailyGapPct),10,MUTED));
        c.addView(tv("Hacim "+String.format(Locale.US,"%.2fx",s.volumeRatio)+" • OBV "+String.format(Locale.US,"%+.1f%%",s.obvSlopePct)+" • "+(s.distributionFlag?"Dağıtım baskısı":"Dağıtım baskısı yok")+" • "+(s.volatilityShock?"Volatilite şoku":"Volatilite normal"),10,MUTED));
        if(portfolio.qty(s.symbol)>0){PortfolioAlertEngine.Decision pd=PortfolioAlertEngine.preview(this,s.symbol,s.price,s);c.addView(tv("POZİSYON YÖNETİMİ: "+PortfolioAlertEngine.levelName(pd.level)+" • "+(pd.title.length()>0?pd.title:s.management),11,CYAN));c.addView(tv(pd.message.length()>0?pd.message:"Pozisyon açık; stop, hedef ve tepe geri çekilmesi izleniyor.",10,MUTED));}
        else c.addView(tv("POZİSYON YÖNETİMİ: Yeni pozisyon yok • mevcut işlem olmadığından satış uyarısı üretilmez.",10,MUTED));
        LinearLayout why=card();
        why.addView(tv("NEDEN "+s.signal,15,TEXT));
        TextView whyMain=tv(s.decisionWhy==null||s.decisionWhy.isEmpty()?s.reason:s.decisionWhy,11,TEXT);
        whyMain.setPadding(0,dp(4),0,dp(8));why.addView(whyMain);
        if(s.positiveReasons!=null&&!s.positiveReasons.isEmpty())why.addView(tv("✓ Olumlu: "+s.positiveReasons,10,GREEN));
        if(s.negativeReasons!=null&&!s.negativeReasons.isEmpty())why.addView(tv("✗ Zayıf/negatif: "+s.negativeReasons,10,RED));
        if(s.gateReasons!=null&&!s.gateReasons.isEmpty())why.addView(tv("⚠ Kararı etkileyen filtreler: "+s.gateReasons,10,YELLOW));
        if("AL ADAYI".equals(s.decisionTier)&&!"AL".equals(s.signal))why.addView(tv("AL ADAYI: Teknik yapı yeterince güçlü; final AL için yukarıdaki filtrelerden kalanların tamamlanması bekleniyor.",10,CYAN));
        c.addView(why);
        content.addView(c);
    }
    void addPricePlanCard(Stock s){LinearLayout c=card();c.addView(tv("Fiyat planı",16,TEXT));if(!s.analysisReady){c.addView(tv("Analiz hazır olduğunda giriş, zarar durdur ve hedef seviyeleri burada görünür.",11,MUTED));}else{c.addView(metricLine("Önerilen giriş aralığı",s.entryLow,s.entryHigh));c.addView(metricLine("Zarar durdur",s.stopPrice));c.addView(metricLine("Hedef 1 • %50",s.targetPrice));c.addView(metricLine("Hedef 2 • kalan",s.targetPrice2));c.addView(metricLine("ATR trailing stop",s.trailingStop));c.addView(tv(String.format(Locale.US,"Stop riski %.2f%% • R/R T1 %.2f • T2 %.2f",s.stopPct,s.rr1,s.rr2),10,MUTED));c.addView(tv(String.format(Locale.US,"Model pozisyon boyutu: %d adet • ≈ %%%.1f nominal",s.suggestedQty,s.suggestedPositionPct),10,MUTED));c.addView(tv("Giriş bölgesi: "+(s.entryZoneOk?"uygun":"bekle/kovalama yapma")+" • Plan: "+s.management,10,MUTED));c.addView(tv("Güvenlik: "+s.safety,10,MUTED));c.addView(tv("Bunlar algoritmik seviyelerdir; kesin emir veya getiri garantisi değildir. İşlem sinyali oluşsa bile emir gerçekleşme fiyatı farklı olabilir.",9,MUTED));}content.addView(c);}
    TextView metricLine(String label,double val){return tv(label+"   "+formatPrice(val),12,TEXT);}
    TextView metricLine(String label,double a,double b){return tv(label+"   "+formatPrice(a)+" – "+formatPrice(b),12,TEXT);}

    void showHistory(Stock s){if(s==null)return;screen=Screen.HISTORY;current=s;clear();content.addView(tv(s.symbol+" • Grafik & Geçmiş",25,TEXT));content.addView(tv("Günlük OHLCV • mum/çizgi • dokunarak tarih ve kapanış",11,MUTED));spacer(8);LinearLayout modes=new LinearLayout(this);Button mum=chip("Mum",historyMode.equals("Mum")),line=chip("Çizgi",historyMode.equals("Çizgi"));modes.addView(mum,new LinearLayout.LayoutParams(0,dp(40),1));spaceH(modes,6);modes.addView(line,new LinearLayout.LayoutParams(0,dp(40),1));content.addView(modes);mum.setOnClickListener(v->{historyMode="Mum";historyChart.setMode(HistoryChartView.Mode.CANDLE);});line.setOnClickListener(v->{historyMode="Çizgi";historyChart.setMode(HistoryChartView.Mode.LINE);});spacer(8);
        LinearLayout ranges=card();ranges.addView(tv("Dönem",15,TEXT));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=new LinearLayout(this);for(String x:new String[]{"1A","3A","6A","1Y","3Y","5Y"}){Button b=chip(x,x.equals(historyRange));r.addView(b,new LinearLayout.LayoutParams(-2,dp(38)));spaceH(r,5);b.setOnClickListener(v->{historyRange=x;history.load(s.symbol,x,this);});}hs.addView(r);ranges.addView(hs);content.addView(ranges);spacer(8);
        historyChart=new HistoryChartView(this);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);content.addView(historyChart,new LinearLayout.LayoutParams(-1,dp(355)));historyInfo=tv("Geçmiş veri yükleniyor…",10,MUTED);content.addView(historyInfo);history.load(s.symbol,historyRange,this);
    }

    void showBacktest(Stock s){
        if(s==null)return;
        screen=Screen.BACKTEST;
        selectNav("Piyasa");
        clear();
        content.addView(tv(s.symbol+" • Backtest",25,TEXT));
        content.addView(tv("Aynı sinyal motorunu geçmiş günlük veride sınar",11,MUTED));
        spacer(10);
        TextView info=tv("Dönem: 3Y • başlangıç 100.000 ₺ • komisyon %0,20 • tahmini kayma %0,05/yan • T1 %50 + trailing",11,MUTED);
        content.addView(info);
        spacer(8);
        Button run=action("Backtesti çalıştır",BLUE);
        content.addView(run);
        LinearLayout box=card();
        box.addView(tv("Sonuç",16,TEXT));
        box.addView(tv("Henüz çalıştırılmadı.",11,MUTED));
        content.addView(box);
        run.setOnClickListener(v->runBacktest(s,box));
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){
            public void onBenchmarkReady(List<Candle> b,String src,String msg){
                history.load(s.symbol,"3Y",new HistoryService.Listener(){
                    public void onHistory(String sym,String range,List<Candle> bars,String source,String msg2){
                        if(bars.size()>=35){
                            info.setText("Dönem: "+bars.size()+" günlük veri • kaynak: "+source+" • %0,20 komisyon • tahmini kayma %0,05/yan • benchmark "+(b.isEmpty()?"yok":"XU100"));
                        } else info.setText(msg2);
                    }
                });
            }
        });
    }

    void runBacktest(Stock s,LinearLayout box){
        history.loadBenchmark("3Y",new HistoryService.BenchmarkListener(){
            public void onBenchmarkReady(List<Candle> bench,String bs,String bm){
                history.load(s.symbol,"3Y",new HistoryService.Listener(){
                    public void onHistory(String sym,String range,List<Candle> bars,String source,String msg){
                        box.removeAllViews();
                        if(bars.size()<AnalysisEngine.MIN_DEEP_BARS+2||!AnalysisEngine.hasFullOhlcv(bars)){
                            box.addView(tv("Backtest için yeterli tam OHLCV veri yok.",12,MUTED));
                            return;
                        }
                        BacktestEngine.Result r=BacktestEngine.run(bars,strategy,bench);
                        box.addView(tv(String.format(Locale.US,"Başlangıç %.2f ₺",r.startCash),12,TEXT));
                        box.addView(tv(String.format(Locale.US,"Bitiş %.2f ₺",r.endCash),20,TEXT));
                        box.addView(tv(String.format(Locale.US,"Getiri %+.2f%%",r.returnPct),14,r.returnPct>=0?GREEN:RED));
                        box.addView(tv("İşlem "+r.trades+" • Kazanan "+r.wins+" • Kaybeden "+r.losses,12,TEXT));
                        box.addView(tv(String.format(Locale.US,"Kazanma %.1f%% • Maks. düşüş %.1f%% • Kâr faktörü %.2f",r.winRate,r.maxDrawdownPct,r.profitFactor),11,MUTED));
                        box.addView(tv(String.format(Locale.US,"T1 %d • T2 %d • Stop %d • Sinyal çıkışı %d • Atlanan %d",r.target1Hits,r.target2Hits,r.stopHits,r.signalExits,r.skippedPlans),11,TEXT));
                        box.addView(tv(String.format(Locale.US,"Ortalama kazanç %+.2f%% • Ortalama kayıp -%.2f%% • Beklenti %+.2f%% • Max ardışık kayıp %d",r.avgWinPct,r.avgLossPct,r.expectancyPct,r.maxConsecutiveLosses),11,MUTED));
                        if(!bench.isEmpty())box.addView(tv("Piyasa filtresi: XU100 kullanıldı • "+bs,10,MUTED));
                        for(int i=Math.max(0,r.log.size()-10);i<r.log.size();i++)box.addView(tv(r.log.get(i),10,TEXT));
                    }
                });
            }
        });
    }

    void showCompare(){screen=Screen.COMPARE;selectNav("Ana");clear();content.addView(tv("Hisse karşılaştırma",25,TEXT));content.addView(tv("En fazla 3 hisse",11,MUTED));spacer(10);if(compareSet.isEmpty()){content.addView(tv("Henüz hisse seçilmedi.",12,MUTED));content.addView(tv("Bir hissenin detayında “Karşılaştırmaya ekle” butonunu kullan.",11,MUTED));return;}for(String sym:compareSet){Stock s=find(sym);if(s==null)continue;LinearLayout c=card();c.addView(tv(sym+" • "+formatPrice(s.price),16,TEXT));c.addView(tv("Sinyal: "+(s.analysisReady?s.signal:"BEKLE")+" • RSI "+String.format(Locale.US,"%.1f",s.rsi)+" • MACD "+(s.macd>s.macdSignal?"✓":"—"),11,MUTED));c.addView(tv("EMA20/50 "+(s.ema20>s.ema50?"✓":"—")+" • Trend "+s.trend+" • Hacim "+String.format(Locale.US,"%.2fx",s.volumeRatio),11,TEXT));content.addView(c);spacer(6);}}

    void showSignals(){
        screen=Screen.SIGNALS;clear();content.addView(tv("Sinyal geçmişi",25,TEXT));content.addView(tv("Sinyal değişimleri ve bugünkü fiyata göre görünüm",11,MUTED));spacer(10);
        JSONArray a=signals.history();
        if(a.length()==0){content.addView(tv("Henüz kayıt yok. Önce AI Tarama çalıştır.",12,MUTED));return;}
        int al=0,sat=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String n=o.optString("new");if("AL".equals(n))al++;if("SAT".equals(n))sat++;}
        LinearLayout summary=card();summary.addView(tv("Özet",16,TEXT));summary.addView(tv("Toplam "+a.length()+" değişim • AL "+al+" • SAT "+sat,12,TEXT));content.addView(summary);spacer(8);
        for(int i=a.length()-1;i>=0;i--){JSONObject o=a.optJSONObject(i);if(o==null)continue;String sym=o.optString("symbol");double px=o.optDouble("price",0),now=find(sym)!=null?find(sym).price:0,perf=0;if(px>0&&now>0)perf="AL".equals(o.optString("new"))?(now/px-1)*100:(px/now-1)*100;LinearLayout c=card();c.addView(tv(sym+" • "+o.optString("new"),15,TEXT));c.addView(tv(formatPrice(px)+" • "+o.optInt("met")+"/"+AnalysisEngine.TOTAL_CONDITIONS+" koşul • "+time(o.optLong("time")),10,MUTED));if(now>0)c.addView(tv(String.format(Locale.US,"Sinyal fiyatından bugüne: %+.2f%%",perf),10,perf>=0?GREEN:RED));content.addView(c);spacer(6);}
    }

    void showPortfolio(){
        screen=Screen.PORTFOLIO;selectNav("Portföy");clear();
        content.addView(tv("Sanal portföy",27,TEXT));
        content.addView(tv("Model öğrenmesinden ayrı: yalnızca senin sanal işlemlerin izlenir.",11,MUTED));spacer(10);
        double value=portfolioValue(), pnl=value-100000.0;
        LinearLayout box=card();box.addView(tv("Toplam değer",11,MUTED));box.addView(tv(String.format(Locale.US,"%.2f ₺",value),27,TEXT));
        box.addView(tv(String.format(Locale.US,"Toplam K/Z %+.2f ₺ • %+.2f%%",pnl,(pnl/100000.0)*100.0),13,pnl>=0?GREEN:RED));
        box.addView(tv(String.format(Locale.US,"Nakit %.2f ₺ • Pozisyon %d • Komisyon %.2f%%",portfolio.cash(),positionCount(),.2),10,MUTED));
        boolean monitorOn=getSharedPreferences("settings",0).getBoolean("portfolio_alerts_enabled",true);
        box.addView(tv("5 dk portföy izleme: "+(monitorOn?"AÇIK":"KAPALI")+" • Son kontrol: "+monitorTimeLabel(),10,monitorOn?GREEN:MUTED));
        content.addView(box);spacer(10);

        LinearLayout pos=card();pos.addView(tv("Pozisyonlar",17,TEXT));boolean any=false;
        for(String sym:portfolio.symbols()){
            int q=portfolio.qty(sym);if(q<=0)continue;any=true;Stock st=find(sym);double px=st!=null?st.price:0,avg=portfolio.avgCost(sym);
            PortfolioAlertEngine.Decision d=px>0?PortfolioAlertEngine.preview(this,sym,px,st):new PortfolioAlertEngine.Decision();
            double pnlTl=px>0?(px-avg)*q:0, pnlPct=avg>0&&px>0?(px/avg-1)*100:0;
            LinearLayout pc=card();pc.setPadding(dp(12),dp(12),dp(12),dp(12));
            LinearLayout hd=new LinearLayout(this);hd.setGravity(Gravity.CENTER_VERTICAL);hd.addView(tv(sym+" • "+q+" adet",14,TEXT),new LinearLayout.LayoutParams(0,-2,1));
            String state=PortfolioAlertEngine.levelName(d.level);hd.addView(pill(state,d.level>=PortfolioAlertEngine.STOP?RED:d.level>=PortfolioAlertEngine.TRAILING?YELLOW:d.level>0?YELLOW:SURFACE2),new LinearLayout.LayoutParams(dp(105),dp(28)));pc.addView(hd);
            pc.addView(tv("Maliyet "+formatPrice(avg)+" • Son "+formatPrice(px)+" • Değer "+formatPrice(px*q),11,TEXT));
            pc.addView(tv(String.format(Locale.US,"K/Z %+.2f ₺ • %+.2f%% • Tepe %s • Tepeden %+.2f%%",pnlTl,pnlPct,formatPrice(d.peak),d.drawdownPct),11,pnlPct>=0?GREEN:RED));
            if(d.protectionLevel>0)pc.addView(tv("Kâr koruma seviyesi "+formatPrice(d.protectionLevel)+" • Tepe kâr "+String.format(Locale.US,"%+.2f%%",d.peakProfitPct),10,MUTED));
            pc.addView(tv("Zarar koruma "+formatPrice(d.stopLevel)+" • T1 "+formatPrice(portfolio.planTarget1(sym))+" • T2 "+formatPrice(portfolio.planTarget2(sym)),10,MUTED));
            if(st!=null&&st.analysisReady)pc.addView(tv("AI "+st.aiSignal+" • Teknik "+st.technicalRatingLabel+" • Günlük "+String.format(Locale.US,"%+.2f%%",st.changePct),10,CYAN));
            if(d.level>0)pc.addView(tv(d.title.length()>0?d.title+" • "+d.message.replace("\\n"," • "):PortfolioAlertEngine.levelName(d.level),10,d.level>=PortfolioAlertEngine.TRAILING?YELLOW:RED));
            Button detail=chip("Detaya git",false);detail.setOnClickListener(v->{Stock x=find(sym);if(x!=null)showDetail(x);});pc.addView(detail);pos.addView(pc);spacerIn(pos,7);
        }
        if(!any)pos.addView(tv("Henüz pozisyon yok. Bir hissenin detayından SANAL AL ile ekleyebilirsin.",11,MUTED));
        content.addView(pos);spacer(8);

        LinearLayout alarms=card();alarms.addView(tv("Son portföy alarmları",16,TEXT));JSONArray hist=new PortfolioAlertStore(this).history();
        if(hist.length()==0)alarms.addView(tv("Henüz alarm oluşmadı. Sistem yaklaşık 5 dakikalık döngüyle mevcut veri kaynağından pozisyon riskini kontrol eder; zarar durdur, kâr koruma, teknik zayıflama ve güçlü bozulma durumlarını ayrı izler.",11,MUTED));
        else for(int i=hist.length()-1;i>=0&&i>=hist.length()-8;i--){JSONObject o=hist.optJSONObject(i);if(o==null)continue;alarms.addView(tv(o.optString("symbol")+" • "+o.optString("title")+" • "+time(o.optLong("time")),10,TEXT));alarms.addView(tv(o.optString("detail").replace("\\n"," • "),9,MUTED));spacerIn(alarms,5);}
        content.addView(alarms);spacer(8);

        LinearLayout tr=card();tr.addView(tv("Son işlemler",16,TEXT));JSONArray a=portfolio.tradeHistory();if(a.length()==0)tr.addView(tv("İşlem geçmişi boş.",11,MUTED));else for(int i=a.length()-1;i>=0&&i>=a.length()-8;i--){JSONObject o=a.optJSONObject(i);tr.addView(tv(o.optString("symbol")+" "+o.optString("side")+" "+o.optInt("qty")+" @ "+formatPrice(o.optDouble("price"))+" • komisyon "+formatPrice(o.optDouble("fee")),10,TEXT));}content.addView(tr);spacer(8);
        Button reset=action("Portföyü sıfırla",YELLOW);reset.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Portföy sıfırlansın mı?").setMessage("100.000 ₺ ile yeniden başlatılacak. Pozisyon tepe/plan/uyarı hafızası da temizlenecek.").setNegativeButton("Vazgeç",null).setPositiveButton("Sıfırla",(d,w)->{portfolio.reset();new PortfolioAlertStore(this).clearAll();stopPortfolioMonitorService();showPortfolio();}).show();});content.addView(reset);
    }
    double portfolioValue(){double v=portfolio.cash();for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);Stock s=find(sym);if(s!=null&&s.price>0)v+=s.price*q;}return v;}

    void showLearning(){showData();}

    void showData(){
        screen=Screen.DATA;selectNav("Veri");clear();content.addView(tv("Veri",27,TEXT));content.addView(tv("Model öğrenmesi ve sanal portföy verileri birbirinden ayrı tutulur.",11,MUTED));spacer(10);
        LinearLayout model=card();model.addView(tv("🧠 Model Öğrenmesi",18,TEXT));
        PredictionStore.Report pr=new PredictionStore(this).report();JSONObject prof=learning.profile();
        model.addView(tv("Toplam karar kaydı: "+pr.decisions+" • "+new PredictionStore(this).decisionSummary()+" • Öğrenme örneği: "+learning.sampleCount(),11,TEXT));
        model.addView(tv("Açık tahmin: "+pr.open+" • Sonuçlanan AL tahminleri: "+pr.closed+" • Pozitif "+pr.wins+" • Negatif "+pr.losses,11,TEXT));
        model.addView(tv(String.format(Locale.US,"Pozitif %d • Negatif %d • Win rate %.1f%% • Ortalama sonuç %+.2f%%",pr.wins,pr.losses,pr.winRate,pr.avgPnl),11,TEXT));
        model.addView(tv("Son öğrenme: "+(learning.lastRun()>0?time(learning.lastRun()):"henüz yok")+" • Profil: "+(learning.active()?"AKTİF":"PASİF"),10,MUTED));
        if(prof.length()>0)model.addView(tv("Profil ağırlıkları: "+prof.toString(),9,MUTED));
        LinearLayout fs=new LinearLayout(this);fs.setOrientation(LinearLayout.VERTICAL);fs.addView(tv("Koşul bazlı gözlem",12,TEXT));
        JSONArray samples=learning.learningSamples();for(String key:new String[]{"rsi","macd","ema","volume","trend","support","momentum"}){int total=0,wins=0;for(int i=0;i<samples.length();i++){JSONObject o=samples.optJSONObject(i);if(o!=null&&o.optBoolean(key,false)){total++;if(o.optBoolean("win",false))wins++;}}String pct=total>0?String.format(Locale.US,"%.1f%%",wins*100.0/total):"—";fs.addView(tv(key.toUpperCase(Locale.US)+" • etkin örnek "+total+" • başarı "+pct,10,TEXT));}
        model.addView(fs);Button learnNow=action("Öğrenme taramasını şimdi kuyruğa al",BLUE);learnNow.setOnClickListener(v->{SelfLearningScheduler.runNow(this);toast("Model öğrenme taraması kuyruğa alındı");});model.addView(learnNow);content.addView(model);spacer(8);

        LinearLayout port=card();port.addView(tv("💼 Sanal Portföy",18,TEXT));double pv=portfolioValue();port.addView(tv(String.format(Locale.US,"Toplam değer %.2f ₺ • Toplam K/Z %+.2f ₺",pv,pv-100000),12,TEXT));port.addView(tv("Pozisyon: "+positionCount()+" • Son kontrol: "+monitorTimeLabel(),10,MUTED));Button pg=action("Sanal portföyü aç",GREEN);pg.setOnClickListener(v->showPortfolio());port.addView(pg);content.addView(port);spacer(8);

        LinearLayout liveBox=card();liveBox.addView(tv("⚡ Canlı veri teşhisi",18,TEXT));boolean enabled=getSharedPreferences("settings",0).getBoolean("itick_enabled",false);String token=getSharedPreferences("settings",0).getString("itick_token","").trim();long qt=getSharedPreferences("runtime",0).getLong("last_quote_time",0L);String qs=getSharedPreferences("runtime",0).getString("quote_source","");
        liveBox.addView(tv("Sağlayıcı: "+(enabled&&!token.isEmpty()?"iTick • BIST gerçek zamanlı":"Kurulmadı / gecikmeli fallback"),11,enabled&&!token.isEmpty()?GREEN:YELLOW));liveBox.addView(tv("Son kotasyon: "+(qt>0?time(qt):"—")+(qt>0?" • yaş "+quoteAgeLabel(qt):""),11,TEXT));liveBox.addView(tv("Kaynak etiketi: "+(qs.isEmpty()?"—":qs),10,MUTED));liveBox.addView(tv("Anlık veri bu sürümde opsiyoneldir. Kullanılmayan sağlayıcı için sahte canlı fiyat üretilmez.",10,MUTED));Button set=chip("Veri kaynağı ayarları",false);set.setOnClickListener(v->showSettings());liveBox.addView(set);content.addView(liveBox);spacer(8);

        LinearLayout ah=card();ah.addView(tv("🔔 Portföy alarm geçmişi",18,TEXT));JSONArray ahj=new PortfolioAlertStore(this).history();if(ahj.length()==0)ah.addView(tv("Henüz kayıt yok.",11,MUTED));else for(int i=ahj.length()-1;i>=0&&i>=ahj.length()-12;i--){JSONObject o=ahj.optJSONObject(i);if(o==null)continue;ah.addView(tv(o.optString("symbol")+" • "+o.optString("title")+" • "+time(o.optLong("time")),10,TEXT));ah.addView(tv(o.optString("detail").replace("\\n"," • "),9,MUTED));spacerIn(ah,5);}content.addView(ah);spacer(8);
        LinearLayout note=card();note.addView(tv("Önemli ayrım",16,TEXT));note.addView(tv("Model öğrenmesi sen işlem yapmasan bile üretilen sinyalleri takip eder. Sanal portföy ise yalnızca senin SANAL AL/SAT işlemlerini izler. Portföy alarmı otomatik emir göndermez; yalnızca uyarır.",10,MUTED));content.addView(note);
    }

    int positionCount(){int n=0;for(String sym:portfolio.symbols())if(portfolio.qty(sym)>0)n++;return n;}
    String monitorTimeLabel(){long t=new PortfolioAlertStore(this).lastNotified("__monitor__");long m=getSharedPreferences("runtime",0).getLong("portfolio_last_monitor",0L);return m>0?time(m):"henüz yok";}
    String quoteAgeLabel(long t){long sec=Math.max(0,(System.currentTimeMillis()-t)/1000L);if(sec<60)return sec+" sn";return (sec/60)+" dk";}

    void showSettings(){
        screen=Screen.SETTINGS;selectNav("Ayar");clear();content.addView(tv("Ayarlar",27,TEXT));content.addView(tv("Analiz, sanal portföy, alarm, öğrenme ve veri kaynağı ayarları",11,MUTED));spacer(10);
        LinearLayout strategyBox=card();strategyBox.addView(tv("Analiz stratejisi",16,TEXT));Spinner strategySp=new Spinner(this);String[] opts={"Dengeli","Trend","Momentum","Kısa Vadeli"};ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts){public View getView(int pos,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,v,parent);t.setTextColor(TEXT);t.setPadding(dp(8),0,dp(8),0);return t;}};strategySp.setAdapter(ad);strategySp.setSelection(Math.max(0,Arrays.asList(opts).indexOf(strategy)));strategyBox.addView(strategySp);content.addView(strategyBox);spacer(8);

        android.content.SharedPreferences sp=getSharedPreferences("settings",0);
        LinearLayout dataBox=card();dataBox.addView(tv("Veri kaynağı (opsiyonel)",17,TEXT));dataBox.addView(tv("Anlık veri şu sürümde öncelik değildir. Uygulama varsayılan olarak İş Yatırım/yedek geçmiş veri akışını kullanır. İleride ForInvest, Matriks, dxFeed veya iTick adaptörü eklenebilir.",10,MUTED));
        Switch itickS=new Switch(this);itickS.setText("iTick harici kotasyonu etkinleştir (opsiyonel)");itickS.setTextColor(TEXT);itickS.setChecked(sp.getBoolean("itick_enabled",false));dataBox.addView(itickS);
        EditText itickToken=field("iTick API Token",sp.getString("itick_token",""));itickToken.setInputType(129);dataBox.addView(itickToken);
        Button getKey=chip("iTick ücretsiz API anahtarı sayfası",false);getKey.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://itick.org/en")));}catch(Exception e){toast("Tarayıcı açılamadı");}});dataBox.addView(getKey);
        dataBox.addView(tv("Durum: "+(itickS.isChecked()&&!itickToken.getText().toString().trim().isEmpty()?"HAZIR • "+dataSourceLabel():"Token girilmesi bekleniyor"),10,itickS.isChecked()&&!itickToken.getText().toString().trim().isEmpty()?GREEN:YELLOW));
        dataBox.addView(tv("⚠ Bu uygulama veriyi gösterir. Borsa İstanbul'un eş-anlı verileri lisanslı veri dağıtıcıları üzerinden sunulur; iTick de kendi kullanım/dağıtım şartlarına tabidir.",9,MUTED));
        content.addView(dataBox);spacer(8);

        LinearLayout alertBox=card();alertBox.addView(tv("🔔 Sanal portföy akıllı alarmı",17,TEXT));alertBox.addView(tv("Pozisyonlarını yaklaşık 5 dakikalık döngüyle mevcut veri kaynağından kontrol eder. Alış maliyetini, gördüğü tepeyi, geri çekilmeyi, teknik stopu ve hedefleri ayrı değerlendirir. Aynı alarmı her kontrolde spamlamaz.",10,MUTED));
        Switch portfolioS=new Switch(this);portfolioS.setText("5 dk portföy risk izlemeyi etkinleştir");portfolioS.setTextColor(TEXT);portfolioS.setChecked(sp.getBoolean("portfolio_alerts_enabled",true));alertBox.addView(portfolioS);
        Switch wsS=new Switch(this);wsS.setText("Harici WebSocket kullan (opsiyonel)");wsS.setTextColor(TEXT);wsS.setChecked(sp.getBoolean("itick_ws_enabled",true));alertBox.addView(wsS);
        Switch signalS=new Switch(this);signalS.setText("Yeni AL/SAT sinyal değişim bildirimi");signalS.setTextColor(TEXT);signalS.setChecked(sp.getBoolean("alerts",false));alertBox.addView(signalS);
        Spinner lossSp=new Spinner(this);String[] lossL={"Maks. zarar %3","Maks. zarar %5","Maks. zarar %7","Maks. zarar %10","Maks. zarar %15"};float[] lossV={3,5,7,10,15};setSpinner(alertBox,lossSp,lossL,lossV,sp.getFloat("max_loss_pct",7));
        Spinner actSp=new Spinner(this);String[] actL={"Kâr koruma %5'te","Kâr koruma %10'da","Kâr koruma %15'te","Kâr koruma %20'de"};float[] actV={5,10,15,20};setSpinner(alertBox,actSp,actL,actV,sp.getFloat("profit_protect_activate_pct",10));
        Spinner peakSp=new Spinner(this);String[] peakL={"Tepe geri çekilme %10","Tepe geri çekilme %15","Tepe geri çekilme %20","Tepe geri çekilme %25","Tepe geri çekilme %30"};float[] peakV={10,15,20,25,30};setSpinner(alertBox,peakSp,peakL,peakV,sp.getFloat("peak_drawdown_pct",20));
        Spinner targetSp=new Spinner(this);String[] targetL={"Kâr hedefi %10","Kâr hedefi %15","Kâr hedefi %20","Kâr hedefi %30","Kâr hedefi %50"};float[] targetV={10,15,20,30,50};setSpinner(alertBox,targetSp,targetL,targetV,sp.getFloat("profit_target_pct",20));
        Spinner repeatSp=new Spinner(this);String[] repeatL={"Aynı kritik alarmı 15 dk sonra hatırlat","30 dk sonra","60 dk sonra","120 dk sonra","Hatırlatma kapalı"};float[] repeatV={15,30,60,120,1000000};setSpinner(alertBox,repeatSp,repeatL,repeatV,sp.getInt("alert_repeat_min",60));
        content.addView(alertBox);spacer(8);

        LinearLayout refreshBox=card();refreshBox.addView(tv("Uygulama yenilemesi",16,TEXT));refreshBox.addView(tv("Bu ayar arayüzün yenilenme sıklığını belirler. iTick ücretsiz kotasyonunun gerçek çağrı sıklığı ayrı bir güvenlik katmanıyla sınırlıdır; canlı portföy kontrolü 5 dakikadır.",10,MUTED));
        Spinner refreshSp=new Spinner(this);String[] refreshLabels={"1 sn","2 sn","3 sn","5 sn","10 sn","15 sn","20 sn","25 sn","30 sn","60 sn","120 sn","300 sn"};int[] refreshValues={1,2,3,5,10,15,20,25,30,60,120,300};ArrayAdapter<String> rad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,refreshLabels){public View getView(int pos,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(pos,v,parent);t.setTextColor(TEXT);t.setPadding(dp(8),0,dp(8),0);return t;}};refreshSp.setAdapter(rad);int saved=sp.getInt("refresh_sec",30),rp=8;for(int i=0;i<refreshValues.length;i++)if(refreshValues[i]==saved){rp=i;break;}refreshSp.setSelection(rp);refreshBox.addView(refreshSp);content.addView(refreshBox);spacer(8);

        LinearLayout learningBox=card();learningBox.addView(tv("🧠 Öğrenme",16,TEXT));Switch learningS=new Switch(this);learningS.setText("Sürekli AI öğrenme");learningS.setTextColor(TEXT);learningS.setChecked(sp.getBoolean("self_learning",true));learningBox.addView(learningS);learningBox.addView(tv("Sinyaller sürekli kaydedilir. Sonuçlar günlük değerlendirilir; model ağırlıkları en az 300 etiketli örnek ve haftalık güvenlik doğrulaması olmadan değiştirilmez.",10,MUTED));content.addView(learningBox);spacer(8);

        EditText customUrl=field("Harici Quote API URL (opsiyonel)",sp.getString("base_url",""));EditText customToken=field("Harici API Token (opsiyonel)",sp.getString("token",""));content.addView(customUrl);content.addView(customToken);spacer(8);
        Button save=action("Kaydet ve sistemi yeniden başlat",GREEN);save.setOnClickListener(v->{int[] vals={1,2,3,5,10,15,20,25,30,60,120,300};int idx=refreshSp.getSelectedItemPosition();String st=opts[strategySp.getSelectedItemPosition()];float maxLoss=selectedFloat(lossSp,lossV);float activate=selectedFloat(actSp,actV);float peak=selectedFloat(peakSp,peakV);float target=selectedFloat(targetSp,targetV);int rep=(int)selectedFloat(repeatSp,repeatV);boolean it=itickS.isChecked(), psOn=portfolioS.isChecked(), wsOn=wsS.isChecked(), sl=learningS.isChecked();sp.edit().putString("strategy",st).putBoolean("itick_enabled",it).putString("itick_token",itickToken.getText().toString().trim()).putBoolean("portfolio_alerts_enabled",psOn).putBoolean("itick_ws_enabled",wsOn).putBoolean("alerts",signalS.isChecked()).putFloat("max_loss_pct",maxLoss).putFloat("profit_protect_activate_pct",activate).putFloat("peak_drawdown_pct",peak).putFloat("profit_target_pct",target).putInt("alert_repeat_min",rep).putInt("refresh_sec",vals[idx]).putString("strategy",st).putBoolean("self_learning",sl).putString("base_url",customUrl.getText().toString().trim()).putString("token",customToken.getText().toString().trim()).apply();if(sl)SelfLearningScheduler.schedule(this);else SelfLearningScheduler.cancel(this);if(psOn)startPortfolioMonitorIfConfigured();else stopPortfolioMonitorService();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&(psOn||signalS.isChecked()))requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);toast("Ayarlar kaydedildi • portföy izleme "+(psOn?"AÇIK":"KAPALI"));restartRefresh();data.refresh();});content.addView(save);spacer(8);
        Button permission=action("Bildirim iznini kontrol et",BLUE);permission.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);else toast("Bildirim izni açık");});content.addView(permission);spacer(8);
        content.addView(tv("Not: iTick ücretsiz katman zaman sınırlıdır. Ücretsiz anahtar sona ererse uygulama otomatik olarak veri kaynağı durumunu Gecikmeli/Fallback şeklinde gösterir; sahte fiyat üretmez.",9,MUTED));
    }

    void setSpinner(LinearLayout host,Spinner sp,String[] labels,float[] values,float saved){ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels){public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);t.setTextColor(TEXT);t.setPadding(dp(8),0,dp(8),0);return t;}};sp.setAdapter(a);int pos=0;for(int i=0;i<values.length;i++)if(Math.abs(values[i]-saved)<0.01){pos=i;break;}sp.setSelection(pos);host.addView(sp);}
    float selectedFloat(Spinner sp,float[] values){return values[Math.max(0,Math.min(values.length-1,sp.getSelectedItemPosition()))];}
    int selectedInt(Spinner sp,int[] values){return values[Math.max(0,Math.min(values.length-1,sp.getSelectedItemPosition()))];}

    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(bg(SURFACE2,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(7);e.setLayoutParams(lp);return e;}

    void setPriceAlert(Stock s){if(s==null||s.price<=0){toast("Fiyat verisi yok");return;}final EditText f=field("Hedef fiyat",formatPlain(s.price));new AlertDialog.Builder(this).setTitle(s.symbol+" fiyat alarmı").setView(f).setNegativeButton("Kapat",null).setPositiveButton("Kaydet",(d,w)->{double p=parseDouble(f.getText().toString(),0);if(p<=0){toast("Geçersiz fiyat");return;}alerts.set(s.symbol,p);toast("Alarm kaydedildi: "+formatPrice(p));}).setNeutralButton("Alarmı sil",(d,w)->{alerts.clear(s.symbol);toast("Alarm silindi");}).show();}
    void tradeNow(String sym,EditText q,boolean buy){
        int qty=parseInt(q.getText().toString(),0);if(qty<=0){toast("Geçerli adet gir");return;}
        Stock s=find(sym);if(s==null||s.price<=0){toast("Güncel fiyat yok");return;}
        boolean ok=buy?portfolio.buy(sym,s.price,qty):portfolio.sell(sym,s.price,qty);
        if(ok && buy) portfolio.updatePlan(sym,s.stopPrice,s.targetPrice,s.targetPrice2);
        if(ok && portfolio.hasPositions()) startPortfolioMonitorIfConfigured();
        toast(ok?(buy?"Sanal alış yapıldı":"Sanal satış yapıldı"):"İşlem yapılamadı");if(ok)showDetail(s);
    }

    private boolean autoScanStarted=false;
    private boolean scanActive=false;

    @Override public void onData(List<Stock> stocks,boolean isLive,String msg){
        HashMap<String,Double> oldPrices=new HashMap<>();for(Stock x:all)oldPrices.put(x.symbol,x.price);
        all.clear();all.addAll(stocks);
        long now=System.currentTimeMillis();
        getSharedPreferences("runtime",0).edit().putLong("last_update",now).putLong("last_quote_time",now).putString("quote_source",dataSourceLabel()).apply();
        live=isLive;
        if(!stocks.isEmpty()){status.setText(isLive?"● CANLI":"● GECİKMELİ");status.setTextColor(isLive?GREEN:YELLOW);}else{status.setText("● VERİ YOK");status.setTextColor(YELLOW);}
        statusMessage.setText(msg+(now>0?" • "+time(now):""));
        PredictionStore predictions=new PredictionStore(this);
        for(Stock x:all){double old=oldPrices.containsKey(x.symbol)?oldPrices.get(x.symbol):x.price;if(alerts.checkAndClear(x.symbol,old,x.price))sendPriceAlert(x);}
        predictions.observeQuotes(all,now);
        boolean portfolioOn=getSharedPreferences("settings",0).getBoolean("portfolio_alerts_enabled",true);
        if(portfolioOn&&portfolio.hasPositions()){for(String sym:portfolio.symbols()){Stock ps=find(sym);if(ps!=null&&ps.price>0){PortfolioAlertEngine.Decision d=PortfolioAlertEngine.evaluate(this,sym,ps.price,ps);if(d.notify)sendPortfolioAlert(d);}}}
        signals.recordTransitions(all);if(listHost!=null)renderList();if(homeQuickHost!=null)renderHomeQuickStocks();
        if(!autoScanStarted && !scanActive && !stocks.isEmpty()){
            autoScanStarted=true;
            ArrayList<String> auto=new ArrayList<>();ArrayList<Stock> ranked=new ArrayList<>(all);ranked.removeIf(x->x.price<=0);
            ranked.sort(Comparator.comparingDouble((Stock x)->-Math.max(0,x.volume)));
            for(Stock x:ranked){auto.add(x.symbol);if(auto.size()>=50)break;}
            if(!auto.isEmpty()){scanActive=true;history.scan(auto,"1Y",strategy,new HistoryService.ScanListener(){
                public void onScanProgress(int done,int total,Stock st){Stock target=find(st.symbol);if(target!=null){double lp=target.price;copyAnalysis(st,target);if(lp>0)target.price=lp;}if(listHost!=null)renderList();if(homeQuickHost!=null)renderHomeQuickStocks();}
                public void onScanFinished(int done,int total){scanActive=false;renderList();renderHomeQuickStocks();updateHomeStatus();}
            });}
        }
        if(current!=null){Stock u=find(current.symbol);if(u!=null){current=u;updateDetailStatus();renderDetailHorizon();}}
        updateHomeStatus();
    }

    @Override public void onNews(List<NewsItem> items,String msg){if(detailNewsList==null)return;detailNewsList.removeAllViews();if(items.isEmpty()){detailNewsList.addView(tv(msg,11,MUTED));return;}for(NewsItem n:items){TextView h=tv(n.title,12,TEXT);h.setTypeface(null,Typeface.BOLD);detailNewsList.addView(h);detailNewsList.addView(tv(n.source+" • "+n.time,9,MUTED));spacerIn(detailNewsList,6);}}
    @Override public void onHistory(String sym,String range,List<Candle> bars,String source,String msg){
        if(current==null||!sym.equals(current.symbol))return;
        if(screen==Screen.DETAIL && "3Y".equals(range)){
            detailHistoryBars=new ArrayList<>(bars);
            if(detailHistoryBars.isEmpty()){
                detailHistoryFailed=true;
                detailHistoryError=msg==null?"Geçmiş veri alınamadı.":msg;
                horizonResults.clear();
                if(detailHorizonHost!=null){
                    detailHorizonHost.removeAllViews();
                    LinearLayout e=card();
                    e.addView(tv("GEÇMİŞ VERİ ALINAMADI",16,YELLOW));
                    e.addView(tv(msg==null||msg.isEmpty()?"Bağlantı veya veri kaynağı yanıt vermedi.":msg,11,MUTED));
                    detailHorizonHost.addView(e);
                }
                renderHorizonSummary();
                return;
            }
            detailHistoryFailed=false;
            detailHistoryError="";
            computeDetailHorizons(sym,source,msg);
            renderDetailHorizon();
            return;
        }
        if(screen==Screen.HISTORY){
            if(historyChart!=null){historyChart.setCandles(bars);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);}
            if(historyInfo!=null)historyInfo.setText(bars.isEmpty()?msg:source+" • "+bars.size()+" günlük veri • "+msg);
        }
    }

    void computeDetailHorizons(String sym,String source,String msg){
        if(current==null||detailHistoryBars.isEmpty())return;
        final Stock liveStock=current.copy();
        final List<Candle> sourceBars=new ArrayList<>(detailHistoryBars);
        final List<Candle> benchmark=new ArrayList<>(detailBenchmarkBars);
        final String symbol=sym;
        analysisExecutor.execute(()->{
            List<Candle> longBars=new ArrayList<>(sourceBars);
            List<Candle> midBars=sliceDaysAtLeast(sourceBars,370,120);
            List<Candle> shortBars=sliceDaysAtLeast(sourceBars,190,60);
            HorizonAnalysis.Result lr=HorizonAnalysis.analyze(liveStock,longBars,benchmark,HorizonAnalysis.LONG);
            HorizonAnalysis.Result mr=HorizonAnalysis.analyze(liveStock,midBars,benchmark,HorizonAnalysis.MEDIUM);
            HorizonAnalysis.Result sr=HorizonAnalysis.analyze(liveStock,shortBars,benchmark,HorizonAnalysis.SHORT);
            runOnUiThread(()->{
                if(current==null||!symbol.equalsIgnoreCase(current.symbol)||screen!=Screen.DETAIL)return;
                horizonResults.put(HorizonAnalysis.LONG,lr);
                horizonResults.put(HorizonAnalysis.MEDIUM,mr);
                horizonResults.put(HorizonAnalysis.SHORT,sr);
                current.longTermAnalysis=lr;current.mediumTermAnalysis=mr;current.shortTermAnalysis=sr;
                renderDetailHorizon();
                renderHorizonSummary();
            });
        });
    }

    List<Candle> sliceDays(List<Candle> bars,long days){
        if(bars==null||bars.isEmpty())return Collections.emptyList();long cutoff=bars.get(bars.size()-1).time-days*86400000L;ArrayList<Candle> out=new ArrayList<>();for(Candle c:bars)if(c.time>=cutoff)out.add(c);return out;
    }

    List<Candle> sliceDaysAtLeast(List<Candle> bars,long days,int minBars){
        List<Candle> out=sliceDays(bars,days);
        if(out.size()>=minBars||bars.size()<minBars)return out;
        return new ArrayList<>(bars.subList(Math.max(0,bars.size()-minBars),bars.size()));
    }

    void copyAnalysis(Stock a,Stock b){b.rsi=a.rsi;b.macd=a.macd;b.macdSignal=a.macdSignal;b.ema20=a.ema20;b.ema50=a.ema50;b.ema200=a.ema200;b.atrPct=a.atrPct;b.momentumPct=a.momentumPct;b.avgVolume=a.avgVolume;b.volumeRatio=a.volumeRatio;b.bollingerUpper=a.bollingerUpper;b.bollingerLower=a.bollingerLower;b.support1=a.support1;b.support2=a.support2;b.resistance1=a.resistance1;b.resistance2=a.resistance2;b.stopPrice=a.stopPrice;b.targetPrice=a.targetPrice;b.targetPrice2=a.targetPrice2;b.entryLow=a.entryLow;b.entryHigh=a.entryHigh;b.trailingStop=a.trailingStop;b.adx=a.adx;b.diPlus=a.diPlus;b.diMinus=a.diMinus;b.obvSlopePct=a.obvSlopePct;b.dailyGapPct=a.dailyGapPct;b.relativeStrengthPct=a.relativeStrengthPct;b.stopPct=a.stopPct;b.rr1=a.rr1;b.rr2=a.rr2;b.riskPerShare=a.riskPerShare;b.suggestedQty=a.suggestedQty;b.suggestedPositionPct=a.suggestedPositionPct;b.setupType=a.setupType;b.stage=a.stage;b.marketRegime=a.marketRegime;b.management=a.management;b.safety=a.safety;b.dataQualityOk=a.dataQualityOk;b.marketOk=a.marketOk;b.relativeStrengthOk=a.relativeStrengthOk;b.volumeSetupOk=a.volumeSetupOk;b.volatilityOk=a.volatilityOk;b.overextended=a.overextended;b.breakoutConfirmed=a.breakoutConfirmed;b.pullbackConfirmed=a.pullbackConfirmed;b.contractionConfirmed=a.contractionConfirmed;b.candleConfirmed=a.candleConfirmed;b.adxConfirmed=a.adxConfirmed;b.obvConfirmed=a.obvConfirmed;b.entryZoneOk=a.entryZoneOk;b.volatilityShock=a.volatilityShock;b.distributionFlag=a.distributionFlag;b.hardGateOk=a.hardGateOk;b.score=a.score;b.confidence=a.confidence;b.signal=a.signal;b.aiSignal=a.aiSignal;b.technicalRatingLabel=a.technicalRatingLabel;b.technicalRating=a.technicalRating;b.technicalMaRating=a.technicalMaRating;b.technicalOscillatorRating=a.technicalOscillatorRating;b.technicalBuyCount=a.technicalBuyCount;b.technicalSellCount=a.technicalSellCount;b.technicalNeutralCount=a.technicalNeutralCount;b.risk=a.risk;b.conditionsMet=a.conditionsMet;b.conditionsTotal=a.conditionsTotal;b.bullConditions=a.bullConditions;b.bearConditions=a.bearConditions;b.weightedBull=a.weightedBull;b.weightedBear=a.weightedBear;b.signalBalance=a.signalBalance;b.entryQuality=a.entryQuality;b.decisionTier=a.decisionTier;b.decisionWhy=a.decisionWhy;b.positiveReasons=a.positiveReasons;b.negativeReasons=a.negativeReasons;b.gateReasons=a.gateReasons;b.nearbyResistanceConflict=a.nearbyResistanceConflict;b.stageOneExtensionRisk=a.stageOneExtensionRisk;b.rsiOk=a.rsiOk;b.macdOk=a.macdOk;b.emaOk=a.emaOk;b.volumeOk=a.volumeOk;b.trendOk=a.trendOk;b.supportOk=a.supportOk;b.momentumOk=a.momentumOk;b.trend=a.trend;b.reason=a.reason;b.quoteTime=a.quoteTime;b.quoteSource=a.quoteSource;b.analysisReady=a.analysisReady;b.longTermAnalysis=a.longTermAnalysis;b.mediumTermAnalysis=a.mediumTermAnalysis;b.shortTermAnalysis=a.shortTermAnalysis;}

    void sendPortfolioAlert(PortfolioAlertEngine.Decision d){
        if(d==null||!d.notify||Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("portfolio","Portföy Alarmları",NotificationManager.IMPORTANCE_HIGH));}
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"portfolio"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("BIST AI Trader • "+d.title).setContentText(d.message.replace("\\n"," • ")).setStyle(new Notification.BigTextStyle().bigText(d.message.replace("\\n","\n"))).setAutoCancel(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(Math.abs((d.symbol+"_"+d.key).hashCode()),b.build());
    }
    void startPortfolioMonitorIfConfigured(){
        android.content.SharedPreferences sp=getSharedPreferences("settings",0);if(!sp.getBoolean("portfolio_alerts_enabled",true)||!portfolio.hasPositions())return;
        try{Intent i=new Intent(this,PortfolioMonitorService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception ignored){}
    }
    void stopPortfolioMonitorService(){try{stopService(new Intent(this,PortfolioMonitorService.class));}catch(Exception ignored){}}

    void sendPriceAlert(Stock s){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("price","Fiyat Alarmları",NotificationManager.IMPORTANCE_DEFAULT));}Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"price"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("BIST AI Trader • "+s.symbol).setContentText("Fiyat alarmı: "+formatPrice(s.price)).setAutoCancel(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(Math.abs(s.symbol.hashCode()),b.build());}
    private void startRefresh(){strategy=getSharedPreferences("settings",0).getString("strategy","Dengeli");refreshTask=()->{data.refresh();timer.postDelayed(refreshTask,Math.max(15,getSharedPreferences("settings",0).getInt("refresh_sec",30))*1000L);};timer.post(refreshTask);}
    private void restartRefresh(){if(refreshTask!=null)timer.removeCallbacks(refreshTask);startRefresh();}
    long lastUpdate(){return getSharedPreferences("runtime",0).getLong("last_update",0L);}
    String lastDataLabel(){long t=getSharedPreferences("runtime",0).getLong("last_quote_time",0L);if(t<=0)t=lastUpdate();return t<=0?"—":time(t);}
    void openDetailFromCurrentScreen(Stock s){if(s==null)return;detailReturnScreen=screen;current=s;showDetail(s);}
    void returnFromDetail(){if(detailReturnScreen==Screen.HOME){showDashboard();return;}if(detailReturnScreen==Screen.WATCH){showWatchlist();return;}if(detailReturnScreen==Screen.PORTFOLIO){showPortfolio();return;}if(detailReturnScreen==Screen.SETTINGS){showSettings();return;}if(detailReturnScreen==Screen.DATA){showData();return;}showMarket();}
    String dataSourceLabel(){android.content.SharedPreferences sp=getSharedPreferences("settings",0);if(sp.getBoolean("itick_enabled",false)&&!sp.getString("itick_token","").trim().isEmpty())return "iTick • BIST gerçek zamanlı";String base=sp.getString("base_url","").trim();return base.isEmpty()?"İş Yatırım • gecikmeli":"Özel veri sağlayıcı";}
    String refreshIntervalLabel(){int sec=Math.max(1,getSharedPreferences("settings",0).getInt("refresh_sec",30));return sec+" sn";}
    String homeMarketRegime(){for(Stock s:all)if(s.analysisReady&&!s.marketRegime.equals("Piyasa doğrulaması yok")&&!s.marketRegime.equals("Belirsiz"))return s.marketRegime;return "XU100 bekleniyor";}

    void updateHomeStatus(){if(homeDataInfo!=null){homeDataInfo.setText("Veri kaynağı: "+dataSourceLabel());}if(homeLastDataInfo!=null){homeLastDataInfo.setText("Son veri: "+lastDataLabel());}if(homeCatalogInfo!=null){homeCatalogInfo.setText("Hisse kataloğu: "+StockUniverse.size()+" sembol • otomatik keşif");}if(homeIndexInfo!=null){homeIndexInfo.setText("Endeks üyelikleri: "+MarketGroups.status(this));}if(homeMarketInfo!=null){homeMarketInfo.setText("Piyasa filtresi: "+homeMarketRegime());}if(homeLearningInfo!=null){PredictionStore.Report pr=new PredictionStore(this).report();homeLearningInfo.setText("AI öğrenme: "+learning.sampleCount()+" sonuç • "+(learning.active()?"AKTİF":"PASİF")+" • "+pr.open+" açık tahmin");}}
    void updateDetailStatus(){if(current==null)return;Stock s=find(current.symbol);if(s==null)return;if(detailPriceView!=null)detailPriceView.setText(s.price>0?formatPrice(s.price):"—");if(detailQuoteMeta!=null)detailQuoteMeta.setText(s.price>0?String.format(Locale.US,"%+.2f%% bugün • %s",s.changePct,s.risk):"Geçmiş OHLCV verisi yükleniyor…");}

    void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
    String time(long t){return new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t));}
    @Override protected void onDestroy(){if(refreshTask!=null)timer.removeCallbacks(refreshTask);if(history!=null)history.shutdown();if(data!=null)data.shutdown();analysisExecutor.shutdownNow();super.onDestroy();}
    String formatPrice(double v){return v<=0?"—":String.format(Locale.US,"%.2f ₺",v);}
    String formatPlain(double v){return v<=0?"":String.format(Locale.US,"%.2f",v);}
    int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    double parseDouble(String s,double d){try{return Double.parseDouble(s.trim().replace(",","."));}catch(Exception e){return d;}}
    boolean isFavorite(String sym){return getSharedPreferences("favorites",0).getBoolean(sym,false);}
    void toggleFavorite(String sym){getSharedPreferences("favorites",0).edit().putBoolean(sym,!isFavorite(sym)).apply();}
    Stock find(String sym){for(Stock s:all)if(s.symbol.equalsIgnoreCase(sym))return s;return null;}
}
