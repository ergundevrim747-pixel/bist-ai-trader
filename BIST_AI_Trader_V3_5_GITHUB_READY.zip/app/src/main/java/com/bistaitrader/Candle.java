package com.bistaitrader;

public class Candle {
    public long time;
    public String date = "";
    public double open, high, low, close, volume;
    /** True only when open/high/low are source data, not reconstructed from close. */
    public boolean fullOhlc = true;

    public Candle(long time, String date, double open, double high, double low, double close, double volume) {
        this.time = time;
        this.date = date == null ? "" : date;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
    }

    public Candle(long time, String date, double open, double high, double low, double close, double volume, boolean fullOhlc) {
        this(time, date, open, high, low, close, volume);
        this.fullOhlc = fullOhlc;
    }
}
