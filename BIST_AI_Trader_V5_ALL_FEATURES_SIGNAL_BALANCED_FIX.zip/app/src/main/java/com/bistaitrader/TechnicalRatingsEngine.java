package com.bistaitrader;

import java.util.*;

/**
 * TradingView-style technical rating engine based on the publicly documented
 * indicator-bucket idea: each indicator votes +1 / 0 / -1 and the final
 * technical score is the normalized average. This is an independent
 * implementation; it does not copy proprietary code or data.
 */
public final class TechnicalRatingsEngine {
    private TechnicalRatingsEngine() {}

    public static final class Result {
        public boolean ready;
        public double maScore;
        public double oscillatorScore;
        public double totalScore;
        public String action = "BEKLE";
        public String label = "VERİ YETERSİZ";
        public int buyCount, sellCount, neutralCount;
        public int maBuy, maSell, maNeutral;
        public int oscBuy, oscSell, oscNeutral;
    }

    public static Result evaluate(List<Candle> input) {
        Result r = new Result();
        List<Candle> bars = clean(input);
        // Short-vade ekranında 60+ günlük veri ile mevcut kısa/orta periyotlar hesaplanır.
        // 100/200 günlük ortalamalar veri yetmezse zorla üretilmez; bu dönemler tarafsız bırakılır.
        if (bars.size() < 60) return r;
        int n = bars.size() - 1;
        double[] c = new double[bars.size()];
        double[] h = new double[bars.size()];
        double[] l = new double[bars.size()];
        double[] v = new double[bars.size()];
        for (int i=0;i<bars.size();i++) { Candle x=bars.get(i); c[i]=x.close; h[i]=x.high; l[i]=x.low; v[i]=x.volume; }

        List<Integer> maVotes=new ArrayList<>();
        int[] periods={10,20,30,50,100,200};
        for(int period:periods){
            if(bars.size()<period) continue;
            maVotes.add(c[n]>sma(c,period,n)?1:c[n]<sma(c,period,n)?-1:0);
            maVotes.add(c[n]>ema(c,period,n)?1:c[n]<ema(c,period,n)?-1:0);
        }
        double hma=hma(c,9,n); maVotes.add(c[n]>hma?1:c[n]<hma?-1:0);
        double vwma=vwma(c,v,20,n); maVotes.add(c[n]>vwma?1:c[n]<vwma?-1:0);
        double[] ichi=ichimoku(c,h, l,n); // conversion/base/spanA/spanB
        double cloudTop=Math.max(ichi[2],ichi[3]);
        double cloudBot=Math.min(ichi[2],ichi[3]);
        maVotes.add(c[n]>cloudTop?1:c[n]<cloudBot?-1:0);

        double maSum=sum(maVotes);
        r.maBuy=count(maVotes,1); r.maSell=count(maVotes,-1); r.maNeutral=count(maVotes,0);
        r.maScore=maSum/(double)Math.max(1,maVotes.size());

        List<Integer> o=new ArrayList<>();
        double rs=rsi(c,14,n); o.add(rs<30?1:rs>70?-1:0);
        double st=stochastic(c,h,l,14,3,n); o.add(st<20?1:st>80?-1:0);
        double cci=cci(c,h,l,20,n); o.add(cci<-100?1:cci>100?-1:0);
        double[] adx=adx(c,h,l,14,n); o.add(adx[1]>adx[2]&&adx[0]>=20?1:adx[1]<adx[2]&&adx[0]>=20?-1:0);
        double ao=ao(c,h,l,n); o.add(ao>0&&ao>aoPrev(c,h,l,n)?1:ao<0&&ao<aoPrev(c,h,l,n)?-1:0);
        double mom=c[n]-c[Math.max(0,n-10)]; o.add(mom>0&&c[n]>c[Math.max(0,n-5)]?1:mom<0&&c[n]<c[Math.max(0,n-5)]?-1:0);
        double[] macd=macd(c,12,26,9,n); o.add(macd[0]>macd[1]&&macd[2]>=0?1:macd[0]<macd[1]&&macd[2]<=0?-1:0);
        double srsi=stochRsi(c,14,14,n); o.add(srsi<0.2?1:srsi>0.8?-1:0);
        double wr=williams(c,h,l,14,n); o.add(wr<-80?1:wr>-20?-1:0);
        double bb=bullBearPower(c,ema(c,13,n)); o.add(bb>0?1:bb<0?-1:0);
        double uo=ultimate(c,h,l,n); o.add(uo<30?1:uo>70?-1:0);

        double osum=sum(o);
        r.oscBuy=count(o,1); r.oscSell=count(o,-1); r.oscNeutral=count(o,0);
        r.oscillatorScore=osum/(double)Math.max(1,o.size());
        r.totalScore=(r.maScore+r.oscillatorScore)/2.0;
        r.buyCount=r.maBuy+r.oscBuy; r.sellCount=r.maSell+r.oscSell; r.neutralCount=r.maNeutral+r.oscNeutral;
        r.action=action(r.totalScore);
        r.label=label(r.totalScore);
        r.ready=true;
        return r;
    }

    private static String action(double s){ if(s>0.50)return "AL"; if(s>0.10)return "AL"; if(s>=-0.10)return "BEKLE"; return "SAT"; }
    private static String label(double s){ if(s>0.50)return "GÜÇLÜ AL"; if(s>0.10)return "AL"; if(s>=-0.10)return "NÖTR"; if(s>=-0.50)return "SAT"; return "GÜÇLÜ SAT"; }
    private static int boolVote(double x){return x>0?1:x<0?-1:0;}
    private static int sum(List<Integer> x){int s=0;for(int a:x)s+=a;return s;}
    private static int count(List<Integer> x,int v){int n=0;for(int a:x)if(a==v)n++;return n;}

    private static double sma(double[] a,int n,int idx){int from=Math.max(0,idx-n+1);double s=0;int k=0;for(int i=from;i<=idx;i++){s+=a[i];k++;}return k==0?0:s/k;}
    private static double ema(double[] a,int n,int idx){double e=a[0],k=2.0/(n+1.0);for(int i=1;i<=idx;i++)e=a[i]*k+e*(1-k);return e;}
    private static double wma(double[] a,int n,int idx){int from=Math.max(0,idx-n+1),len=idx-from+1;double s=0,w=0;for(int i=0;i<len;i++){double wt=i+1;s+=a[from+i]*wt;w+=wt;}return w==0?0:s/w;}
    private static double hma(double[] a,int n,int idx){int half=Math.max(2,n/2),sqrt=Math.max(2,(int)Math.round(Math.sqrt(n)));double[] tmp=new double[idx+1];for(int i=0;i<=idx;i++)tmp[i]=2*wma(a,half,i)-wma(a,n,i);return wma(tmp,sqrt,idx);}
    private static double vwma(double[] c,double[] v,int n,int idx){int from=Math.max(0,idx-n+1);double pv=0,p=0;for(int i=from;i<=idx;i++){pv+=v[i];p+=c[i]*v[i];}return pv>0?p/pv:sma(c,n,idx);}
    private static double[] ichimoku(double[] c,double[] h,double[] l,int idx){
        double conv=(highest(h,9,idx)+lowest(l,9,idx))/2.0;
        double base=(highest(h,26,idx)+lowest(l,26,idx))/2.0;
        int shift=Math.min(26,idx);
        double spanA=(highest(h,9,idx-shift)+lowest(l,9,idx-shift)+highest(h,26,idx-shift)+lowest(l,26,idx-shift))/4.0;
        double spanB=(highest(h,52,idx-shift)+lowest(l,52,idx-shift))/2.0;
        return new double[]{conv,base,spanA,spanB};
    }
    private static double highest(double[] a,int n,int idx){int from=Math.max(0,idx-n+1);double x=Double.NEGATIVE_INFINITY;for(int i=from;i<=idx;i++)x=Math.max(x,a[i]);return x;}
    private static double lowest(double[] a,int n,int idx){int from=Math.max(0,idx-n+1);double x=Double.POSITIVE_INFINITY;for(int i=from;i<=idx;i++)x=Math.min(x,a[i]);return x;}
    private static double rsi(double[] c,int p,int idx){int from=Math.max(1,idx-p+1);double g=0,loss=0;for(int i=from;i<=idx;i++){double d=c[i]-c[i-1];if(d>0)g+=d;else loss-=d;}if(loss==0)return 100;double rs=(g/p)/(loss/p);return 100-100/(1+rs);}
    private static double stochastic(double[] c,double[] h,double[] l,int p,int smooth,int idx){int from=Math.max(0,idx-p+1);double lo=lowest(l,p,idx),hi=highest(h,p,idx);if(hi<=lo)return 50;double k=(c[idx]-lo)/(hi-lo)*100;double sum=0;int count=0;for(int j=Math.max(from,idx-smooth+1);j<=idx;j++){double ll=lowest(l,p,j),hh=highest(h,p,j);sum+=hh<=ll?50:(c[j]-ll)/(hh-ll)*100;count++;}return count==0?k:sum/count;}
    private static double cci(double[] c,double[] h,double[] l,int p,int idx){double[] tp=new double[idx+1];for(int i=0;i<=idx;i++)tp[i]=(h[i]+l[i]+c[i])/3.0;double mean=sma(tp,p,idx),dev=0;int from=Math.max(0,idx-p+1),k=0;for(int i=from;i<=idx;i++){dev+=Math.abs(tp[i]-mean);k++;}dev/=Math.max(1,k);return dev==0?0:(tp[idx]-mean)/(0.015*dev);}
    private static double[] adx(double[] c,double[] h,double[] l,int p,int idx){int from=Math.max(1,idx-p+1);double tr=0,plus=0,minus=0;for(int i=from;i<=idx;i++){double up=h[i]-h[i-1],dn=l[i-1]-l[i];if(up>dn&&up>0)plus+=up;if(dn>up&&dn>0)minus+=dn;tr+=Math.max(h[i]-l[i],Math.max(Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));}double dip=tr==0?0:plus/tr*100,dim=tr==0?0:minus/tr*100,dx=(dip+dim)==0?0:Math.abs(dip-dim)/(dip+dim)*100;return new double[]{dx,dip,dim};}
    private static double ao(double[] c,double[] h,double[] l,int idx){double[] m=new double[idx+1];for(int i=0;i<=idx;i++)m[i]=(h[i]+l[i])/2.0;return sma(m,5,idx)-sma(m,34,idx);}
    private static double aoPrev(double[] c,double[] h,double[] l,int idx){return idx<=0?0:ao(c,h,l,idx-1);}
    private static double[] macd(double[] c,int fast,int slow,int sig,int idx){double[] m=new double[idx+1];for(int i=0;i<=idx;i++)m[i]=ema(c,fast,i)-ema(c,slow,i);double signal=ema(m,sig,idx);return new double[]{m[idx],signal,m[idx]-signal};}
    private static double stochRsi(double[] c,int p,int rsiP,int idx){int from=Math.max(rsiP,idx-p+1);double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;for(int i=from;i<=idx;i++){double x=rsi(c,rsiP,i);min=Math.min(min,x);max=Math.max(max,x);}double x=rsi(c,rsiP,idx);return max-min==0?0.5:(x-min)/(max-min);}
    private static double williams(double[] c,double[] h,double[] l,int p,int idx){double hi=highest(h,p,idx),lo=lowest(l,p,idx);return hi==lo?-50:(hi-c[idx])/(hi-lo)*-100;}
    private static double bullBearPower(double[] c,double ema){return c[c.length-1]-ema;}
    private static double ultimate(double[] c,double[] h,double[] l,int idx){
        double bp4=bp(c,h,l,4,idx),tr4=tr(h,l,c,4,idx),bp7=bp(c,h,l,7,idx),tr7=tr(h,l,c,7,idx),bp14=bp(c,h,l,14,idx),tr14=tr(h,l,c,14,idx);
        double a=tr4==0?0:bp4/tr4,b=tr7==0?0:bp7/tr7,d=tr14==0?0:bp14/tr14;return (4*a+2*b+d)/7.0*100;
    }
    private static double bp(double[] c,double[] h,double[] l,int p,int idx){int from=Math.max(0,idx-p+1);double s=0;for(int i=from;i<=idx;i++){double prev=i==0?c[0]:Math.min(c[i-1],l[i]);s+=c[i]-prev;}return s;}
    private static double tr(double[] h,double[] l,double[] c,int p,int idx){int from=Math.max(1,idx-p+1);double s=0;for(int i=from;i<=idx;i++)s+=Math.max(h[i]-l[i],Math.max(Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));return s;}
    private static List<Candle> clean(List<Candle> src){ArrayList<Candle> o=new ArrayList<>();if(src==null)return o;long prev=Long.MIN_VALUE;for(Candle c:src){if(c==null||c.close<=0||c.high<=0||c.low<=0||c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close)||c.time<=prev)continue;o.add(c);prev=c.time;}return o;}
}
