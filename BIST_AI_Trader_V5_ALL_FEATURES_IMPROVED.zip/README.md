# BIST AI Trader V5 - Improved Signals

Bu sürüm V5 sinyal motorunu yeniden dengeler.

- 5/7 teknik teyit AL ADAYI eşiğidir.
- Final AL artık özel breakout/pullback kurulumuna zorunlu olarak bağlı değildir.
- Stop, risk/getiri, piyasa, volatilite, göreli güç ve giriş bölgesi güvenlikleri korunur.
- T1 minimum R/R 1.40, T2 minimum R/R 2.00 olarak kullanılır.
- Hisse detayında AL / BEKLE / SAT kararının açık nedeni gösterilir.
- Olumlu koşullar, zayıf koşullar ve kararı engelleyen filtreler ayrı listelenir.
- Ana ekranda AL ADAYI ayrı filtre olarak gösterilir.
- Teknik rating AI kararını ezmez.
