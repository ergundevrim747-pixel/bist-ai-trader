# BIST AI Trader v3 — Android

V3, tekrar tekrar APK kurma ihtiyacını azaltmak için tek sürümde kapsamlı bir kullanım akışı hedefler.

## V3 yenilikleri
- Geri tuşu uygulamadan çıkarmak yerine ekran geçmişine döner.
- Yenilenmiş koyu arayüz, daha büyük başlıklar, durum rozeti ve alt menü.
- Hisseler tek tek aramak zorunda kalmadan tek uzun listede aşağı doğru gezilebilir.
- Kategori filtreleri: Tümü, BIST 30, BIST 50, BIST 100, BIST 500/Geniş Katalog, Takip.
- Sinyal, günlük değişim, hacim, skor ve fiyat sıralaması.
- Favori/Takip listesi.
- Gerçek fiyat kaynağı erişilemezse uygulama sahte fiyat göstermemeyi tercih eder; fiyat `—` görünür ve veri durumu ayrıca belirtilir.
- Hisse detayında gerçek tarihsel veriden oluşturulan çizgi grafik.
- Ayrı Grafik & Geçmiş ekranı: 1A / 3A / 6A / 1Y / 3Y / 5Y ve Mum / Çizgi modları.
- Grafikte dokunarak tarih ve kapanış seçimi; günlük OHLCV geçmişi.
- Tarihsel veri üzerinden RSI14, MACD, EMA20/50/200, ATR%, 20 günlük momentum, Bollinger Bandı, hacim oranı, destek/direnç, trend, göreli risk ve teknik skor.
- Sinyal gerekçesi ve sinyal geçmişi.
- Sanal portföy, alış/satış simülasyonu ve portföy özeti.
- AL/SAT değişim bildirimleri.
- Haber/KAP için harici JSON sağlayıcı alanı.
- Harici quote API bağlama desteği.

## Veri kaynakları ve önemli sınırlamalar

### Güncel fiyat
Varsayılan güncel fiyat kaynağı, İş Yatırım'ın halka açık hisse ekranıdır. Bu ekranın güncellik/frekans koşulları lisanslı gerçek zamanlı piyasa veri akışı ile aynı kabul edilmemelidir. Uygulama durum çubuğunda yalnızca `VERİ BAĞLI` gösterir; lisanslı eşanlı veri iddiasında bulunmaz.

### Tarihsel grafik
Tarihsel OHLCV için varsayılan kaynak, halka açık Yahoo Finance chart uç noktasıdır. Çalışmazsa halka açık İş Yatırım tarihsel kapanış/hacim uç noktasına geri düşer. Fallback verisinde açılış/yüksek/düşük değerleri önceki kapanış ve mevcut kapanıştan türetilir; mum görünümü bu durumda kapanış tabanlı bir görselleştirme olarak düşünülmelidir.

Bu uç noktalar resmi bir BIST/İş Yatırım geliştirici SDK'sı değildir. Kişisel kullanımda istekleri önbellekleyerek ve gereksiz tekrarları azaltarak kullanmak gerekir. Sağlayıcıların kullanım şartlarını ve yeniden dağıtım/lisans hükümlerini ayrıca kontrol edin.

## Endeks kategorileri

BIST 30 / BIST 50 / BIST 100 kümeleri uygulamada hızlı erişim için gömülü snapshot olarak tutulur. Borsa İstanbul endeks üyeliklerini dönemsel gözden geçirebildiği için bu listeler ileride güncellenebilir. BIST 500 / Geniş Katalog, uygulamanın geniş sembol kataloğunu kullanır.

## Teknik analiz

V3'te sinyal üretimi tek bir indikatöre göre yapılmaz. Trend, RSI, MACD, EMA'lar, momentum, hacim ve volatilite birlikte puanlanır ve sonucunda `AL / SAT / BEKLE` üretilir. Bu bir makine öğrenmesi modeli değildir; deterministik bir teknik analiz/sinyal motorudur.

## Harici quote API formatı

Ayarlar ekranına standart JSON endpoint'i girilebilir. Örnek:

```json
{
  "symbols": [
    {
      "symbol": "THYAO",
      "name": "Türk Hava Yolları",
      "sector": "Ulaştırma",
      "price": 123.45,
      "previousClose": 122.80,
      "changePct": 0.53,
      "volume": 12345678,
      "avgVolume": 9876543,
      "signal": "AL"
    }
  ]
}
```

## GitHub Actions

Mevcut GitHub Actions workflow'unuz ZIP dosyasını `project/` altına çıkarıp `:app:assembleDebug` çalıştırabilir. V3 proje sürümü `versionCode 3 / versionName 3.0` kullanır.

## Risk notu

Borsada garantili/risk­siz hisse yoktur. Uygulamadaki düşük/orta/yüksek risk etiketleri göreli volatilite ve likidite ölçümleridir; yatırım tavsiyesi veya getiri garantisi değildir.
