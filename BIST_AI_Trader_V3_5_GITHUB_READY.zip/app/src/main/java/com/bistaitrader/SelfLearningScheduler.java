package com.bistaitrader;

import android.content.Context;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public final class SelfLearningScheduler {
    private static final String UNIQUE="bist_ai_continuous_learning";
    private SelfLearningScheduler(){}
    public static void schedule(Context context){
        Context c=context.getApplicationContext();
        if(!c.getSharedPreferences("settings",0).getBoolean("self_learning",true)){cancel(c);return;}
        Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(ContinuousLearningWorker.class,15,TimeUnit.MINUTES)
                .setConstraints(constraints).build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(UNIQUE,ExistingPeriodicWorkPolicy.KEEP,req);
    }
    public static void runNow(Context context){
        Context c=context.getApplicationContext();
        if(!c.getSharedPreferences("settings",0).getBoolean("self_learning",true))return;
        Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest req=new OneTimeWorkRequest.Builder(ContinuousLearningWorker.class).setConstraints(constraints).build();
        WorkManager.getInstance(c).enqueueUniqueWork("bist_ai_learning_now",ExistingWorkPolicy.REPLACE,req);
    }
    public static void cancel(Context context){WorkManager.getInstance(context.getApplicationContext()).cancelUniqueWork(UNIQUE);}
}
