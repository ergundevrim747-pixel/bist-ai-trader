package com.bistaitrader;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class PortfolioStore {
    private final android.content.SharedPreferences sp;
    public PortfolioStore(Context c){sp=c.getApplicationContext().getSharedPreferences("portfolio",Context.MODE_PRIVATE);}
    public double cash(){return Double.longBitsToDouble(sp.getLong("cash",Double.doubleToLongBits(100000.0)));}
    public void setCash(double v){sp.edit().putLong("cash",Double.doubleToLongBits(Math.max(0,v))).apply();}
    public int qty(String sym){return sp.getInt("q_"+sym,0);}
    public void setQty(String sym,int q){sp.edit().putInt("q_"+sym,Math.max(0,q)).apply();}
    public double avgCost(String sym){return Double.longBitsToDouble(sp.getLong("avg_"+sym,Double.doubleToLongBits(0)));}
    private void setAvgCost(String sym,double v){sp.edit().putLong("avg_"+sym,Double.doubleToLongBits(Math.max(0,v))).apply();}
    public Set<String> symbols(){String raw=sp.getString("symbols","");Set<String> out=new LinkedHashSet<>();if(!raw.isEmpty())out.addAll(Arrays.asList(raw.split(",")));return out;}
    private void addSymbol(String sym){Set<String>s=symbols();s.add(sym);sp.edit().putString("symbols",String.join(",",s)).apply();}
    private double commissionRate(){return 0.002;}
    public boolean buy(String sym,double price,int q){
        if(sym==null||q<=0||price<=0)return false;
        double gross=price*q, fee=gross*commissionRate(), total=gross+fee;
        if(total>cash())return false;
        int oldQ=qty(sym);double oldAvg=avgCost(sym);int newQ=oldQ+q;
        double newAvg=(oldQ*oldAvg+total)/newQ;
        setCash(cash()-total);setQty(sym,newQ);setAvgCost(sym,newAvg);addSymbol(sym);logTrade(sym,"AL",price,q,fee);return true;
    }
    public boolean sell(String sym,double price,int q){
        if(sym==null||q<=0||price<=0||qty(sym)<q)return false;
        double gross=price*q,fee=gross*commissionRate(),net=gross-fee;
        int left=qty(sym)-q;
        setCash(cash()+net);setQty(sym,left);if(left==0)setAvgCost(sym,0);logTrade(sym,"SAT",price,q,fee);return true;
    }
    private void logTrade(String sym,String side,double price,int qty,double fee){
        String raw=sp.getString("trades","[]");JSONArray a;try{a=new JSONArray(raw);}catch(Exception e){a=new JSONArray();}
        try{JSONObject o=new JSONObject();o.put("symbol",sym);o.put("side",side);o.put("price",price);o.put("qty",qty);o.put("fee",fee);o.put("time",System.currentTimeMillis());a.put(o);}catch(Exception ignored){}
        while(a.length()>300)a.remove(0);sp.edit().putString("trades",a.toString()).apply();
    }
    public JSONArray tradeHistory(){try{return new JSONArray(sp.getString("trades","[]"));}catch(Exception e){return new JSONArray();}}
    public void reset(){sp.edit().clear().apply();setCash(100000);}
}
