package com.bistaitrader;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.*;

public class MiniChartView extends View {
    private Stock stock;
    private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path line = new Path();
    private Path area = new Path();
    private float[] points = new float[42];

    public MiniChartView(Context c){super(c); p.setStrokeWidth(4f); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setStock(Stock s){ stock=s; invalidate(); }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawColor(Color.TRANSPARENT);
        if(stock==null||stock.price<=0)return;
        float w=getWidth(),h=getHeight();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.0f); p.setColor(Color.rgb(39,59,84));
        for(int i=1;i<4;i++) c.drawLine(0,h*i/4f,w,h*i/4f,p);
        for(int i=1;i<5;i++) c.drawLine(w*i/5f,0,w*i/5f,h,p);
        boolean up = stock.signal.equals("AL") || stock.changePct>=0;
        p.setColor(up?Color.rgb(48,209,88):Color.rgb(255,69,58));
        p.setStrokeWidth(5f); p.setStyle(Paint.Style.STROKE);
        line.reset(); area.reset();
        double drift=(stock.changePct/100.0)*0.65;
        for(int i=0;i<points.length;i++){
            double t=i/(double)(points.length-1);
            double v=0.5 + drift*(t-0.25) + 0.12*Math.sin(i*0.72 + stock.symbol.hashCode()%13) + 0.04*Math.sin(i*1.7);
            float y=(float)((1-Math.max(0.08,Math.min(0.92,v)))*h);
            float x=(float)(t*w);
            if(i==0){line.moveTo(x,y); area.moveTo(x,h); area.lineTo(x,y);} else {line.lineTo(x,y); area.lineTo(x,y);}
            points[i]=(float)v;
        }
        area.lineTo(w,h); area.close();
        p.setStyle(Paint.Style.FILL); p.setColor(up?0x2530D158:0x25FF453A); c.drawPath(area,p);
        p.setStyle(Paint.Style.STROKE); p.setColor(up?Color.rgb(48,209,88):Color.rgb(255,69,58)); c.drawPath(line,p);
        p.setStyle(Paint.Style.FILL); c.drawCircle(w-6, (float)((1-points[points.length-1])*h), 6, p);
    }
}
