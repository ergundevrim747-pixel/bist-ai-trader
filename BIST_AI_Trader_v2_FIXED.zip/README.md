# BIST AI Trader v2 — Android

Bu sürüm, önceki MVP'nin yerine geçecek şekilde daha gelişmiş bir BIST analiz arayüzü, risk katmanı ve sanal portföy içerir.

## Bu sürümde
- Modern koyu arayüz
- Ana sayfa / Piyasa / Takip / Portföy / Ayarlar
- Büyük hisse kataloğu ve sembol arama
- Düşük / Orta / Yüksek Risk filtreleri
- AL / SAT / BEKLE sinyal motoru
- Teknik göstergeler: RSI, MACD, EMA20, EMA50, ATR-benzeri volatilite, hacim
- Destek / direnç seviyeleri
- Mini grafik görünümü
- Hisse detay ekranı
- Sanal portföy ve alış/satış
- Yerel favori/takip listesi
- Haber/KAP API alanı
- Gerçek veri modu için veri sağlayıcı URL + token ayarı
- Ağ bağlantısı, son güncelleme ve CANLI/DEMO göstergesi

## Önemli: gerçek zamanlı BIST verisi
Borsa İstanbul eşanlı verilerini yetkili/lisanslı veri dağıtıcıları üzerinden sağlar. Bu uygulama, bir veri sağlayıcının API'sine bağlanmaya hazır bir standart arayüz içerir; uygulamaya sağlayıcının URL/token bilgisi girilmeden DEMO verisi gösterilir.

### Quote API örnek cevabı
```json
{
  "symbols": [
    {
      "symbol": "THYAO",
      "name": "Türk Hava Yolları",
      "sector": "Ulaştırma",
      "price": 123.45,
      "previousClose": 122.80,
      "changePct": 0.53,
      "volume": 12345678,
      "avgVolume": 9876543,
      "rsi": 58.4,
      "macd": 0.73,
      "ema20": 121.80,
      "ema50": 117.40,
      "atrPct": 2.4,
      "score": 76,
      "newsScore": 0.3,
      "signal": "AL",
      "risk": "Orta Risk",
      "support1": 120.5,
      "support2": 117.9,
      "resistance1": 126.0,
      "resistance2": 129.8
    }
  ]
}
```

### Haber/KAP API örnek cevabı
```json
{
  "items": [
    {"symbol":"THYAO","title":"Başlık","source":"KAP","publishedAt":"2026-09-19 10:05","sentiment":0.6}
  ]
}
```

## GitHub Actions
Mevcut repodaki workflow, bu projenin ZIP'ini `project/` klasörüne çıkarıp `:app:assembleDebug` ile APK oluşturacak şekilde kullanılabilir.

## Not
`Düşük Risk / Orta Risk / Yüksek Risk` sınıfları göreli sınıflardır. Borsada garantili/risk­siz hisse yoktur. Gerçek para işlemi bu sürümde yoktur; sanal portföy kullanılır.
