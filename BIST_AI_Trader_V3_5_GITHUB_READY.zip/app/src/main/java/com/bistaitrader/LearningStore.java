package com.bistaitrader;

import android.content.Context;
import org.json.*;
import java.util.*;

/** Persistent, bounded adaptive-learning profile. It stores evidence, not arbitrary model rewrites. */
public final class LearningStore {
    public static final String[] FEATURES={"RSI","MACD","EMA","Hacim","Trend","Destek","Momentum"};
    private final android.content.SharedPreferences sp;
    public LearningStore(Context c){sp=c.getApplicationContext().getSharedPreferences("ai_learning",Context.MODE_PRIVATE);}

    public synchronized boolean hasSample(String symbol,long time){
        JSONArray a=read("samples");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&symbol.equals(o.optString("symbol"))&&time==o.optLong("time"))return true;}
        return false;
    }
    public synchronized void recordSample(String symbol,long time,String signal,Stock s,boolean win,double pnlPct){
        if(s==null||(!"AL".equals(signal)&&!"SAT".equals(signal))||hasSample(symbol,time))return;
        JSONArray a=read("samples");
        try{
            JSONObject o=new JSONObject();o.put("symbol",symbol);o.put("time",time);o.put("signal",signal);o.put("win",win);o.put("pnl",pnlPct);
            o.put("rsi",s.rsiOk);o.put("macd",s.macdOk);o.put("ema",s.emaOk);o.put("volume",s.volumeOk);o.put("trend",s.trendOk);o.put("support",s.supportOk);o.put("momentum",s.momentumOk);
            o.put("score",s.score);o.put("conditions",s.conditionsMet);o.put("setup",s.setupType);o.put("adx",s.adx);o.put("volRatio",s.volumeRatio);o.put("atrPct",s.atrPct);
            a.put(o);
        }catch(Exception ignored){}
        while(a.length()>3000)a.remove(0);
        sp.edit().putString("samples",a.toString()).apply();
    }

    public JSONArray samples(){return read("samples");}
    public JSONArray predictionSamples(){return read("prediction_samples");}
    public JSONArray learningSamples(){
        JSONArray out=new JSONArray();
        JSONArray a=samples(), b=predictionSamples();
        for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o!=null) out.put(o); }
        for(int i=0;i<b.length();i++) { JSONObject o=b.optJSONObject(i); if(o!=null) out.put(o); }
        return out;
    }
    public int sampleCount(){return learningSamples().length();}

    /** Outcome from an independently tracked paper prediction. */
    public synchronized void recordPredictionOutcome(JSONObject p){
        if(p==null)return;
        JSONArray a=predictionSamples();
        String id=p.optString("id",p.optString("symbol","")+"|"+p.optLong("time",0));
        for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&id.equals(x.optString("id")))return;}
        try{
            JSONObject o=new JSONObject();
            o.put("id",id);o.put("symbol",p.optString("symbol"));o.put("time",p.optLong("time"));o.put("signal",p.optString("signal","AL"));
            double pnl=p.optDouble("pnl",0);o.put("pnl",pnl);o.put("win",pnl>0);o.put("reason",p.optString("reason",""));o.put("status",p.optString("status",""));
            String[] ks={"rsi","macd","ema","volume","trend","support","momentum","score","conditions","setup","adx","volRatio","atrPct","rr1","rr2","market","stage","rs","breakout","pullback","overextended","volShock","distribution"};
            for(String k:ks)if(p.has(k))o.put(k,p.get(k));
            a.put(o);while(a.length()>3000)a.remove(0);
        }catch(Exception ignored){}
        sp.edit().putString("prediction_samples",a.toString()).apply();
    }
    public void setProfile(JSONObject p){sp.edit().putString("profile",p.toString()).apply();}
    public JSONObject profile(){try{return new JSONObject(sp.getString("profile","{}"));}catch(Exception e){return new JSONObject();}}
    public void setLastRun(long t){sp.edit().putLong("last_run",t).apply();}
    public long lastRun(){return sp.getLong("last_run",0);}
    public void setActive(boolean x){sp.edit().putBoolean("active",x).apply();}
    public boolean active(){return sp.getBoolean("active",true);}
    public void clear(){sp.edit().clear().apply();}
    private JSONArray read(String k){try{return new JSONArray(sp.getString(k,"[]"));}catch(Exception e){return new JSONArray();}}
}
