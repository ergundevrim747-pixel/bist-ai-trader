package com.bistaitrader;

public class Stock {
    public String symbol = "";
    public String name = "";
    public String sector = "";
    public double price = 0;
    public double previousClose = 0;
    public double changePct = 0;
    public double volume = 0;
    public double avgVolume = 0;
    public double rsi = 50;
    public double macd = 0;
    public double macdSignal = 0;
    public double ema20 = 0;
    public double ema50 = 0;
    public double ema200 = 0;
    public double atrPct = 0;
    public double momentumPct = 0;
    public double bollingerUpper = 0;
    public double bollingerLower = 0;
    public double volumeRatio = 1;
    public double score = 50;
    public double newsScore = 0;
    public String trend = "Belirsiz";
    public String signal = "BEKLE";
    public String risk = "Orta Risk";
    public double support1 = 0, support2 = 0, resistance1 = 0, resistance2 = 0;
    public double stopPrice = 0, targetPrice = 0;
    public long updatedAt = System.currentTimeMillis();
    public boolean live = false;
    public boolean analysisReady = false;

    public Stock copy() {
        Stock s = new Stock();
        s.symbol=symbol; s.name=name; s.sector=sector; s.price=price; s.previousClose=previousClose;
        s.changePct=changePct; s.volume=volume; s.avgVolume=avgVolume; s.rsi=rsi; s.macd=macd;
        s.macdSignal=macdSignal; s.ema20=ema20; s.ema50=ema50; s.ema200=ema200; s.atrPct=atrPct; s.momentumPct=momentumPct;
        s.bollingerUpper=bollingerUpper; s.bollingerLower=bollingerLower; s.volumeRatio=volumeRatio; s.score=score; s.newsScore=newsScore;
        s.trend=trend; s.signal=signal; s.risk=risk; s.support1=support1; s.support2=support2; s.resistance1=resistance1;
        s.resistance2=resistance2; s.stopPrice=stopPrice; s.targetPrice=targetPrice; s.updatedAt=updatedAt; s.live=live; s.analysisReady=analysisReady;
        return s;
    }
}
