# BIST AI Trader V5.1 — Signal Balance Fix

Bu sürüm özellikle kullanıcı geri bildirimindeki üç sorunu düzeltir:

- **Teknik AL ≠ Giriş AL:** Ekranda teknik rating ile gerçek giriş kararı açıkça ayrılır. Teknik AL olup ana 7 koşul/giriş güvenliği yeterli değilse sonuç **AL ADAYI** veya **BEKLE** olarak açıklanır; artık “AL • TV teknik” gibi kafa karıştıran bir satır kullanılmaz.
- **AL / AL ADAYI / BEKLE / SAT filtresi:** Riskli BIST piyasası tek başına AL'ı kilitlemez. Güçlü bireysel hisseler piyasa zayıfken de aday olabilir. Stop, R/R, aşırı uzama, dağıtım, volatilite ve giriş bölgesi gibi gerçek risk kapıları korunur. 5/7 ana adaylık eşiğidir; güçlü bağımsız teknik rating + 4/7 da aday havuzuna girebilir.
- **Kısa vade ve 3 vade özeti:** Kısa vade için minimum geçerli veri 60 güne indirildi. Yeterli veri yoksa kaç gün bulunduğu açıkça yazılır. “3 vadenin özeti” artık analiz sonuçları geldikçe kendini günceller; ağ/histori verisi başarısız olursa sonsuz “yükleniyor” ekranında kalmaz.

### GitHub Actions
Projeyi Android Studio olmadan GitHub Actions ile derleyebilirsin. Kök dizine `BIST_AI_Trader_V5_SIGNAL_BALANCED_FIX.zip` yükleyip workflow'u çalıştır.
