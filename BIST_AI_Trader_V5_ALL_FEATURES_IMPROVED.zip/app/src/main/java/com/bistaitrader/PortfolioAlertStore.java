package com.bistaitrader;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

/** Persistent anti-spam state and audit trail for virtual-portfolio alerts. */
public final class PortfolioAlertStore {
    private final android.content.SharedPreferences sp;
    public PortfolioAlertStore(Context c){sp=c.getApplicationContext().getSharedPreferences("portfolio_alerts",Context.MODE_PRIVATE);}
    private String stateKey(String sym){return "state_"+sym;}
    private String notifiedKey(String sym){return "notified_"+sym;}
    public synchronized int state(String sym){return sp.getInt(stateKey(sym),0);}
    public synchronized long lastNotified(String sym){return sp.getLong(notifiedKey(sym),0L);}
    public synchronized void setState(String sym,int state){sp.edit().putInt(stateKey(sym),state).apply();}
    public synchronized void setNotified(String sym,long time){sp.edit().putLong(notifiedKey(sym),time).apply();}
    public synchronized void clear(String sym){sp.edit().remove(stateKey(sym)).remove(notifiedKey(sym)).apply();}
    public synchronized void addHistory(String symbol,String level,String title,String detail,long time){
        JSONArray a=read("history");
        try{JSONObject o=new JSONObject();o.put("symbol",symbol);o.put("level",level);o.put("title",title);o.put("detail",detail);o.put("time",time);a.put(o);}catch(Exception ignored){}
        while(a.length()>300)a.remove(0);
        sp.edit().putString("history",a.toString()).apply();
    }
    public synchronized JSONArray history(){return read("history");}
    public synchronized void clearAll(){sp.edit().clear().apply();}
    private JSONArray read(String key){try{return new JSONArray(sp.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
}
