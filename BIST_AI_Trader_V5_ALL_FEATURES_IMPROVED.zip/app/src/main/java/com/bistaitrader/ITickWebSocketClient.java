package com.bistaitrader;

import android.os.Handler;
import android.os.Looper;
import okhttp3.*;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Best-effort iTick stock WebSocket for up to 3 portfolio symbols on the free tier.
 * It never fabricates data and falls back to the REST monitor when disconnected.
 */
public final class ITickWebSocketClient {
    public interface Listener { void onQuote(String symbol,double price,double volume,long quoteTime); }
    private final String token;
    private final List<String> symbols;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final OkHttpClient client=new OkHttpClient.Builder().readTimeout(0,TimeUnit.MILLISECONDS).pingInterval(30,TimeUnit.SECONDS).build();
    private WebSocket socket;
    private volatile boolean closed=false;

    public ITickWebSocketClient(String token,List<String> symbols,Listener listener){
        this.token=token; this.symbols=new ArrayList<>(symbols); this.listener=listener;
    }
    public void connect(){
        closed=false;
        Request req=new Request.Builder().url("wss://api-free.itick.org/stock").header("token",token).build();
        socket=client.newWebSocket(req,new WebSocketListener(){
            @Override public void onOpen(WebSocket webSocket,Response response){
                StringBuilder p=new StringBuilder(); for(String s:symbols){if(p.length()>0)p.append(',');p.append(s).append("$TR");}
                try{webSocket.send(new JSONObject().put("ac","subscribe").put("params",p.toString()).put("types","quote").toString());}catch(Exception ignored){}
            }
            @Override public void onMessage(WebSocket webSocket,String text){parse(text);}
            @Override public void onFailure(WebSocket webSocket,Throwable t,Response response){
                getStatus(false,String.valueOf(t.getMessage()));
                if(!closed)reconnectLater();
            }
            @Override public void onClosed(WebSocket webSocket,int code,String reason){getStatus(false,reason);if(!closed)reconnectLater();}
        });
    }
    private void parse(String text){
        try{
            JSONObject root=new JSONObject(text); JSONObject data=root.optJSONObject("data");
            if(data==null)return;
            double price=data.optDouble("ld",0); if(price<=0)return;
            String sym=data.optString("s","").trim().toUpperCase(Locale.ROOT); if(sym.isEmpty())return;
            long t=data.optLong("t",System.currentTimeMillis()); double v=data.optDouble("v",0);
            main.post(()->{if(listener!=null)listener.onQuote(sym,price,v,t);});
        }catch(Exception ignored){}
    }
    private void reconnectLater(){main.postDelayed(()->{if(!closed)connect();},5000L);}
    private void getStatus(boolean ok,String detail){ }
    public void close(){closed=true;try{if(socket!=null)socket.close(1000,"bye");}catch(Exception ignored){}try{client.connectionPool().evictAll();client.dispatcher().executorService().shutdown();}catch(Exception ignored){}}
}
