BIST AI Trader V5 - GitHub Actions yükleme

1) Bu klasördeki BIST_AI_Trader_V5_ALL_FEATURES.zip dosyasını GitHub repository root'una yükleyin.
2) .github/workflows/BIST_AI_Trader_V5_ALL_FEATURES_WORKFLOW.yml yolunu oluşturup workflow dosyasını oraya yükleyin.
3) Actions > Build BIST AI Trader v5 > Run workflow.

ÖNEMLİ:
Workflow artık android-actions/setup-android@v3 kullanmıyor ve eski 'sdkmanager tools' paketini istemiyor.
GitHub runner üzerindeki mevcut Android SDK cmdline-tools içinden sdkmanager bulunup yalnızca:
- platform-tools
- platforms;android-35
- build-tools;35.0.0
kuruluyor.

Başarılı build sonrası APK:
app/build/outputs/apk/debug/*.apk
ve Actions Artifacts altında BIST_AI_Trader_v5_debug adıyla oluşur.
