package com.bistaitrader;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DataService {
    public interface Listener { void onData(List<Stock> stocks, boolean live, String message); }

    private final Context context;
    private final Listener listener;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String,Stock> cache = new LinkedHashMap<>();
    private int tick = 0;

    public DataService(Context c, Listener l) { context=c.getApplicationContext(); listener=l; seed(); }

    public List<Stock> current() { return new ArrayList<>(cache.values()); }

    private void seed() {
        List<String> symbols = StockUniverse.allSymbols();
        for (int i=0;i<symbols.size();i++) {
            String sym=symbols.get(i);
            Stock s=new Stock(); s.symbol=sym; s.name=prettyName(sym); s.sector=guessSector(sym);
            AnalysisEngine.enrichDemo(s,i); cache.put(sym,s);
        }
    }

    public void refresh() {
        executor.execute(() -> {
            String base = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("base_url", "").trim();
            String token = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("token", "").trim();
            boolean liveMode = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("live_mode", false);
            if (liveMode && !base.isEmpty()) {
                try {
                    String body = fetch(base, token);
                    int count = applyJson(body);
                    if (count > 0) {
                        notifyData(true, "CANLI • " + count + " hisse güncellendi");
                        return;
                    }
                } catch (Exception e) {
                    notifyData(false, "Canlı veri alınamadı: " + safeMessage(e));
                    return;
                }
            }
            tick++;
            List<Stock> values=new ArrayList<>(cache.values());
            for(int i=0;i<values.size();i++) AnalysisEngine.enrichDemo(values.get(i),i+tick);
            notifyData(false, "DEMO • gerçek zamanlı veri bağlantısı bekleniyor");
        });
    }

    private String fetch(String base,String token) throws Exception {
        String sep = base.contains("?") ? "&" : "?";
        String symbols = String.join(",", StockUniverse.allSymbols());
        String urlText = base + sep + "symbols=" + java.net.URLEncoder.encode(symbols, "UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(9000); c.setRequestMethod("GET"); c.setRequestProperty("Accept","application/json");
        if(!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
        int code=c.getResponseCode();
        InputStream in= code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){ BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null) sb.append(line); r.close(); }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("HTTP "+code+" " + sb);
        return sb.toString();
    }

    private int applyJson(String body) throws Exception {
        Object root = new org.json.JSONTokener(body).nextValue();
        JSONArray arr;
        if(root instanceof JSONObject){
            JSONObject o=(JSONObject)root;
            if(o.has("symbols")) arr=o.getJSONArray("symbols");
            else if(o.has("data")) arr=o.getJSONArray("data");
            else arr=null;
        } else if(root instanceof JSONArray) arr=(JSONArray)root; else arr=null;
        if(arr==null) return 0;
        int count=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.getJSONObject(i);
            String sym = firstString(o,"symbol","ticker","code");
            if(sym==null||sym.isEmpty()) continue;
            sym=sym.toUpperCase(Locale.US);
            Stock s=cache.get(sym); if(s==null){ s=new Stock(); s.symbol=sym; s.name=prettyName(sym); s.sector="BIST"; cache.put(sym,s); }
            s.price=firstDouble(o,"price","last","close",s.price);
            s.previousClose=firstDouble(o,"previousClose","prevClose","previous_close",s.previousClose>0?s.previousClose:s.price);
            s.changePct=firstDouble(o,"changePct","changePercent","percent",safePct(s.price,s.previousClose));
            s.volume=firstDouble(o,"volume","turnover","qty",s.volume);
            s.avgVolume=firstDouble(o,"avgVolume","averageVolume","avg_volume",s.avgVolume);
            s.rsi=firstDouble(o,"rsi",s.rsi); s.macd=firstDouble(o,"macd",s.macd); s.ema20=firstDouble(o,"ema20",s.ema20); s.ema50=firstDouble(o,"ema50",s.ema50);
            s.atrPct=firstDouble(o,"atrPct","atr_percent",s.atrPct); s.score=firstDouble(o,"score","aiScore",s.score);
            s.newsScore=firstDouble(o,"newsScore","news_score",s.newsScore);
            s.signal=firstString(o,"signal","action"); if(s.signal==null) s.signal="BEKLE";
            s.risk=firstString(o,"risk","riskLevel"); if(s.risk==null) s.risk=riskFromScore(s.score,s.atrPct);
            s.support1=firstDouble(o,"support1","support",s.support1); s.support2=firstDouble(o,"support2",s.support2);
            s.resistance1=firstDouble(o,"resistance1","resistance",s.resistance1); s.resistance2=firstDouble(o,"resistance2",s.resistance2);
            s.name=firstString(o,"name","company")!=null?firstString(o,"name","company"):s.name;
            s.sector=firstString(o,"sector")!=null?firstString(o,"sector"):s.sector;
            s.updatedAt=System.currentTimeMillis(); s.live=true; count++;
        }
        return count;
    }

    private void notifyData(boolean live,String msg){ main.post(()->listener.onData(current(),live,msg)); }
    private static String safeMessage(Exception e){ return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(); }
    private static double safePct(double p,double pc){ return pc==0?0:(p/pc-1)*100; }
    private static double firstDouble(JSONObject o,String k1,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); if(k2!=null&&o.has(k2)&&!o.isNull(k2)) return o.optDouble(k2,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,String k3,double def){ double v=firstDouble(o,k1,k2,Double.NaN); return Double.isNaN(v)?firstDouble(o,k3,null,def):v; }
    private static String firstString(JSONObject o,String... ks){ for(String k:ks){ if(o.has(k)&&!o.isNull(k)){ String v=o.optString(k,""); if(!v.isEmpty()) return v; } } return null; }
    private static String riskFromScore(double s,double atr){ if(atr<2.5 && s>=45) return "Düşük Risk"; if(atr<5.0) return "Orta Risk"; return "Yüksek Risk"; }

    static String prettyName(String s){
        Map<String,String> m=new HashMap<>();
        m.put("THYAO","Türk Hava Yolları"); m.put("ASELS","Aselsan"); m.put("AKBNK","Akbank"); m.put("SAHOL","Sabancı Holding"); m.put("TUPRS","Tüpraş"); m.put("BIMAS","BİM Mağazalar");
        m.put("KCHOL","Koç Holding"); m.put("SISE","Şişecam"); m.put("EREGL","Ereğli Demir Çelik"); m.put("FROTO","Ford Otosan"); m.put("GARAN","Garanti BBVA"); m.put("YKBNK","Yapı Kredi");
        m.put("ISCTR","İş Bankası C"); m.put("TCELL","Turkcell"); m.put("PGSUS","Pegasus"); m.put("TOASO","Tofaş"); m.put("EKGYO","Emlak Konut"); m.put("TAVHL","TAV Havalimanları");
        return m.containsKey(s)?m.get(s):s;
    }
    static String guessSector(String s){
        if(Arrays.asList("AKBNK","GARAN","YKBNK","ISCTR","HALKB","VAKBN","TSKB","SKBNK","ALBRK").contains(s)) return "Bankacılık";
        if(Arrays.asList("THYAO","PGSUS","TAVHL").contains(s)) return "Ulaştırma";
        if(Arrays.asList("ASELS","ALTNY","SDTTR","PAPIL","FORTE").contains(s)) return "Savunma/Teknoloji";
        if(Arrays.asList("TUPRS","PETKM","AKSA","SASA","KMPUR").contains(s)) return "Kimya/Enerji";
        if(Arrays.asList("BIMAS","MGROS","SOKM","MAVI","ULKER").contains(s)) return "Perakende";
        if(s.endsWith("GYO")||s.contains("GYO")) return "GYO";
        return "BIST Hisse";
    }
}
