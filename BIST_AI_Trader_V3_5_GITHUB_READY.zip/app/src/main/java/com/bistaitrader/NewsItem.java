package com.bistaitrader;
public class NewsItem { public String symbol=""; public String title=""; public String source=""; public String time=""; public double sentiment=0; }
