package com.bistaitrader;

public class Candle {
    public long time;
    public String date = "";
    public double open, high, low, close, volume;

    public Candle(long time, String date, double open, double high, double low, double close, double volume) {
        this.time = time;
        this.date = date == null ? "" : date;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
    }
}
