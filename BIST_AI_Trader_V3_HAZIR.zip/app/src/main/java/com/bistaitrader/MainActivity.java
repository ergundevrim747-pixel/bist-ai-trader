package com.bistaitrader;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements DataService.Listener, NewsService.Listener, HistoryService.Listener {
    private static final int BG=Color.rgb(7,14,26), SURFACE=Color.rgb(14,24,40), SURFACE2=Color.rgb(20,34,54), LINE=Color.rgb(38,56,81), TEXT=Color.rgb(244,247,251), MUTED=Color.rgb(145,164,186), BLUE=Color.rgb(84,145,255), GREEN=Color.rgb(48,209,88), YELLOW=Color.rgb(255,204,0), RED=Color.rgb(255,79,91), CYAN=Color.rgb(72,211,255);

    private enum Screen { HOME, MARKET, WATCH, PORTFOLIO, SETTINGS, DETAIL, HISTORY }
    private Screen screen=Screen.HOME, listScreen=Screen.MARKET;

    private LinearLayout root, content, listHost, nav;
    private TextView status, statusMessage;
    private EditText search;
    private String marketCategory="Tümü", sort="Sinyal", riskFilter="Tümü", historyRange="6A";
    private final ArrayList<Stock> all=new ArrayList<>();
    private Stock current;
    private DataService data; private NewsService news; private HistoryService history; private PortfolioStore portfolio;
    private LinearLayout detailNewsList;
    private HistoryChartView historyChart;
    private TextView historyInfo;
    private String historyMode="Mum";
    private Handler timer=new Handler(Looper.getMainLooper()); private Runnable refreshTask;
    private boolean live=false;
    private long lastBackToast=0;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,float sp,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(c);t.setFontFeatureSettings("kern");return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),LINE);return g;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(15),dp(16),dp(15));l.setBackground(bg(SURFACE,18));return l;}
    TextView pill(String text,int color){TextView t=tv(text,10,TEXT);t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(5),dp(10),dp(5));t.setBackground(bg(color,13));return t;}
    Button chip(String text,boolean selected){Button b=new Button(this);b.setText(text);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(selected?Color.BLACK:TEXT);b.setPadding(dp(11),0,dp(11),0);b.setMinHeight(0);b.setMinimumHeight(dp(36));b.setStateListAnimator(null);b.setBackground(bg(selected?BLUE:SURFACE2,18));return b;}
    Button action(String text,int color){Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(color==YELLOW?Color.BLACK:Color.WHITE);b.setTypeface(null,Typeface.BOLD);b.setMinHeight(0);b.setMinimumHeight(dp(44));b.setStateListAnimator(null);b.setBackground(bg(color,14));return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);portfolio=new PortfolioStore(this);data=new DataService(this,this);news=new NewsService(this,this);history=new HistoryService(this);if(Build.VERSION.SDK_INT>=33){getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);}buildShell();showDashboard();startRefresh();}
    @Override protected void onResume(){super.onResume();if(refreshTask!=null)timer.post(refreshTask);}
    @Override protected void onPause(){super.onPause();timer.removeCallbacksAndMessages(null);}

    @Override public void onBackPressed(){handleBack();}
    private void handleBack(){
        if(screen==Screen.HISTORY){showDetail(current);return;}
        if(screen==Screen.DETAIL){returnToList();return;}
        if(screen==Screen.MARKET || screen==Screen.WATCH || screen==Screen.PORTFOLIO || screen==Screen.SETTINGS){showDashboard();return;}
        long now=System.currentTimeMillis();
        if(now-lastBackToast<1200) { return; }
        lastBackToast=now; toast("Ana sayfadasın • aşağıdaki menüden devam edebilirsin");
    }

    private void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(16),dp(10),dp(16),dp(9));bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(BG);
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        TextView title=tv("BIST AI TRADER",19,TEXT);title.setTypeface(null,Typeface.BOLD);brand.addView(title);
        statusMessage=tv("500 hisselik tarayıcı • sanal işlem",10,MUTED);brand.addView(statusMessage);
        bar.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        status=tv("● HAZIR",11,YELLOW);status.setTypeface(null,Typeface.BOLD);status.setGravity(Gravity.RIGHT);bar.addView(status,new LinearLayout.LayoutParams(dp(92),-2));
        root.addView(bar);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(4),dp(12),dp(28));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        nav=new LinearLayout(this);nav.setPadding(dp(6),dp(5),dp(6),dp(5));nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(SURFACE);
        TextView home=navBtn("⌂\nAna"), market=navBtn("▦\nPiyasa"), fav=navBtn("☆\nTakip"), pf=navBtn("₺\nPortföy"), set=navBtn("⚙\nAyar");
        nav.addView(home,new LinearLayout.LayoutParams(0,dp(54),1));nav.addView(market,new LinearLayout.LayoutParams(0,dp(54),1));nav.addView(fav,new LinearLayout.LayoutParams(0,dp(54),1));nav.addView(pf,new LinearLayout.LayoutParams(0,dp(54),1));nav.addView(set,new LinearLayout.LayoutParams(0,dp(54),1));root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
        home.setOnClickListener(v->showDashboard());market.setOnClickListener(v->showMarket());fav.setOnClickListener(v->showWatchlist());pf.setOnClickListener(v->showPortfolio());set.setOnClickListener(v->showSettings());setContentView(root);
    }
    TextView navBtn(String s){TextView t=tv(s,10,MUTED);t.setGravity(Gravity.CENTER);t.setTypeface(null,Typeface.BOLD);t.setBackgroundColor(Color.TRANSPARENT);t.setClickable(true);return t;}
    private void selectNav(String which){for(int i=0;i<nav.getChildCount();i++){TextView t=(TextView)nav.getChildAt(i);t.setTextColor(MUTED);}int idx=which.equals("Ana")?0:which.equals("Piyasa")?1:which.equals("Takip")?2:which.equals("Portföy")?3:4;if(idx<nav.getChildCount())((TextView)nav.getChildAt(idx)).setTextColor(TEXT);}

    void showDashboard(){
        screen=Screen.HOME; selectNav("Ana"); listScreen=Screen.MARKET; current=null; marketCategory="Tümü";
        clear();
        content.addView(tv("Piyasa özeti",26,TEXT));content.addView(tv("Fiyat • teknik analiz • sinyal • geçmiş grafik",12,MUTED));spacer(12);
        LinearLayout hero=card();hero.addView(tv("Bugünün tarayıcısı",16,TEXT));
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(pill(live?"VERİ BAĞLI":"VERİ YÜKLENİYOR",live?GREEN:YELLOW),new LinearLayout.LayoutParams(dp(105),dp(32)));spaceH(r,8);r.addView(tv(live?"Güncel fiyat akışı alındı.":"Fiyatlar kaynaktan gelene kadar örnek fiyat gösterilmiyor.",11,MUTED),new LinearLayout.LayoutParams(0,-2,1));hero.addView(r);content.addView(hero);spacer(12);

        LinearLayout idx=new LinearLayout(this);idx.setOrientation(LinearLayout.HORIZONTAL);
        idx.addView(indexCard("BIST 30","XU030","BIST 30"),new LinearLayout.LayoutParams(0,dp(92),1));spaceH(idx,8);idx.addView(indexCard("BIST 100","XU100","BIST 100"),new LinearLayout.LayoutParams(0,dp(92),1));spaceH(idx,8);idx.addView(indexCard("Geniş Katalog","500+","BIST 500"),new LinearLayout.LayoutParams(0,dp(92),1));content.addView(idx);spacer(12);

        LinearLayout c=card();c.addView(tv("Hızlı tarama",16,TEXT));c.addView(tv("Listeyi kategori değiştirerek tek ekranda gez.",11,MUTED));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout ch=new LinearLayout(this);String[] cs={"Tümü","BIST 30","BIST 50","BIST 100","BIST 500"};for(String x:cs){Button b=chip(x,x.equals(marketCategory));ch.addView(b,new LinearLayout.LayoutParams(-2,dp(38)));spaceH(ch,6);b.setOnClickListener(v->{marketCategory=x;renderList();});}hs.addView(ch);c.addView(hs);content.addView(c);spacer(12);

        LinearLayout rf=card();rf.addView(tv("Risk filtresi",16,TEXT));rf.addView(tv("Risk sınıfı volatilite/likidite ölçümlerinden türetilir.",11,MUTED));HorizontalScrollView rh=new HorizontalScrollView(this);rh.setHorizontalScrollBarEnabled(false);LinearLayout rc=new LinearLayout(this);String[] rs={"Tümü","Düşük Risk","Orta Risk","Yüksek Risk"};for(String x:rs){Button b=chip(x,x.equals(riskFilter));rc.addView(b,new LinearLayout.LayoutParams(-2,dp(38)));spaceH(rc,6);b.setOnClickListener(v->{riskFilter=x;renderList();});}rh.addView(rc);rf.addView(rh);content.addView(rf);spacer(12);

        LinearLayout sig=card();sig.addView(tv("Son sinyal değişimleri",16,TEXT));String[] logs=readSignalLogs(5);if(logs.length==0)sig.addView(tv("Henüz kaydedilmiş sinyal değişimi yok.",11,MUTED));else for(String x:logs){sig.addView(tv(x,11,TEXT));spacerIn(sig,4);}content.addView(sig);spacer(12);

        listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();
    }

    LinearLayout indexCard(String name,String code,String category){LinearLayout c=card();c.setPadding(dp(12),dp(12),dp(12),dp(12));TextView a=tv(name,10,MUTED);TextView b=tv(code,16,TEXT);b.setTypeface(null,Typeface.BOLD);TextView d=tv(category.equals("BIST 500")?"Geniş tarama":"Hızlı görünüm",9,live?GREEN:YELLOW);c.addView(a);c.addView(b);c.addView(d);c.setOnClickListener(v->{marketCategory=category;showMarket();});return c;}

    void showMarket(){screen=Screen.MARKET;selectNav("Piyasa");listScreen=Screen.MARKET;clear();content.addView(tv("Piyasa tarayıcı",26,TEXT));content.addView(tv("Bütün hisseler aşağı doğru tek listede.",12,MUTED));spacer(10);buildSearchAndSort();
        categoryRow();spacer(10);listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();}
    void showWatchlist(){screen=Screen.WATCH;selectNav("Takip");listScreen=Screen.WATCH;marketCategory="Takip";clear();content.addView(tv("Takip listem",26,TEXT));content.addView(tv("Yıldız verdiğin hisseler burada toplanır.",12,MUTED));spacer(10);buildSearchAndSort();listHost=new LinearLayout(this);listHost.setOrientation(LinearLayout.VERTICAL);content.addView(listHost);renderList();}

    void buildSearchAndSort(){
        search=new EditText(this);search.setSingleLine(true);search.setHint("Hisse ara: THYAO, ASELS, şirket adı...");search.setHintTextColor(MUTED);search.setTextColor(TEXT);search.setTextSize(13);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(SURFACE2,14));content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){renderList();}public void afterTextChanged(Editable e){}});spacer(8);
        LinearLayout row=new LinearLayout(this);Button sortB=chip("Sıralama: "+sort,false);sortB.setOnClickListener(v->chooseSort(sortB));Button refresh=chip("↻ Yenile",false);refresh.setOnClickListener(v->data.refresh());row.addView(sortB,new LinearLayout.LayoutParams(0,dp(38),1));spaceH(row,8);row.addView(refresh,new LinearLayout.LayoutParams(dp(115),dp(38)));content.addView(row);
    }
    void categoryRow(){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout ch=new LinearLayout(this);String[] cs={"Tümü","BIST 30","BIST 50","BIST 100","BIST 500","Takip"};for(String x:cs){Button b=chip(x,x.equals(marketCategory));ch.addView(b,new LinearLayout.LayoutParams(-2,dp(38)));spaceH(ch,6);b.setOnClickListener(v->{marketCategory=x;renderList();});}hs.addView(ch);content.addView(hs);}
    void chooseSort(Button b){final String[] ops={"Sinyal","Günlük %","Hacim","Skor","Fiyat"};new AlertDialog.Builder(this).setTitle("Sıralama").setItems(ops,(d,w)->{sort=ops[w];b.setText("Sıralama: "+sort);renderList();}).show();}

    void renderList(){
        if(listHost==null)return;listHost.removeAllViews();
        List<Stock> list=new ArrayList<>(all);String q=search==null?"":search.getText().toString().trim().toUpperCase(Locale.US);
        if(marketCategory.equals("Takip"))list.removeIf(s->!isFavorite(s.symbol));else list.removeIf(s->!MarketGroups.matches(marketCategory,s));
        if(!riskFilter.equals("Tümü"))list.removeIf(s->!riskFilter.equals(s.risk));
        if(!q.isEmpty())list.removeIf(s->!s.symbol.contains(q)&&!s.name.toUpperCase(Locale.US).contains(q));
        Comparator<Stock> cmp=Comparator.comparingDouble((Stock s)->-s.score);
        if(sort.equals("Günlük %"))cmp=Comparator.comparingDouble((Stock s)->-s.changePct);if(sort.equals("Hacim"))cmp=Comparator.comparingDouble((Stock s)->-s.volume);if(sort.equals("Fiyat"))cmp=Comparator.comparingDouble((Stock s)->-s.price);list.sort(cmp);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView h=tv(list.size()+" hisse",11,MUTED);TextView k=tv(live?"Kaynak bağlı":"Veri bekleniyor",10,live?GREEN:YELLOW);head.addView(h,new LinearLayout.LayoutParams(0,-2,1));head.addView(k);listHost.addView(head);spacerIn(listHost,6);
        if(list.isEmpty()){LinearLayout empty=card();empty.addView(tv("Bu filtrede hisse bulunamadı.",14,TEXT));empty.addView(tv("Kategori veya aramayı değiştir.",11,MUTED));listHost.addView(empty);return;}
        for(Stock s:list)listHost.addView(stockRow(s),new LinearLayout.LayoutParams(-1,dp(74)));
    }

    View stockRow(Stock s){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(11),dp(8),dp(9),dp(8));row.setBackground(bg(SURFACE,15));row.setClickable(true);row.setOnClickListener(v->{current=s;listScreen=screen==Screen.WATCH?Screen.WATCH:Screen.MARKET;showDetail(s);});
        TextView star=tv(isFavorite(s.symbol)?"★":"☆",23,isFavorite(s.symbol)?YELLOW:MUTED);star.setGravity(Gravity.CENTER);star.setClickable(true);star.setOnClickListener(v->{toggleFavorite(s.symbol);renderList();});row.addView(star,new LinearLayout.LayoutParams(dp(30),-1));
        LinearLayout name=new LinearLayout(this);name.setOrientation(LinearLayout.VERTICAL);TextView sy=tv(s.symbol,14,TEXT);sy.setTypeface(null,Typeface.BOLD);TextView nm=tv(s.name.isEmpty()?s.symbol:s.name,9,MUTED);nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);name.addView(sy);name.addView(nm);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.setGravity(Gravity.RIGHT);String price=s.price>0?formatPrice(s.price):"—";TextView pr=tv(price,14,TEXT);pr.setTypeface(null,Typeface.BOLD);String cp=s.price>0?String.format(Locale.US,"%+.2f%%",s.changePct):"—";TextView ch=tv(cp,10,s.changePct>=0?GREEN:RED);ch.setGravity(Gravity.RIGHT);mid.addView(pr);mid.addView(ch);row.addView(mid,new LinearLayout.LayoutParams(dp(90),-2));
        TextView sg=pill(s.signal,s.signal.equals("AL")?GREEN:s.signal.equals("SAT")?RED:YELLOW);row.addView(sg,new LinearLayout.LayoutParams(dp(68),dp(30)));return row;
    }

    void showDetail(Stock s){
        if(s==null)return;screen=Screen.DETAIL;current=s;clear();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹ Geri",13,BLUE);back.setTypeface(null,Typeface.BOLD);back.setClickable(true);back.setOnClickListener(v->returnToList());top.addView(back,new LinearLayout.LayoutParams(dp(70),dp(40)));TextView head=tv(s.symbol,19,TEXT);head.setTypeface(null,Typeface.BOLD);top.addView(head,new LinearLayout.LayoutParams(0,dp(40),1));TextView fav=tv(isFavorite(s.symbol)?"★":"☆",25,isFavorite(s.symbol)?YELLOW:MUTED);fav.setGravity(Gravity.CENTER);fav.setOnClickListener(v->{toggleFavorite(s.symbol);showDetail(find(s.symbol));});top.addView(fav,new LinearLayout.LayoutParams(dp(45),dp(40)));content.addView(top);
        TextView nm=tv((s.name.isEmpty()?s.symbol:s.name)+"  •  "+s.sector,11,MUTED);content.addView(nm);spacer(8);
        LinearLayout quote=card();LinearLayout qr=new LinearLayout(this);qr.setGravity(Gravity.CENTER_VERTICAL);TextView pr=tv(s.price>0?formatPrice(s.price):"—",28,TEXT);pr.setTypeface(null,Typeface.BOLD);qr.addView(pr,new LinearLayout.LayoutParams(0,-2,1));qr.addView(pill(s.signal,s.signal.equals("AL")?GREEN:s.signal.equals("SAT")?RED:YELLOW),new LinearLayout.LayoutParams(dp(76),dp(34)));quote.addView(qr);quote.addView(tv(s.price>0?String.format(Locale.US,"%+.2f%% bugün • skor %.0f • %s",s.changePct,s.score,s.risk):"Geçmiş veri ve teknik analiz yükleniyor…",11,s.changePct>=0?GREEN:MUTED));content.addView(quote);spacer(10);
        historyChart=new HistoryChartView(this);historyChart.setMode(HistoryChartView.Mode.LINE);historyChart.setCandles(Collections.emptyList());content.addView(historyChart,new LinearLayout.LayoutParams(-1,dp(205)));spacer(7);
        Button full=action("Grafik & Geçmiş Veriler",BLUE);full.setOnClickListener(v->showHistory(s));content.addView(full);spacer(10);
        LinearLayout metrics=card();metrics.addView(tv("Teknik analiz",16,TEXT));addMetricGrid(metrics,s);content.addView(metrics);spacer(10);
        LinearLayout levels=card();levels.addView(tv("Destek / direnç ve risk planı",16,TEXT));levels.addView(metricLine("Destek 2",s.support2));levels.addView(metricLine("Destek 1",s.support1));levels.addView(metricLine("Direnç 1",s.resistance1));levels.addView(metricLine("Direnç 2",s.resistance2));levels.addView(metricLine("Stop seviyesi",s.stopPrice));levels.addView(metricLine("Hedef seviyesi",s.targetPrice));content.addView(levels);spacer(10);
        LinearLayout ai=card();ai.addView(tv("Analiz gerekçesi",16,TEXT));ai.addView(tv(AnalysisEngine.reason(s),11,MUTED));content.addView(ai);spacer(10);
        LinearLayout newsCard=card();newsCard.addView(tv("Haber / KAP akışı",16,TEXT));detailNewsList=new LinearLayout(this);detailNewsList.setOrientation(LinearLayout.VERTICAL);detailNewsList.addView(tv("Yükleniyor…",11,MUTED));newsCard.addView(detailNewsList);content.addView(newsCard);news.refresh(s.symbol);spacer(10);
        LinearLayout trade=card();trade.addView(tv("Sanal işlem",16,TEXT));EditText qty=new EditText(this);qty.setHint("Adet");qty.setText("10");qty.setInputType(2);qty.setTextColor(TEXT);qty.setHintTextColor(MUTED);qty.setBackground(bg(SURFACE2,12));trade.addView(qty,new LinearLayout.LayoutParams(-1,dp(46)));spacerIn(trade,8);LinearLayout rr=new LinearLayout(this);Button buy=action("Sanal AL",GREEN), sell=action("Sanal SAT",RED);rr.addView(buy,new LinearLayout.LayoutParams(0,dp(44),1));spaceH(rr,8);rr.addView(sell,new LinearLayout.LayoutParams(0,dp(44),1));trade.addView(rr);buy.setOnClickListener(v->tradeNow(s.symbol,qty,true));sell.setOnClickListener(v->tradeNow(s.symbol,qty,false));content.addView(trade);spacer(12);
        content.addView(tv("Son fiyat güncellemesi: "+time(s.updatedAt)+" • "+(s.live?"kaynak bağlı":"geçmiş analiz bekleniyor"),10,MUTED));
        history.load(s.symbol,"6A",this);
    }

    View metricLine(String name,double value){LinearLayout r=new LinearLayout(this);r.setPadding(0,dp(5),0,dp(5));r.addView(tv(name,11,MUTED),new LinearLayout.LayoutParams(0,-2,1));r.addView(tv(value>0?formatPrice(value):"—",12,TEXT));return r;}
    void addMetricGrid(LinearLayout box,Stock s){String[][] m={{"Trend",s.trend},{"RSI (14)",String.format(Locale.US,"%.1f",s.rsi)},{"MACD",String.format(Locale.US,"%.3f",s.macd)},{"EMA 20",formatPrice(s.ema20)},{"EMA 50",formatPrice(s.ema50)},{"EMA 200",formatPrice(s.ema200)},{"20G momentum",String.format(Locale.US,"%+.2f%%",s.momentumPct)},{"ATR %",String.format(Locale.US,"%.2f%%",s.atrPct)},{"Hacim oranı",String.format(Locale.US,"%.2fx",s.volumeRatio)},{"Bollinger",formatPrice(s.bollingerLower)+" — "+formatPrice(s.bollingerUpper)}};for(String[] x:m){LinearLayout r=new LinearLayout(this);r.setPadding(0,dp(5),0,dp(5));TextView a=tv(x[0],11,MUTED),b=tv(x[1],12,TEXT);b.setGravity(Gravity.RIGHT);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(b,new LinearLayout.LayoutParams(dp(180),-2));box.addView(r);}}

    void showHistory(Stock s){screen=Screen.HISTORY;current=s;clear();LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹ "+s.symbol,13,BLUE);back.setClickable(true);back.setTypeface(null,Typeface.BOLD);back.setOnClickListener(v->showDetail(s));top.addView(back,new LinearLayout.LayoutParams(dp(85),dp(42)));TextView t=tv("Grafik & geçmiş",19,TEXT);t.setTypeface(null,Typeface.BOLD);top.addView(t,new LinearLayout.LayoutParams(0,dp(42),1));content.addView(top);content.addView(tv("Günlük OHLCV • mum ve çizgi • dokunarak tarih seç",10,MUTED));spacer(8);
        HorizontalScrollView rh=new HorizontalScrollView(this);rh.setHorizontalScrollBarEnabled(false);LinearLayout ranges=new LinearLayout(this);String[] rs={"1A","3A","6A","1Y","3Y","5Y"};for(String x:rs){Button b=chip(x,x.equals(historyRange));ranges.addView(b,new LinearLayout.LayoutParams(-2,dp(36)));spaceH(ranges,6);b.setOnClickListener(v->{historyRange=x;showHistory(current);});}rh.addView(ranges);content.addView(rh);spacer(8);
        LinearLayout modes=new LinearLayout(this);Button candle=chip("Mum",historyMode.equals("Mum")), line=chip("Çizgi",historyMode.equals("Çizgi"));modes.addView(candle,new LinearLayout.LayoutParams(0,dp(36),1));spaceH(modes,8);modes.addView(line,new LinearLayout.LayoutParams(0,dp(36),1));candle.setOnClickListener(v->{historyMode="Mum";if(historyChart!=null)historyChart.setMode(HistoryChartView.Mode.CANDLE);showHistory(current);});line.setOnClickListener(v->{historyMode="Çizgi";if(historyChart!=null)historyChart.setMode(HistoryChartView.Mode.LINE);showHistory(current);});content.addView(modes);spacer(8);
        historyInfo=tv("Geçmiş veri yükleniyor…",10,MUTED);content.addView(historyInfo);spacer(5);historyChart=new HistoryChartView(this);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);content.addView(historyChart,new LinearLayout.LayoutParams(-1,dp(390)));spacer(8);
        LinearLayout note=card();note.addView(tv("Grafik kaynağı",15,TEXT));note.addView(tv("Günlük geçmiş verisi halka açık tarihsel veri uç noktalarından alınır. Veri sağlayıcı veya piyasa koşulları değişirse kaynak/frekans değişebilir; grafik lisanslı gerçek zamanlı akış iddiasında bulunmaz.",10,MUTED));content.addView(note);
        history.load(s.symbol,historyRange,this);
    }

    void showPortfolio(){screen=Screen.PORTFOLIO;selectNav("Portföy");clear();content.addView(tv("Sanal portföy",26,TEXT));content.addView(tv("Gerçek para yok • yalnızca simülasyon",12,MUTED));spacer(12);double cash=portfolio.cash(),value=cash;LinearLayout box=card();box.addView(tv("Portföy özeti",16,TEXT));for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);Stock s=find(sym);if(s!=null&&s.price>0)value+=s.price*q;}box.addView(tv(String.format(Locale.US,"Toplam değer   %.2f ₺",value),19,TEXT));box.addView(tv(String.format(Locale.US,"Nakit   %.2f ₺",cash),13,MUTED));box.addView(tv(String.format(Locale.US,"K/Z   %+.2f ₺",value-100000),13,value>=100000?GREEN:RED));content.addView(box);spacer(10);LinearLayout list=card();list.addView(tv("Pozisyonlar",16,TEXT));boolean any=false;for(String sym:portfolio.symbols()){int q=portfolio.qty(sym);if(q<=0)continue;any=true;Stock s=find(sym);double val=s!=null?s.price*q:0;list.addView(tv(String.format(Locale.US,"%s   •   %d adet   •   %.2f ₺",sym,q,val),13,TEXT));}if(!any)list.addView(tv("Henüz pozisyon yok.",11,MUTED));content.addView(list);spacer(10);Button reset=action("Portföyü sıfırla",YELLOW);reset.setOnClickListener(v->{portfolio.reset();showPortfolio();});content.addView(reset);}

    void showSettings(){screen=Screen.SETTINGS;selectNav("Ayar");clear();content.addView(tv("Ayarlar",26,TEXT));content.addView(tv("Veri, bildirim ve uygulama davranışı",12,MUTED));spacer(12);LinearLayout c=card();c.addView(tv("Veri bağlantısı",16,TEXT));c.addView(tv("Anlık fiyat alanı mevcut uygulamada İş Yatırım halka açık hisse ekranından okunur. Eşanlı lisanslı akış ayrıca bağlanabilir.",11,MUTED));Switch alertsS=new Switch(this);alertsS.setText("AL/SAT değişim bildirimleri");alertsS.setTextColor(TEXT);alertsS.setChecked(getSharedPreferences("settings",0).getBoolean("alerts",false));c.addView(alertsS);EditText url=field("Harici Quote API URL (opsiyonel)",getSharedPreferences("settings",0).getString("base_url",""));EditText token=field("API Token (opsiyonel)",getSharedPreferences("settings",0).getString("token",""));EditText newsUrl=field("Haber/KAP API URL (opsiyonel)",getSharedPreferences("settings",0).getString("news_url",""));EditText refreshSec=field("Fiyat yenileme saniyesi (min 10)",String.valueOf(getSharedPreferences("settings",0).getInt("refresh_sec",30)));refreshSec.setInputType(2);c.addView(url);c.addView(token);c.addView(newsUrl);c.addView(refreshSec);Button save=action("Kaydet ve yenile",GREEN);save.setOnClickListener(v->{getSharedPreferences("settings",0).edit().putBoolean("alerts",alertsS.isChecked()).putString("base_url",url.getText().toString().trim()).putString("token",token.getText().toString().trim()).putString("news_url",newsUrl.getText().toString().trim()).putInt("refresh_sec",Math.max(10,parseInt(refreshSec.getText().toString(),30))).apply();toast("Ayarlar kaydedildi");data.refresh();});c.addView(save);content.addView(c);spacer(10);
        LinearLayout h=card();h.addView(tv("Geçmiş grafik",16,TEXT));h.addView(tv("Mum/çizgi grafikleri günlük OHLCV geçmişi üzerinden oluşturulur. Tarih aralığı ve seçilen gün grafikte dokunarak incelenebilir.",11,MUTED));content.addView(h);spacer(10);Button req=action("Bildirim iznini kontrol et",BLUE);req.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},30);else toast("Bildirim izni açık");});content.addView(req);spacer(8);content.addView(tv("Not: Borsada garantili/risk­siz hisse yoktur. Risk sınıfları göreli ölçümlerdir.",10,MUTED));}
    EditText field(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(13),0,dp(13),0);e.setBackground(bg(SURFACE2,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(8);e.setLayoutParams(lp);return e;}

    private void startRefresh(){int sec=getSharedPreferences("settings",0).getInt("refresh_sec",30);refreshTask=()->{data.refresh();int s=getSharedPreferences("settings",0).getInt("refresh_sec",30);timer.postDelayed(refreshTask,Math.max(10,s)*1000L);};timer.post(refreshTask);}
    @Override public void onData(List<Stock> stocks,boolean l,String msg){all.clear();all.addAll(stocks);live=l;status.setText(l?"● VERİ BAĞLI":"● VERİ YOK");status.setTextColor(l?GREEN:YELLOW);statusMessage.setText(msg);if(listHost!=null)renderList();if(current!=null){Stock updated=find(current.symbol);if(updated!=null)current=updated;}saveSignalChanges(stocks);if(l&&getSharedPreferences("settings",0).getBoolean("alerts",false))checkSignalTransitions(stocks);}
    @Override public void onNews(List<NewsItem> items,String statusMsg){if(detailNewsList==null)return;detailNewsList.removeAllViews();if(items.isEmpty()){detailNewsList.addView(tv(statusMsg,11,MUTED));return;}for(NewsItem n:items){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);TextView h=tv(n.title,13,TEXT);h.setTypeface(null,Typeface.BOLD);TextView m=tv(n.source+"  •  "+n.time+"  •  duygu "+String.format(Locale.US,"%+.2f",n.sentiment),10,MUTED);r.addView(h);r.addView(m);detailNewsList.addView(r);spacerIn(detailNewsList,6);}}
    @Override public void onHistory(String symbol,String range,List<Candle> candles,String source,String msg){if(!symbol.equals(current==null?"":current.symbol))return;AnalysisEngine.enrichFromHistory(current,candles);Stock same=find(symbol);if(same!=null){same.rsi=current.rsi;same.macd=current.macd;same.macdSignal=current.macdSignal;same.ema20=current.ema20;same.ema50=current.ema50;same.ema200=current.ema200;same.atrPct=current.atrPct;same.momentumPct=current.momentumPct;same.bollingerUpper=current.bollingerUpper;same.bollingerLower=current.bollingerLower;same.volumeRatio=current.volumeRatio;same.avgVolume=current.avgVolume;same.support1=current.support1;same.support2=current.support2;same.resistance1=current.resistance1;same.resistance2=current.resistance2;same.stopPrice=current.stopPrice;same.targetPrice=current.targetPrice;same.score=current.score;same.signal=current.signal;same.risk=current.risk;same.trend=current.trend;same.analysisReady=current.analysisReady;}if(historyChart!=null){historyChart.setCandles(candles);historyChart.setMode(historyMode.equals("Mum")?HistoryChartView.Mode.CANDLE:HistoryChartView.Mode.LINE);}if(historyInfo!=null)historyInfo.setText(candles.isEmpty()?msg:source+" • "+candles.size()+" günlük veri • "+msg);if(screen==Screen.DETAIL&&historyChart!=null&&current!=null)historyChart.setCandles(candles);}

    void checkSignalTransitions(List<Stock> stocks){android.content.SharedPreferences p=getSharedPreferences("signals",0);for(Stock s:stocks){String old=p.getString(s.symbol,"");if(!old.isEmpty()&&!old.equals(s.signal)&&!s.signal.equals("BEKLE"))sendSignalNotification(s);p.edit().putString(s.symbol,s.signal).apply();}}
    void saveSignalChanges(List<Stock> stocks){android.content.SharedPreferences p=getSharedPreferences("signals",0);String raw=p.getString("history","");JSONArray a;try{a=raw.isEmpty()?new JSONArray():new JSONArray(raw);}catch(Exception e){a=new JSONArray();}for(Stock s:stocks){String old=p.getString("last_"+s.symbol,"");if(!old.isEmpty()&&!old.equals(s.signal)){try{JSONObject o=new JSONObject();o.put("symbol",s.symbol);o.put("old",old);o.put("new",s.signal);o.put("price",s.price);o.put("time",System.currentTimeMillis());a.put(o);}catch(Exception ignored){}}p.edit().putString("last_"+s.symbol,s.signal).apply();}while(a.length()>300)a.remove(0);p.edit().putString("history",a.toString()).apply();}
    String[] readSignalLogs(int max){String raw=getSharedPreferences("signals",0).getString("history","");if(raw.isEmpty())return new String[0];try{JSONArray a=new JSONArray(raw);ArrayList<String> out=new ArrayList<>();for(int i=a.length()-1;i>=0&&out.size()<max;i--){JSONObject o=a.getJSONObject(i);out.add(o.optString("symbol")+"  "+o.optString("old")+" → "+o.optString("new")+"  •  "+formatPrice(o.optDouble("price",0))+"  •  "+time(o.optLong("time",0)));}return out.toArray(new String[0]);}catch(Exception e){return new String[0];}}
    void sendSignalNotification(Stock s){if(Build.VERSION.SDK_INT>=26){android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);android.app.NotificationChannel ch=new android.app.NotificationChannel("signals","AI Sinyalleri",android.app.NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"signals"):new android.app.Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("BIST AI Trader • "+s.symbol).setContentText(s.signal+" sinyali • Skor "+String.format(Locale.US,"%.0f",s.score)).setAutoCancel(true);((android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(Math.abs(s.symbol.hashCode()),b.build());}

    void returnToList(){if(listScreen==Screen.WATCH)showWatchlist();else showMarket();}
    boolean isFavorite(String sym){return getSharedPreferences("favorites",0).getBoolean(sym,false);}
    void toggleFavorite(String sym){getSharedPreferences("favorites",0).edit().putBoolean(sym,!isFavorite(sym)).apply();}
    Stock find(String sym){for(Stock s:all)if(s.symbol.equals(sym))return s;return null;}
    void tradeNow(String sym,EditText q,boolean buy){int qty;try{qty=Integer.parseInt(q.getText().toString());}catch(Exception e){toast("Geçerli adet gir");return;}Stock s=find(sym);if(s==null||s.price<=0){toast("Güncel fiyat henüz yok");return;}boolean ok=buy?portfolio.buy(sym,s.price,qty):portfolio.sell(sym,s.price,qty);toast(ok?(buy?"Sanal alış yapıldı":"Sanal satış yapıldı"):"İşlem yapılamadı • bakiye/adet yetersiz");}

    void clear(){content.removeAllViews();search=null;listHost=null;detailNewsList=null;historyChart=null;historyInfo=null;}
    void spacer(int d){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(d)));}
    void spacerIn(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,dp(d)));}
    void spaceH(LinearLayout l,int d){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(dp(d),1));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    int parseInt(String s,int def){try{return Integer.parseInt(s);}catch(Exception e){return def;}}
    String time(long t){return new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t));}
    String formatPrice(double v){if(v<=0)return "—";return String.format(Locale.US,"%.2f ₺",v);}
}
