package com.bistaitrader;

import android.content.Context;
import androidx.work.WorkerParameters;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Persistent background deep-scan. It evaluates the market even when no paper/manual trade exists. */
public class ContinuousLearningWorker extends androidx.work.Worker {
    private final Context context;
    public ContinuousLearningWorker(Context appContext, WorkerParameters params){super(appContext,params);context=appContext.getApplicationContext();}
    @Override public Result doWork(){
        if(!context.getSharedPreferences("settings",0).getBoolean("self_learning",true))return Result.success();
        StockUniverse.loadPersisted(context);MarketGroups.load(context);
        try {
            DataService catalog=new DataService(context,(stocks,live,message)->{});
            catalog.syncCatalogBlocking();
            catalog.shutdown();
        } catch(Exception ignored) {}
        final List<String> symbols=new ArrayList<>(StockUniverse.allSymbols());
        if(symbols.isEmpty())return Result.retry();
        final String strategy=context.getSharedPreferences("settings",0).getString("strategy","Dengeli");
        final CountDownLatch latch=new CountDownLatch(1);
        final HistoryService history=new HistoryService(context);
        final int[] done={0};
        PredictionStore ps=new PredictionStore(context);ps.setMonitorStatus("Derin piyasa taraması çalışıyor • 0/"+symbols.size());
        history.scan(symbols,"1Y",strategy,new HistoryService.ScanListener(){
            public void onScanProgress(int d,int total,Stock stock){done[0]=d;if(d%10==0||d==total)ps.setMonitorStatus("Derin piyasa taraması • "+d+"/"+total+" • "+(stock==null?"":stock.symbol));}
            public void onScanFinished(int completed,int total){latch.countDown();}
        });
        try{
            boolean finished=latch.await(30,TimeUnit.MINUTES);
            history.shutdown();
            if(!finished){ps.setMonitorStatus("Tarama zaman aşımına uğradı • "+done[0]+"/"+symbols.size());return Result.retry();}
            LearningStore ls=new LearningStore(context);LearningEngine.learn(ls);ps.setLastMonitor(System.currentTimeMillis());PredictionStore.Report r=ps.report();
            ps.setMonitorStatus("Aktif • "+symbols.size()+" hisse tarandı • "+r.open+" açık tahmin • "+r.closed+" sonuç");
            return Result.success();
        }catch(InterruptedException e){Thread.currentThread().interrupt();try{history.shutdown();}catch(Exception ignored){}ps.setMonitorStatus("Tarama durduruldu");return Result.retry();}
        catch(Exception e){try{history.shutdown();}catch(Exception ignored){}ps.setMonitorStatus("Tarama hatası: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));return Result.retry();}
    }
}
