package com.bistaitrader;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DataService {
    public interface Listener { void onData(List<Stock> stocks, boolean live, String message); }

    private final Context context;
    private final Listener listener;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String,Stock> cache = new LinkedHashMap<>();
    private int tick = 0;

    public DataService(Context c, Listener l) { context=c.getApplicationContext(); listener=l; seed(); }

    public List<Stock> current() { return new ArrayList<>(cache.values()); }

    private void seed() {
        List<String> symbols = StockUniverse.allSymbols();
        for (int i=0;i<symbols.size();i++) {
            String sym=symbols.get(i);
            Stock s=new Stock(); s.symbol=sym; s.name=prettyName(sym); s.sector=guessSector(sym);
            cache.put(sym,s);
        }
    }

    public void refresh() {
        executor.execute(() -> {
            try {
                String base = context.getSharedPreferences("settings", 0).getString("base_url", "").trim();
                String token = context.getSharedPreferences("settings", 0).getString("token", "").trim();
                int count;
                if (!base.isEmpty()) {
                    count = applyJson(fetch(base, token));
                    if (count > 0) notifyData(true, "Özel veri sağlayıcı • " + count + " hisse güncellendi");
                    else notifyData(false, "Özel veri sağlayıcı JSON alanları okunamadı");
                } else {
                    count = fetchIsYatirimMarketPage();
                    if (count > 0) notifyData(true, "İŞ YATIRIM • " + count + " hisse güncellendi");
                    else notifyData(false, "İŞ YATIRIM verisi okunamadı");
                }
            } catch (Exception e) {
                notifyData(false, "Veri bağlantısı başarısız: " + safeMessage(e));
            }
        });
    }

    /**
     * İş Yatırım'ın halka açık hisse ekranındaki tabloyu okur.
     * Bu sürüm Yahoo/demo verisine geri düşmez: kaynak okunamazsa uygulama
     * sahte fiyat üretmez.
     */
    private int fetchIsYatirimMarketPage() throws Exception {
        String urlText = "https://www.isyatirim.com.tr/tr-tr/analiz/hisse/sayfalar/default.aspx";
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept","text/html,application/xhtml+xml");
        c.setRequestProperty("Accept-Language","tr-TR,tr;q=0.9");
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        int code=c.getResponseCode();
        InputStream in= code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){ BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null) sb.append(line); r.close(); }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("İş Yatırım HTTP "+code);

        String html=sb.toString();
        int updated=0;
        java.util.regex.Matcher rows=java.util.regex.Pattern.compile("<tr\\b[^>]*>(.*?)</tr>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(html);
        while(rows.find()) {
            String row=rows.group(1);
            java.util.regex.Matcher cells=java.util.regex.Pattern.compile("<td\\b[^>]*>(.*?)</td>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(row);
            ArrayList<String> v=new ArrayList<>();
            while(cells.find()) v.add(cleanHtml(cells.group(1)));
            if(v.size()<3) continue;
            String sym=normalizeSymbol(v.get(0));
            if(sym==null || !cache.containsKey(sym)) continue;
            Double price=parseTrNumber(v.get(1));
            Double pct=parseTrNumber(v.get(2));
            if(price==null || price<=0) continue;
            Stock st=cache.get(sym);
            st.price=price;
            st.changePct=pct==null?0:pct;
            st.previousClose=st.changePct>-99 ? st.price/(1.0+st.changePct/100.0) : st.price;
            if(v.size()>3){ Double vol=parseTrNumber(v.get(3)); if(vol!=null) st.volume=vol; }
            if(st.avgVolume<=0) st.avgVolume=Math.max(1,st.volume);
            AnalysisEngine.enrichLiveQuote(st);
            st.live=true; st.updatedAt=System.currentTimeMillis();
            updated++;
        }
        return updated;
    }

    private static String cleanHtml(String x){
        String y=x.replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&");
        y=y.replace("&#39;","'").replace("&quot;","\"").trim();
        return y.replaceAll("\\s+"," ");
    }
    private static String normalizeSymbol(String x){
        if(x==null) return null;
        String y=x.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");
        if(y.length()<3 || y.length()>6) return null;
        return y;
    }
    private static Double parseTrNumber(String x){
        if(x==null) return null;
        String y=x.replace("%","").replace("TL","").trim();
        y=y.replace(".","").replace(",",".");
        y=y.replaceAll("[^0-9.\\-]","");
        if(y.isEmpty() || y.equals("-") || y.equals(".")) return null;
        try{return Double.parseDouble(y);}catch(Exception e){return null;}
    }

    private String fetch(String base,String token) throws Exception {
        String sep = base.contains("?") ? "&" : "?";
        String symbols = String.join(",", StockUniverse.allSymbols());
        String urlText = base + sep + "symbols=" + java.net.URLEncoder.encode(symbols, "UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(9000); c.setRequestMethod("GET"); c.setRequestProperty("Accept","application/json");
        if(!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
        int code=c.getResponseCode();
        InputStream in= code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){ BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null) sb.append(line); r.close(); }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("HTTP "+code+" " + sb);
        return sb.toString();
    }

    private int applyJson(String body) throws Exception {
        Object root = new org.json.JSONTokener(body).nextValue();
        JSONArray arr;
        if(root instanceof JSONObject){
            JSONObject o=(JSONObject)root;
            if(o.has("symbols")) arr=o.getJSONArray("symbols");
            else if(o.has("data")) arr=o.getJSONArray("data");
            else arr=null;
        } else if(root instanceof JSONArray) arr=(JSONArray)root; else arr=null;
        if(arr==null) return 0;
        int count=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.getJSONObject(i);
            String sym = firstString(o,"symbol","ticker","code");
            if(sym==null||sym.isEmpty()) continue;
            sym=sym.toUpperCase(Locale.US);
            Stock s=cache.get(sym); if(s==null){ s=new Stock(); s.symbol=sym; s.name=prettyName(sym); s.sector="BIST"; cache.put(sym,s); }
            s.price=firstDouble(o,"price","last","close",s.price);
            s.previousClose=firstDouble(o,"previousClose","prevClose","previous_close",s.previousClose>0?s.previousClose:s.price);
            s.changePct=firstDouble(o,"changePct","changePercent","percent",safePct(s.price,s.previousClose));
            s.volume=firstDouble(o,"volume","turnover","qty",s.volume);
            s.avgVolume=firstDouble(o,"avgVolume","averageVolume","avg_volume",s.avgVolume);
            s.rsi=firstDouble(o,"rsi",s.rsi); s.macd=firstDouble(o,"macd",s.macd); s.ema20=firstDouble(o,"ema20",s.ema20); s.ema50=firstDouble(o,"ema50",s.ema50);
            s.atrPct=firstDouble(o,"atrPct","atr_percent",s.atrPct); s.score=firstDouble(o,"score","aiScore",s.score);
            s.newsScore=firstDouble(o,"newsScore","news_score",s.newsScore);
            s.signal=firstString(o,"signal","action"); if(s.signal==null) s.signal="BEKLE";
            s.risk=firstString(o,"risk","riskLevel"); if(s.risk==null) s.risk=riskFromScore(s.score,s.atrPct);
            s.support1=firstDouble(o,"support1","support",s.support1); s.support2=firstDouble(o,"support2",s.support2);
            s.resistance1=firstDouble(o,"resistance1","resistance",s.resistance1); s.resistance2=firstDouble(o,"resistance2",s.resistance2);
            s.name=firstString(o,"name","company")!=null?firstString(o,"name","company"):s.name;
            s.sector=firstString(o,"sector")!=null?firstString(o,"sector"):s.sector;
            s.updatedAt=System.currentTimeMillis(); s.live=true; count++;
        }
        return count;
    }

    private void notifyData(boolean live,String msg){ main.post(()->listener.onData(current(),live,msg)); }
    private static String safeMessage(Exception e){ return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(); }
    private static double safePct(double p,double pc){ return pc==0?0:(p/pc-1)*100; }
    private static double firstDouble(JSONObject o,String k1,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); if(k2!=null&&o.has(k2)&&!o.isNull(k2)) return o.optDouble(k2,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,String k3,double def){ double v=firstDouble(o,k1,k2,Double.NaN); return Double.isNaN(v)?firstDouble(o,k3,null,def):v; }
    private static String firstString(JSONObject o,String... ks){ for(String k:ks){ if(o.has(k)&&!o.isNull(k)){ String v=o.optString(k,""); if(!v.isEmpty()) return v; } } return null; }
    private static String riskFromScore(double s,double atr){ if(atr<2.5 && s>=45) return "Düşük Risk"; if(atr<5.0) return "Orta Risk"; return "Yüksek Risk"; }

    static String prettyName(String s){
        Map<String,String> m=new HashMap<>();
        m.put("THYAO","Türk Hava Yolları"); m.put("ASELS","Aselsan"); m.put("AKBNK","Akbank"); m.put("SAHOL","Sabancı Holding"); m.put("TUPRS","Tüpraş"); m.put("BIMAS","BİM Mağazalar");
        m.put("KCHOL","Koç Holding"); m.put("SISE","Şişecam"); m.put("EREGL","Ereğli Demir Çelik"); m.put("FROTO","Ford Otosan"); m.put("GARAN","Garanti BBVA"); m.put("YKBNK","Yapı Kredi");
        m.put("ISCTR","İş Bankası C"); m.put("TCELL","Turkcell"); m.put("PGSUS","Pegasus"); m.put("TOASO","Tofaş"); m.put("EKGYO","Emlak Konut"); m.put("TAVHL","TAV Havalimanları");
        return m.containsKey(s)?m.get(s):s;
    }
    static String guessSector(String s){
        if(Arrays.asList("AKBNK","GARAN","YKBNK","ISCTR","HALKB","VAKBN","TSKB","SKBNK","ALBRK").contains(s)) return "Bankacılık";
        if(Arrays.asList("THYAO","PGSUS","TAVHL").contains(s)) return "Ulaştırma";
        if(Arrays.asList("ASELS","ALTNY","SDTTR","PAPIL","FORTE").contains(s)) return "Savunma/Teknoloji";
        if(Arrays.asList("TUPRS","PETKM","AKSA","SASA","KMPUR").contains(s)) return "Kimya/Enerji";
        if(Arrays.asList("BIMAS","MGROS","SOKM","MAVI","ULKER").contains(s)) return "Perakende";
        if(s.endsWith("GYO")||s.contains("GYO")) return "GYO";
        return "BIST Hisse";
    }
}
