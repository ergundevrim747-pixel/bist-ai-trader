package com.bistaitrader;

import android.content.Context;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class NewsService {
    public interface Listener{void onNews(List<NewsItem> items, String status);}
    private final Context c; private final Listener listener; private final ExecutorService ex=Executors.newSingleThreadExecutor(); private final Handler main=new Handler(Looper.getMainLooper());
    public NewsService(Context c,Listener l){this.c=c.getApplicationContext();listener=l;}
    public void refresh(String symbol){ ex.execute(()->{ String base=c.getSharedPreferences("settings",0).getString("news_url","").trim();
        if(base.isEmpty()){ main.post(()->listener.onNews(Collections.emptyList(),"Haber/KAP kaynağı Ayarlar’dan eklenmedi.")); return; }
        try{String body=fetch(base,symbol); List<NewsItem> n=parse(body,symbol); main.post(()->listener.onNews(n,"Haber akışı güncellendi"));}
        catch(Exception e){main.post(()->listener.onNews(Collections.emptyList(),"Haber bağlantısı alınamadı"));}
    }); }
    private String fetch(String base,String symbol)throws Exception{String sep=base.contains("?")?"&":"?";URL u=new URL(base+sep+"symbol="+URLEncoder.encode(symbol,"UTF-8"));HttpURLConnection x=(HttpURLConnection)u.openConnection();x.setConnectTimeout(7000);x.setReadTimeout(9000);x.setRequestProperty("Accept","application/json");int code=x.getResponseCode();InputStream in=code>=200&&code<300?x.getInputStream():x.getErrorStream();StringBuilder b=new StringBuilder();if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null)b.append(line);r.close();}x.disconnect();if(code<200||code>=300)throw new Exception("HTTP "+code);return b.toString();}
    private List<NewsItem> parse(String body,String symbol)throws Exception{Object v=new JSONTokener(body).nextValue();JSONArray a=v instanceof JSONObject?((JSONObject)v).optJSONArray("items"):(JSONArray)v;List<NewsItem> out=new ArrayList<>();if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);NewsItem n=new NewsItem();n.symbol=o.optString("symbol",symbol);n.title=o.optString("title","Başlık yok");n.source=o.optString("source","Kaynak");n.time=o.optString("publishedAt",o.optString("time",""));n.sentiment=o.optDouble("sentiment",0);out.add(n);}return out;}
    private List<NewsItem> demo(String s){List<NewsItem> n=new ArrayList<>();String[] t={"Piyasa verisi bağlantısı için sağlayıcı bekleniyor","Teknik görünüm izleniyor","KAP ve haber akışı gerçek veri modunda burada gösterilecek"};for(int i=0;i<t.length;i++){NewsItem x=new NewsItem();x.symbol=s;x.title=t[i];x.source=i==0?"BIST AI Trader":"Demo";x.time="—";n.add(x);}return n;}
}
