# BIST AI Trader — Android Studio Projesi

Bu proje gerçek bir Android uygulamasıdır ve Android Studio ile APK olarak derlenebilir.

## APK oluşturma
1. Android Studio'yu kurun.
2. Bu ZIP'i çıkarın.
3. Android Studio > Open ile `BIST_AI_Trader_Android_Studio` klasörünü açın.
4. Gradle senkronizasyonunun tamamlanmasını bekleyin.
5. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
6. Oluşan APK'yı Android telefona aktarın ve kurun.

## Mevcut MVP
- Android uygulaması
- BIST örnek hisseleri
- AL/SAT/BEKLE sinyali
- RSI/trend/skor görünümü
- Sanal portföy
- Sanal AL/SAT
- Gerçek para/emir bağlantısı yok

Canlı BIST verisi ve haber/KAP API'leri bir sonraki aşamada eklenmelidir.
