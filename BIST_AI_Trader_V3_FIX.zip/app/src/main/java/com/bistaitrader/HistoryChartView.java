package com.bistaitrader;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryChartView extends View {
    public enum Mode { LINE, CANDLE }
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint up = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint down = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Candle> candles = new ArrayList<>();
    private Mode mode = Mode.CANDLE;
    private int selected = -1;
    private float left, right, top, bottom, plotBottom;
    private String selectedLabel = "";

    public HistoryChartView(Context c) {
        super(c);
        setBackgroundColor(0xff0b1524);
        grid.setColor(0xff243a55); grid.setStrokeWidth(1f);
        axis.setColor(0xff7186a1); axis.setStrokeWidth(1f);
        line.setColor(0xff5e9bff); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(4f); line.setStrokeCap(Paint.Cap.ROUND); line.setStrokeJoin(Paint.Join.ROUND);
        up.setColor(0xff31d17a); down.setColor(0xffff5b65);
        text.setColor(0xffb9c6d6); text.setTextSize(28f);
        cross.setColor(0xff6d829e); cross.setStrokeWidth(1.5f); cross.setPathEffect(new android.graphics.DashPathEffect(new float[]{7,7},0));
        setFocusable(true);
    }

    public void setCandles(List<Candle> items) { candles = items == null ? new ArrayList<>() : new ArrayList<>(items); selected = -1; invalidate(); }
    public void setMode(Mode m) { mode = m == null ? Mode.CANDLE : m; invalidate(); }
    public int getSelectedIndex() { return selected; }
    public String getSelectedLabel() { return selectedLabel; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        left = 24; right = getWidth()-24; top = 24; bottom = getHeight()-40; plotBottom = bottom-62;
        if (candles.isEmpty()) { text.setTextSize(34); c.drawText("Geçmiş veri bekleniyor…", left+10, getHeight()/2f, text); return; }
        double min=Double.MAX_VALUE, max=-Double.MAX_VALUE;
        int start=0;
        for(int i=start;i<candles.size();i++){Candle k=candles.get(i);min=Math.min(min,k.low);max=Math.max(max,k.high);}
        if(max<=min){max=min+1;}
        double pad=(max-min)*0.08; min=Math.max(0,min-pad); max=max+pad;
        for(int i=0;i<=5;i++){
            float y=top+(plotBottom-top)*(i/5f); c.drawLine(left,y,right,y,grid);
            double p=max-(max-min)*(i/5.0); text.setTextSize(24); c.drawText(String.format(Locale.US,"%.2f",p),right-120,y-5,text);
        }
        c.drawLine(left,plotBottom,right,plotBottom,axis);
        int n=candles.size()-start;
        if(mode==Mode.LINE) drawLine(c,start,n,min,max);
        else drawCandles(c,start,n,min,max);
        drawVolume(c,start,n);
        text.setTextSize(22);
        c.drawText(candles.get(start).date, left, bottom+27, text);
        String lastDate=candles.get(candles.size()-1).date;
        c.drawText(lastDate, Math.max(left, right-text.measureText(lastDate)), bottom+27, text);
        if(selected>=start && selected<candles.size()) drawCrosshair(c,start,n,min,max);
    }

    private float xFor(int local,int n){return left+(right-left)*(n<=1?0.5f:local/(float)(n-1));}
    private float yFor(double p,double min,double max){return plotBottom-(float)((p-min)/(max-min))*(plotBottom-top);}
    private void drawLine(Canvas c,int start,int n,double min,double max){Path p=new Path();for(int i=0;i<n;i++){Candle k=candles.get(start+i);float x=xFor(i,n),y=yFor(k.close,min,max);if(i==0)p.moveTo(x,y);else p.lineTo(x,y);}c.drawPath(p,line);}
    private void drawCandles(Canvas c,int start,int n,double min,double max){float bodyW=Math.max(4,(right-left)/Math.max(20,n)*0.58f);for(int i=0;i<n;i++){Candle k=candles.get(start+i);float x=xFor(i,n);float yo=yFor(k.open,min,max),yc=yFor(k.close,min,max),yh=yFor(k.high,min,max),yl=yFor(k.low,min,max);boolean green=k.close>=k.open;Paint pp=green?up:down;c.drawLine(x,yh,x,yl,pp);float topY=Math.min(yo,yc),botY=Math.max(yo,yc);if(Math.abs(botY-topY)<2)botY=topY+2;c.drawRect(new RectF(x-bodyW,topY,x+bodyW,botY),pp);}}
    private void drawVolume(Canvas c,int start,int n){double mv=1;for(int i=start;i<candles.size();i++)mv=Math.max(mv,candles.get(i).volume);float vh=48;for(int i=0;i<n;i++){Candle k=candles.get(start+i);float x=xFor(i,n);float h=(float)(k.volume/mv)*vh;Paint pp=k.close>=k.open?up:down; c.drawRect(x-2,plotBottom+60-h,x+2,plotBottom+60,pp);}}
    private void drawCrosshair(Canvas c,int start,int n,double min,double max){int li=selected-start;if(li<0||li>=n)return;Candle k=candles.get(selected);float x=xFor(li,n),y=yFor(k.close,min,max);c.drawLine(x,top,x,bottom,cross);c.drawLine(left,y,right,y,cross);selectedLabel=k.date+"   Kapanış "+String.format(Locale.US,"%.2f",k.close);text.setTextSize(25);float tw=text.measureText(selectedLabel);float bx=Math.max(left,Math.min(right-tw-16,x-tw/2));c.drawRect(bx-8,top+4,bx+tw+8,top+38,0xff14263c);text.setColor(0xffecf2f8);c.drawText(selectedLabel,bx,top+30,text);text.setColor(0xffb9c6d6);}
    @Override public boolean onTouchEvent(MotionEvent e){if(candles.isEmpty())return true;float x=e.getX();if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){int start=0,n=candles.size()-start;if(x<left)x=left;if(x>right)x=right;int li=Math.round((x-left)/(right-left)*Math.max(1,n-1));selected=start+Math.min(n-1,Math.max(0,li));invalidate();return true;}return true;}
}
