package com.bistaitrader;

import java.util.*;

/**
 * Multi-horizon analysis used only on the stock detail screen.
 *
 * It reuses the core technical engine, then overlays the current live quote
 * so a stale daily close cannot make the detail page ignore the live price.
 * Target values are technical model bands, not analyst consensus forecasts.
 */
public final class HorizonAnalysis {
    public static final String LONG = "Uzun Vade Yatırım";
    public static final String MEDIUM = "Orta Vade";
    public static final String SHORT = "Kısa Vade";

    public static final class Result {
        public String horizon = "";
        public String signal = "BEKLE";
        public String strength = "Nötr";
        public String risk = "Orta Risk";
        public String trend = "Belirsiz";
        public String stage = "Belirsiz";
        public String reason = "Analiz bekleniyor.";
        public String liveNote = "";
        public String source = "";
        public String periodLabel = "";
        public double score;
        public double confidence;
        public int conditionsMet;
        public int conditionsTotal;
        public double historicalLast;
        public double livePrice;
        public double liveReactionPct;
        public double periodReturnPct;
        public double modelLow;
        public double modelBase;
        public double modelHigh;
        public double upsidePct;
        public double downsidePct;
        public double upsideHighPct;
        public double liveScoreAdjustment;
        public boolean liveEntryConfirmed;
        public double support;
        public double resistance;
        public double stop;
        public double target1;
        public double target2;
        public double entryLow, entryHigh;
        public double atrPct;
        public boolean ready;
    }

    private HorizonAnalysis() {}

    public static String strategyFor(String horizon) {
        if (LONG.equals(horizon)) return "Trend";
        if (MEDIUM.equals(horizon)) return "Dengeli";
        return "Kısa Vadeli";
    }

    public static Result analyze(Stock liveStock, List<Candle> bars, List<Candle> benchmark, String horizon) {
        Result r = new Result();
        r.horizon = horizon == null ? MEDIUM : horizon;
        r.periodLabel = periodLabel(r.horizon);
        if (bars == null || bars.size() < minimumBars(r.horizon)) {
            r.reason = "Bu vade için yeterli geçmiş günlük veri yok.";
            return r;
        }

        Stock work = liveStock == null ? new Stock() : liveStock.copy();
        double live = liveStock != null && liveStock.price > 0 ? liveStock.price : 0;
        AnalysisEngine.enrichFromHistory(work, bars, strategyFor(r.horizon), benchmark);

        List<Candle> clean = clean(bars);
        if (clean.isEmpty()) return r;
        Candle last = clean.get(clean.size() - 1);
        r.historicalLast = last.close;
        r.livePrice = live > 0 ? live : last.close;
        r.liveReactionPct = r.historicalLast > 0 ? (r.livePrice / r.historicalLast - 1.0) * 100.0 : 0;
        r.periodReturnPct = periodReturn(clean, lookbackFor(r.horizon));

        r.signal = work.analysisReady ? work.signal : "BEKLE";
        r.score = work.score;
        r.confidence = work.confidence;
        r.conditionsMet = work.conditionsMet;
        r.conditionsTotal = work.conditionsTotal;
        r.risk = work.risk;
        r.trend = work.trend;
        r.stage = work.stage;
        r.stop = work.stopPrice;
        r.entryLow = work.entryLow;
        r.entryHigh = work.entryHigh;
        r.target1 = work.targetPrice;
        r.target2 = work.targetPrice2;
        r.atrPct = work.atrPct;
        r.support = chooseSupport(work, clean);
        r.resistance = chooseResistance(work, clean, r.horizon);

        calculateModelBand(r, clean, work);
        applyLiveReaction(r, work);
        r.strength = strength(r.score, r.signal);
        r.reason = buildReason(r, work);
        r.ready = work.analysisReady && clean.size() >= minimumBars(r.horizon);
        return r;
    }

    private static int minimumBars(String h) {
        if (LONG.equals(h)) return 200;
        if (MEDIUM.equals(h)) return 120;
        return 90;
    }

    private static int lookbackFor(String h) {
        if (LONG.equals(h)) return 252;
        if (MEDIUM.equals(h)) return 22;
        return 10;
    }

    private static int targetWindow(String h) {
        if (LONG.equals(h)) return 252;
        if (MEDIUM.equals(h)) return 63;
        return 20;
    }

    private static String periodLabel(String h) {
        if (LONG.equals(h)) return "12 ay / yıllık görünüm";
        if (MEDIUM.equals(h)) return "1 ay / orta vade görünüm";
        return "5-20 işlem günü / kısa vade görünüm";
    }

    private static double periodReturn(List<Candle> bars, int n) {
        if (bars.size() <= n) return 0;
        double a = bars.get(bars.size() - 1 - n).close;
        double b = bars.get(bars.size() - 1).close;
        return a > 0 ? (b / a - 1.0) * 100.0 : 0;
    }

    private static double highest(List<Candle> bars, int n) {
        int from = Math.max(0, bars.size() - n);
        double x = 0;
        for (int i = from; i < bars.size(); i++) x = Math.max(x, bars.get(i).high);
        return x;
    }

    private static double lowest(List<Candle> bars, int n) {
        int from = Math.max(0, bars.size() - n);
        double x = Double.MAX_VALUE;
        for (int i = from; i < bars.size(); i++) x = Math.min(x, bars.get(i).low);
        return x == Double.MAX_VALUE ? 0 : x;
    }

    private static double trendProjection(List<Candle> bars, int lookback, int projectionDays) {
        int n = Math.min(lookback, bars.size());
        if (n < 20) return bars.get(bars.size()-1).close;
        int start = bars.size() - n;
        double sx=0, sy=0, sxx=0, sxy=0;
        for (int i=0;i<n;i++) {
            double x=i;
            double y=Math.log(Math.max(0.01,bars.get(start+i).close));
            sx+=x; sy+=y; sxx+=x*x; sxy+=x*y;
        }
        double den=n*sxx-sx*sx;
        double slope=den==0?0:(n*sxy-sx*sy)/den;
        double future=Math.log(Math.max(0.01,bars.get(bars.size()-1).close))+slope*projectionDays;
        double projected=Math.exp(future);
        double last=bars.get(bars.size()-1).close;
        return Math.max(last*0.50, Math.min(last*2.0, projected));
    }

    private static void calculateModelBand(Result r, List<Candle> bars, Stock work) {
        int window=targetWindow(r.horizon);
        double last=r.livePrice>0?r.livePrice:r.historicalLast;
        double recentHigh=highest(bars,Math.min(window,bars.size()));
        double recentLow=lowest(bars,Math.min(window,bars.size()));
        double projected=trendProjection(bars,Math.min(window,bars.size()),projectionFor(r.horizon));
        double base=last;

        if (work != null && work.targetPrice > last) base=Math.max(base,work.targetPrice);
        if (recentHigh > last) base=Math.max(base,recentHigh*0.985);
        base=0.55*base+0.45*projected;

        double atrBuffer=last>0?last*(Math.max(1.0,r.atrPct)/100.0)*targetAtrMultiplier(r.horizon):0;
        double low=base>last ? last+(base-last)*0.55 : Math.min(last,recentHigh);
        double high=base>last ? base+Math.max(atrBuffer,(base-last)*0.45) : last+Math.max(0,atrBuffer*0.5);

        // Prevent absurd technical projections from becoming fake-looking targets.
        double cap=last*(LONG.equals(r.horizon)?1.55:MEDIUM.equals(r.horizon)?1.35:1.18);
        if (high>cap) high=cap;
        if (base>high) base=high;
        if (low>base) low=base;
        if (low<=0) low=last;

        r.modelLow=low;
        r.modelBase=base;
        r.modelHigh=high;
        r.upsidePct=last>0?(base/last-1)*100:0;
        r.upsideHighPct=last>0?(high/last-1)*100:0;
        r.downsidePct=last>0?(low/last-1)*100:0;
        if (r.support<=0) r.support=recentLow;
        if (r.resistance<=0) r.resistance=recentHigh;
    }

    private static int projectionFor(String h) {
        if (LONG.equals(h)) return 252;
        if (MEDIUM.equals(h)) return 45;
        return 10;
    }

    private static double targetAtrMultiplier(String h) {
        if (LONG.equals(h)) return 1.6;
        if (MEDIUM.equals(h)) return 1.25;
        return 0.85;
    }

    private static double chooseSupport(Stock s, List<Candle> bars) {
        if (s != null && s.support1 > 0) return s.support1;
        return lowest(bars,20);
    }

    private static double chooseResistance(Stock s, List<Candle> bars, String h) {
        if (s != null && s.resistance1 > 0) return s.resistance1;
        return highest(bars,targetWindow(h));
    }

    private static void applyLiveReaction(Result r, Stock work) {
        if (work == null || !work.analysisReady || r.livePrice <= 0 || r.historicalLast <= 0) return;
        double atrMoney = r.livePrice * Math.max(0.5, r.atrPct) / 100.0;
        double reaction = r.liveReactionPct;
        double adj = 0;

        boolean belowStop = work.stopPrice > 0 && r.livePrice <= work.stopPrice;
        boolean inEntry = work.entryLow > 0 && work.entryHigh > 0
                && r.livePrice >= work.entryLow - atrMoney * 0.25
                && r.livePrice <= work.entryHigh + atrMoney * 0.25;
        boolean chasing = work.entryHigh > 0 && r.livePrice > work.entryHigh + atrMoney * 0.65;
        boolean belowSupport = work.support1 > 0 && r.livePrice < work.support1 - atrMoney * 0.35;
        boolean passedTarget = work.targetPrice > 0 && r.livePrice >= work.targetPrice * 1.01;

        if (inEntry && !chasing) { adj += 7; r.liveEntryConfirmed = true; }
        if (reaction >= 0.35 && reaction <= 2.50) adj += 5;
        else if (reaction > 2.50 && reaction <= 5.0) adj += 2;
        else if (reaction < -0.75 && reaction >= -3.0) adj -= 4;
        else if (reaction < -3.0) adj -= 8;
        if (chasing) adj -= 10;
        if (belowSupport) adj -= 8;
        if (belowStop) adj -= 18;
        if (passedTarget) adj -= 7;
        if (work.overextended) adj -= 7;
        r.liveScoreAdjustment = adj;
        r.score = Math.max(0, Math.min(100, r.score + adj));
        r.confidence = Math.max(0, Math.min(100, r.confidence + adj));

        if (belowStop) {
            r.signal = "SAT";
            r.liveNote = "Canlı fiyat teknik stopun altında; tarihsel analiz canlı fiyat filtresinde çıkışa döndü.";
            return;
        }
        if (passedTarget || chasing) {
            r.signal = "BEKLE";
            r.liveNote = passedTarget
                    ? "Canlı fiyat hedef bölgesine ulaştı; yeni alımda fiyat kovalanmıyor."
                    : "Canlı fiyat hesaplanan giriş bölgesinin belirgin üzerinde; geç alım engellendi.";
            return;
        }

        // A historical BEKLE can become AL only when the live quote moves into a
        // valid entry zone and the underlying model is already close to actionable.
        // The live quote does not invent a signal from scratch.
        if ("BEKLE".equals(work.signal) && work.conditionsMet >= 3
                && work.signalBalance >= 58 && r.score >= 55 && r.liveEntryConfirmed
                && work.hardGateOk && work.volatilityOk && !work.distributionFlag
                && !work.overextended && work.marketOk) {
            r.signal = "AL";
            r.liveNote = "Geçmiş teknik kurulum sınıra yakın; canlı fiyat giriş bölgesine geldiği için AL teyidi güçlendi.";
            return;
        }
        if ("AL".equals(work.signal) && r.liveEntryConfirmed) {
            r.signal = "AL";
            r.liveNote = "Tarihsel AL ve canlı fiyat giriş bölgesi uyumlu.";
        } else if (belowSupport && "SAT".equals(work.signal)) {
            r.signal = "SAT";
            r.liveNote = "Canlı fiyat destek altında ve tarihsel SAT teyidi korunuyor.";
        } else if (r.liveScoreAdjustment < -5) {
            r.signal = "BEKLE";
            r.liveNote = "Canlı fiyat tarihsel kurulumu zayıflatıyor; yeni giriş için teyit bekleniyor.";
        }
    }

    private static String strength(double score, String signal) {
        if ("AL".equals(signal) && score >= 85) return "Güçlü AL";
        if ("AL".equals(signal)) return "AL teyidi";
        if ("SAT".equals(signal) && score <= 25) return "Güçlü SAT";
        if ("SAT".equals(signal)) return "SAT teyidi";
        return "Nötr / BEKLE";
    }

    private static String buildReason(Result r, Stock w) {
        StringBuilder b=new StringBuilder();
        b.append(r.conditionsMet).append('/').append(r.conditionsTotal).append(" koşul");
        if (r.livePrice>0 && r.historicalLast>0)
            b.append(" • canlı tepki ").append(String.format(Locale.US,"%+.2f%%",r.liveReactionPct));
        b.append(" • dönem getirisi ").append(String.format(Locale.US,"%+.2f%%",r.periodReturnPct));
        b.append(" • trend ").append(r.trend);
        if (!r.liveNote.isEmpty()) b.append(" • ").append(r.liveNote);
        if (w!=null && w.reason!=null && !w.reason.isEmpty()) b.append(" • ").append(w.reason);
        if ("AL".equals(r.signal) && r.upsidePct>0)
            b.append(" • model taban hedef bölgesi ").append(String.format(Locale.US,"%+.1f%%",r.upsidePct));
        return b.toString();
    }

    private static ArrayList<Candle> clean(List<Candle> src) {
        ArrayList<Candle> out=new ArrayList<>();
        if(src==null)return out;
        long prev=Long.MIN_VALUE;
        for(Candle c:src){
            if(c==null||c.close<=0||c.low<=0||c.high<=0||c.open<=0||c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close))continue;
            if(c.time<=prev)continue;
            out.add(c);prev=c.time;
        }
        return out;
    }

    private static List<Candle> sliceDays(List<Candle> bars, long days) {
        if (bars == null || bars.isEmpty()) return Collections.emptyList();
        long cutoff=bars.get(bars.size()-1).time-days*86400000L;
        ArrayList<Candle> out=new ArrayList<>();
        for(Candle c:bars) if(c.time>=cutoff) out.add(c);
        return out;
    }
}
