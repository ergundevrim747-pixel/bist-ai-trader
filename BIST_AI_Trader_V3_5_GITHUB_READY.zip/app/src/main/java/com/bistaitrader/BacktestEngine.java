package com.bistaitrader;

import java.util.*;

/**
 * Conservative daily-bar backtest using the same signal/plan engine as the UI.
 * Benchmark data is aligned by timestamp inside AnalysisEngine, so future
 * benchmark information is not exposed to historical decisions. If stop and
 * target are both touched in one candle, stop is assumed to occur first.
 */
public final class BacktestEngine {
    private BacktestEngine() {}

    public static final class Result {
        public int trades, wins, losses;
        public int target1Hits, target2Hits, stopHits, signalExits, skippedPlans;
        public int maxConsecutiveLosses;
        public double startCash, endCash, returnPct, maxDrawdownPct, winRate;
        public double grossProfit, grossLoss, profitFactor, avgWinPct, avgLossPct, expectancyPct;
        public final ArrayList<String> log = new ArrayList<>();
    }

    private static final class TradeState {
        double entry;
        double stop;
        double target1;
        double target2;
        double realizedPct;
        int remaining;
        int initialShares;
        boolean t1Done;
        boolean active;
    }

    public static Result run(List<Candle> source, String strategy) { return run(source, strategy, null); }

    public static Result run(List<Candle> source, String strategy, List<Candle> benchmark) {
        ArrayList<Candle> bars = new ArrayList<>();
        if (source != null) for (Candle c : source) if (c != null) bars.add(c);
        bars.sort((a,b)->Long.compare(a.time,b.time));
        Result r = new Result();
        r.startCash = 100000.0;
        if (bars.size() < AnalysisEngine.MIN_DEEP_BARS + 2 || !AnalysisEngine.hasFullOhlcv(bars)) {
            r.endCash = r.startCash;
            return r;
        }

        final double fee = 0.002;
        final double slippage = 0.0005; // 5 bps per side: conservative fill-cost assumption.
        final double riskFraction = 0.005;
        double cash = r.startCash;
        double peak = cash;
        double winsSum = 0, lossesSum = 0;
        int consecutiveLosses = 0;
        TradeState t = new TradeState();

        for (int i = AnalysisEngine.MIN_DEEP_BARS - 1; i < bars.size() - 1; i++) {
            AnalysisEngine.Decision d = AnalysisEngine.evaluateAt(bars, i, strategy, benchmark);
            Candle bar = bars.get(i + 1);
            boolean enteredThisBar = false;

            if (!t.active) {
                if ("AL".equals(d.signal) && d.hardGateOk && d.entryZoneOk && d.entryLow > 0 && d.entryHigh > d.entryLow) {
                    boolean gapChase = bar.open > d.entryHigh * 1.03 || bar.open < d.entryLow * 0.95;
                    if (gapChase) {
                        r.skippedPlans++;
                    } else {
                        double px = bar.open;
                        if (px < d.entryLow) px = d.entryLow;
                        if (px > d.entryHigh * 1.03) {
                            r.skippedPlans++;
                        } else {
                            int qtyRisk = (int)Math.floor((r.startCash * riskFraction) / Math.max(0.01, d.riskPerShare));
                            int qtyCash = (int)Math.floor(cash / (px * (1 + fee)));
                            int qty = Math.min(qtyRisk, qtyCash);
                            if (d.suggestedQty > 0) qty = Math.min(qty, d.suggestedQty);
                            if (qty > 0) {
                                double fillPx = px * (1 + slippage);
                                cash -= fillPx * qty * (1 + fee);
                                t.entry = fillPx;
                                t.stop = d.stop;
                                t.target1 = d.target1;
                                t.target2 = d.target2;
                                t.remaining = qty;
                                t.initialShares = qty;
                                t.realizedPct = 0;
                                t.t1Done = false;
                                t.active = true;
                                enteredThisBar = true;
                                r.trades++;
                                r.log.add(bar.date + " • AL " + qty + " @ " + fmt(px) + " • " + d.setupType);
                                // Entry candle is also managed; older versions accidentally skipped it.
                            } else {
                                r.skippedPlans++;
                            }
                        }
                    }
                }
            }

            // Manage the entry candle exactly once.
            if (enteredThisBar && t.active) {
                Event ev = evaluateBar(t, bar);
                if (ev.type == 1) {
                    double p = pct(t.entry, ev.price);
                    t.realizedPct = weightedClose(t.realizedPct, p, t.remaining, t.remaining);
                    cash += ev.price * (1 - slippage) * t.remaining * (1 - fee);
                    r.stopHits++;
                    TradeClose tc = finishTrade(r, t); winsSum += tc.win ? tc.pnlPct : 0; lossesSum += tc.win ? 0 : -tc.pnlPct;
                    if (tc.win) consecutiveLosses = 0; else { consecutiveLosses++; r.maxConsecutiveLosses=Math.max(r.maxConsecutiveLosses,consecutiveLosses); }
                    r.log.add(bar.date + " • STOP entry candle " + fmt(ev.price) + " • " + fmtPct(tc.pnlPct));
                    t.active=false;
                } else if (ev.type == 2) {
                    int before=t.remaining, q1=Math.max(1,before/2); int after=before-q1;
                    cash += t.target1*(1-slippage)*q1*(1-fee);
                    t.realizedPct += pct(t.entry,t.target1)*(q1/(double)Math.max(1,before));
                    t.remaining=after;t.t1Done=true;t.stop=Math.max(t.stop,t.entry*1.0015);r.target1Hits++;
                    r.log.add(bar.date+" • HEDEF1 %50 @ "+fmt(t.target1)+" • "+fmtPct(pct(t.entry,t.target1)));
                }
            }

            if (t.active && !enteredThisBar) {
                if (bar.open <= t.stop) {
                    double p=pct(t.entry,bar.open);t.realizedPct += p*(t.remaining/(double)Math.max(1,t.initialShares));cash += bar.open*(1-slippage)*t.remaining*(1-fee);r.stopHits++;
                    TradeClose tc=finishTrade(r,t);winsSum += tc.win?tc.pnlPct:0;lossesSum += tc.win?0:-tc.pnlPct;
                    if(tc.win)consecutiveLosses=0;else{consecutiveLosses++;r.maxConsecutiveLosses=Math.max(r.maxConsecutiveLosses,consecutiveLosses);}
                    r.log.add(bar.date+" • STOP GAP "+fmt(bar.open)+" • "+fmtPct(tc.pnlPct));t.active=false;
                } else if (bar.low <= t.stop) {
                    double p=pct(t.entry,t.stop);t.realizedPct += p*(t.remaining/(double)Math.max(1,t.initialShares));cash += t.stop*(1-slippage)*t.remaining*(1-fee);r.stopHits++;
                    TradeClose tc=finishTrade(r,t);winsSum += tc.win?tc.pnlPct:0;lossesSum += tc.win?0:-tc.pnlPct;
                    if(tc.win)consecutiveLosses=0;else{consecutiveLosses++;r.maxConsecutiveLosses=Math.max(r.maxConsecutiveLosses,consecutiveLosses);}
                    r.log.add(bar.date+" • STOP "+fmt(t.stop)+" • "+fmtPct(tc.pnlPct));t.active=false;
                } else if (!t.t1Done && bar.high >= t.target1) {
                    int before=t.remaining,q1=Math.max(1,before/2),after=before-q1;
                    cash += t.target1*(1-slippage)*q1*(1-fee);
                    t.realizedPct += pct(t.entry,t.target1)*(q1/(double)Math.max(1,before));
                    t.remaining=after;t.t1Done=true;t.stop=Math.max(t.stop,t.entry*1.0015);r.target1Hits++;
                    r.log.add(bar.date+" • HEDEF1 %50 @ "+fmt(t.target1)+" • "+fmtPct(pct(t.entry,t.target1)));
                } else if (t.t1Done && bar.high >= t.target2) {
                    double p=pct(t.entry,t.target2);t.realizedPct += p*(t.remaining/(double)Math.max(1,t.initialShares));cash += t.target2*(1-slippage)*t.remaining*(1-fee);r.target2Hits++;
                    TradeClose tc=finishTrade(r,t);winsSum += tc.win?tc.pnlPct:0;lossesSum += tc.win?0:-tc.pnlPct;
                    if(tc.win)consecutiveLosses=0;else{consecutiveLosses++;r.maxConsecutiveLosses=Math.max(r.maxConsecutiveLosses,consecutiveLosses);}
                    r.log.add(bar.date+" • HEDEF2 kalan @ "+fmt(t.target2)+" • "+fmtPct(tc.pnlPct));t.active=false;
                } else if ("SAT".equals(d.signal)) {
                    double px=bar.open>0?bar.open:bar.close;double p=pct(t.entry,px);t.realizedPct += p*(t.remaining/(double)Math.max(1,t.initialShares));cash += px*(1-slippage)*t.remaining*(1-fee);r.signalExits++;
                    TradeClose tc=finishTrade(r,t);winsSum += tc.win?tc.pnlPct:0;lossesSum += tc.win?0:-tc.pnlPct;
                    if(tc.win)consecutiveLosses=0;else{consecutiveLosses++;r.maxConsecutiveLosses=Math.max(r.maxConsecutiveLosses,consecutiveLosses);}
                    r.log.add(bar.date+" • SAT çıkış "+fmt(px)+" • "+fmtPct(tc.pnlPct));t.active=false;
                } else {
                    double trail=d.trailingStop;
                    if(trail>t.stop && trail<bar.close)t.stop=trail;
                }
            }

            double mark=cash+(t.active?t.remaining*bar.close:0);
            peak=Math.max(peak,mark);
            if(peak>0)r.maxDrawdownPct=Math.max(r.maxDrawdownPct,(peak-mark)/peak*100);
        }

        if(t.active && t.remaining>0){
            Candle last=bars.get(bars.size()-1);double px=last.close;double p=pct(t.entry,px);t.realizedPct += p*(t.remaining/(double)Math.max(1,t.initialShares));cash += px*(1-slippage)*t.remaining*(1-fee);TradeClose tc=finishTrade(r,t);winsSum += tc.win?tc.pnlPct:0;lossesSum += tc.win?0:-tc.pnlPct;r.log.add(last.date+" • Dönem sonu çıkış "+fmt(px)+" • "+fmtPct(tc.pnlPct));t.active=false;
        }

        r.endCash=cash;
        r.returnPct=(cash/r.startCash-1)*100;
        r.winRate=r.trades==0?0:r.wins*100.0/r.trades;
        r.avgWinPct=r.wins==0?0:winsSum/r.wins;
        r.avgLossPct=r.losses==0?0:lossesSum/r.losses;
        r.grossProfit=winsSum;r.grossLoss=lossesSum;
        r.profitFactor=lossesSum>0?winsSum/lossesSum:(winsSum>0?Double.POSITIVE_INFINITY:0);
        int closed=r.wins+r.losses;
        r.expectancyPct=closed==0?0:(winsSum-lossesSum)/closed;
        return r;
    }

    private static final class Event {int type;double price;Event(int t,double p){type=t;price=p;}}
    private static Event evaluateBar(TradeState t,Candle b){
        if(b.open<=t.stop)return new Event(1,b.open);
        if(b.low<=t.stop)return new Event(1,t.stop);
        if(!t.t1Done&&b.high>=t.target1)return new Event(2,t.target1);
        return new Event(0,0);
    }
    private static final class TradeClose {boolean win;double pnlPct;}
    private static TradeClose finishTrade(Result r,TradeState t){
        TradeClose c=new TradeClose();c.pnlPct=t.realizedPct;c.win=c.pnlPct>=0;if(c.win)r.wins++;else r.losses++;t.remaining=0;t.initialShares=0;t.t1Done=false;t.realizedPct=0;return c;
    }
    private static double weightedClose(double current,double p,int qty,int total){return current + p*(qty/(double)Math.max(1,total));}
    private static double pct(double a,double b){return a>0?(b/a-1)*100:0;}
    private static String fmt(double x){return String.format(Locale.US,"%.2f",x);}
    private static String fmtPct(double x){return String.format(Locale.US,"%+.2f%%",x);}
}
