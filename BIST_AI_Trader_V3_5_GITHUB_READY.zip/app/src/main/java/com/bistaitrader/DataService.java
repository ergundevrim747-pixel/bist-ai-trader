package com.bistaitrader;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;

public class DataService {
    public interface Listener { void onData(List<Stock> stocks, boolean live, String message); }

    private final Context context;
    private final Listener listener;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String,Stock> cache = new LinkedHashMap<>();
    private int tick = 0;
    private final AtomicBoolean refreshRunning = new AtomicBoolean(false);
    private final AtomicBoolean maintenanceRunning = new AtomicBoolean(false);
    private final ExecutorService maintenanceExecutor = Executors.newSingleThreadExecutor();
    private final PredictionStore predictions;
    private static final long MAINTENANCE_INTERVAL_MS = 15 * 60 * 1000L;

    public DataService(Context c, Listener l) {
        context=c.getApplicationContext(); listener=l; predictions=new PredictionStore(context);
        StockUniverse.loadPersisted(context);
        MarketGroups.load(context);
        seed();
    }

    public List<Stock> current() { return new ArrayList<>(cache.values()); }

    /** Background-safe synchronous catalog/index sync used by the persistent learner. */
    public int syncCatalogBlocking() throws Exception {
        int discovered=fetchIsYatirimUniverse();
        try { syncIndexMemberships(); } catch(Exception ignored) {}
        return discovered;
    }

    public void shutdown() {
        executor.shutdownNow();
        maintenanceExecutor.shutdownNow();
    }

    private void seed() {
        List<String> symbols = StockUniverse.allSymbols();
        for (String sym : symbols) {
            Stock s=new Stock(); s.symbol=sym;
            String dynamicName=StockUniverse.nameOf(sym), dynamicSector=StockUniverse.sectorOf(sym);
            s.name=dynamicName.isEmpty()?prettyName(sym):dynamicName;
            s.sector=dynamicSector.isEmpty()?guessSector(sym):dynamicSector;
            cache.put(sym,s);
        }
    }

    public void refresh() {
        maybeMaintenanceSync();
        if(!refreshRunning.compareAndSet(false,true)) return;
        executor.execute(() -> {
            try {
                String base = context.getSharedPreferences("settings", 0).getString("base_url", "").trim();
                String token = context.getSharedPreferences("settings", 0).getString("token", "").trim();
                int count;
                if (!base.isEmpty()) {
                    count = applyJson(fetch(base, token));
                    if (count > 0) notifyData(true, "Özel veri sağlayıcı • " + count + " hisse güncellendi");
                    else notifyData(false, "Özel veri sağlayıcı JSON alanları okunamadı");
                } else {
                    count = fetchIsYatirimMarketPage();
                    if (count > 0) notifyData(true, "İŞ YATIRIM • " + count + " hisse güncellendi");
                    else notifyData(false, "İŞ YATIRIM verisi okunamadı");
                }
            } catch (Exception e) {
                notifyData(false, "Veri bağlantısı başarısız: " + safeMessage(e));
            } finally {
                refreshRunning.set(false);
            }
        });
    }

    private void maybeMaintenanceSync() {
        long now=System.currentTimeMillis();
        long next=context.getSharedPreferences("runtime",0).getLong("catalog_next",0L);
        if(now<next) return;
        if(!maintenanceRunning.compareAndSet(false,true)) return;
        maintenanceExecutor.execute(() -> {
            String message="Katalog/endeks kontrolü başarısız";
            try {
                int discovered=fetchIsYatirimUniverse();
                int synced=syncIndexMemberships();
                message="Otomatik kontrol: "+discovered+" hisse • "+synced+" endeks listesi";
                MarketGroups.setStatus(context,message);
                context.getSharedPreferences("runtime",0).edit().putLong("catalog_next",System.currentTimeMillis()+MAINTENANCE_INTERVAL_MS).apply();
            } catch(Exception e) {
                MarketGroups.setStatus(context,"Otomatik kontrol başarısız • "+safeMessage(e));
                context.getSharedPreferences("runtime",0).edit().putLong("catalog_next",System.currentTimeMillis()+2*60*1000L).apply();
            } finally {
                maintenanceRunning.set(false);
            }
        });
    }

    private boolean liveFlag() {
        for(Stock s:cache.values()) if(s.live && s.price>0) return true;
        return false;
    }

    /**
     * İş Yatırım'ın halka açık hisse ekranındaki tabloyu okur.
     * Bu sürüm Yahoo/demo verisine geri düşmez: kaynak okunamazsa uygulama
     * sahte fiyat üretmez.
     */
    private int fetchIsYatirimMarketPage() throws Exception {
        String urlText = withCacheBuster("https://www.isyatirim.com.tr/tr-tr/analiz/hisse/sayfalar/default.aspx");
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept","text/html,application/xhtml+xml");
        c.setRequestProperty("Accept-Language","tr-TR,tr;q=0.9");
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        int code=c.getResponseCode();
        InputStream in= code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){ BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null) sb.append(line); r.close(); }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("İş Yatırım HTTP "+code);

        String html=sb.toString();
        int updated=0;
        java.util.regex.Matcher rows=java.util.regex.Pattern.compile("<tr\\b[^>]*>(.*?)</tr>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(html);
        while(rows.find()) {
            String row=rows.group(1);
            java.util.regex.Matcher cells=java.util.regex.Pattern.compile("<td\\b[^>]*>(.*?)</td>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(row);
            ArrayList<String> v=new ArrayList<>();
            while(cells.find()) v.add(cleanHtml(cells.group(1)));
            if(v.size()<3) continue;
            String sym=normalizeSymbol(v.get(0));
            if(sym==null || isReservedSymbol(sym)) continue;
            if(!StockUniverse.contains(sym)) StockUniverse.merge(sym, "", "");
            Stock st=cache.get(sym);
            if(st==null){ st=new Stock(); st.symbol=sym; st.name=StockUniverse.nameOf(sym); st.sector=StockUniverse.sectorOf(sym); cache.put(sym,st); }
            Double price=parseTrNumber(v.get(1));
            Double pct=parseTrNumber(v.get(2));
            if(price==null || price<=0) continue;
            if(st.name==null || st.name.isEmpty()) st.name=StockUniverse.nameOf(sym);
            if(st.sector==null || st.sector.isEmpty()) st.sector=StockUniverse.sectorOf(sym);
            st.price=price;
            st.changePct=pct==null?0:pct;
            st.previousClose=st.changePct>-99 ? st.price/(1.0+st.changePct/100.0) : st.price;
            if(v.size()>3){ Double vol=parseTrNumber(v.get(3)); if(vol!=null) st.volume=vol; }
            if(st.avgVolume<=0) st.avgVolume=Math.max(1,st.volume);
            AnalysisEngine.enrichLiveQuote(st);
            st.risk=AnalysisEngine.liveRisk(st.changePct);
            st.live=true; st.updatedAt=System.currentTimeMillis();
            updated++;
        }
        return updated;
    }

    /** Discover the current BIST equity catalogue and company metadata from İş Yatırım. */
    private int fetchIsYatirimUniverse() throws Exception {
        String urlText = withCacheBuster("https://www.isyatirim.com.tr/en-us/analysis/stocks/Pages/bist-data-table.aspx");
        String html = httpGet(urlText, true);
        LinkedHashMap<String,String[]> found = new LinkedHashMap<>();
        Matcher rows=java.util.regex.Pattern.compile("<tr\\b[^>]*>(.*?)</tr>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(html);
        while(rows.find()) {
            String row=rows.group(1);
            Matcher cells=java.util.regex.Pattern.compile("<td\\b[^>]*>(.*?)</td>", java.util.regex.Pattern.CASE_INSENSITIVE|java.util.regex.Pattern.DOTALL).matcher(row);
            ArrayList<String> v=new ArrayList<>();
            while(cells.find()) v.add(cleanHtml(cells.group(1)));
            if(v.size()<3) continue;
            String sym=normalizeSymbol(v.get(0));
            if(sym==null||isReservedSymbol(sym)) continue;
            String name=v.get(1).trim();
            String sector=v.get(2).trim();
            if(name.isEmpty()||sector.isEmpty()) continue;
            found.put(sym,new String[]{name,sector});
        }
        if(found.size()<300) throw new Exception("İş Yatırım kataloğu eksik: "+found.size());
        StockUniverse.replaceAll(found);
        StockUniverse.savePersisted(context);
        for(Map.Entry<String,String[]> e:found.entrySet()) {
            Stock s=cache.get(e.getKey());
            if(s==null){s=new Stock();s.symbol=e.getKey();cache.put(e.getKey(),s);}
            s.name=e.getValue()[0]; s.sector=e.getValue()[1];
        }
        cache.keySet().removeIf(sym -> !StockUniverse.contains(sym));
        return found.size();
    }

    /** Current BIST 30/50/100/500 membership is refreshed from live constituent pages. */
    private int syncIndexMemberships() throws Exception {
        String[] cats={"BIST 30","BIST 50","BIST 100","BIST 500"};
        String[] urls={
                "https://www.cnbce.com/borsa/endeksler/bist-30",
                "https://www.cnbce.com/borsa/endeksler/bist-50",
                "https://www.cnbce.com/borsa/endeksler/bist-100",
                "https://www.cnbce.com/borsa/endeksler/bist-500"};
        int ok=0;
        for(int i=0;i<cats.length;i++){
            try{
                String html=httpGet(withCacheBuster(urls[i]),false);
                if(MarketGroups.syncFromHtml(context,cats[i],html,null)) ok++;
            }catch(Exception ignored){}
        }
        if(ok==0) throw new Exception("Endeks üyelikleri okunamadı");
        return ok;
    }

    private String httpGet(String urlText, boolean jsonLike) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(jsonLike?10000:8000); c.setReadTimeout(jsonLike?20000:12000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept",jsonLike?"text/html,application/xhtml+xml,application/json":"text/html,application/xhtml+xml");
        c.setRequestProperty("Accept-Language","tr-TR,tr;q=0.9,en;q=0.8");
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        int code=c.getResponseCode();
        InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null)sb.append(line);r.close();}
        c.disconnect();
        if(code<200||code>=300)throw new Exception("HTTP "+code);
        return sb.toString();
    }

    private static String withCacheBuster(String url){
        if(url==null||url.isEmpty()) return url;
        String sep=url.contains("?")?"&":"?";
        return url+sep+"_t="+System.currentTimeMillis();
    }

    private static boolean isReservedSymbol(String sym){
        if(sym==null) return true;
        return sym.equals("STOCK")||sym.equals("CODE")||sym.equals("HISSE")||sym.equals("NAME")||sym.equals("SECTOR");
    }

    private static String cleanHtml(String x){
        String y=x.replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&");
        y=y.replace("&#39;","'").replace("&quot;","\"").trim();
        return y.replaceAll("\\s+"," ");
    }
    private static String normalizeSymbol(String x){
        if(x==null) return null;
        String y=x.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");
        if(y.length()<3 || y.length()>8) return null;
        return y;
    }
    private static Double parseTrNumber(String x){
        if(x==null) return null;
        String y=x.replace("%","").replace("TL","").trim();
        y=y.replace(".","").replace(",",".");
        y=y.replaceAll("[^0-9.\\-]","");
        if(y.isEmpty() || y.equals("-") || y.equals(".")) return null;
        try{return Double.parseDouble(y);}catch(Exception e){return null;}
    }

    private String fetch(String base,String token) throws Exception {
        String sep = base.contains("?") ? "&" : "?";
        String symbols = String.join(",", StockUniverse.allSymbols());
        String urlText = withCacheBuster(base + sep + "symbols=" + java.net.URLEncoder.encode(symbols, "UTF-8"));
        HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(9000); c.setRequestMethod("GET"); c.setRequestProperty("Accept","application/json");
        if(!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
        int code=c.getResponseCode();
        InputStream in= code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb=new StringBuilder();
        if(in!=null){ BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line; while((line=r.readLine())!=null) sb.append(line); r.close(); }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("HTTP "+code+" " + sb);
        return sb.toString();
    }

    private int applyJson(String body) throws Exception {
        Object root = new org.json.JSONTokener(body).nextValue();
        JSONArray arr;
        if(root instanceof JSONObject){
            JSONObject o=(JSONObject)root;
            if(o.has("symbols")) arr=o.getJSONArray("symbols");
            else if(o.has("data")) arr=o.getJSONArray("data");
            else arr=null;
        } else if(root instanceof JSONArray) arr=(JSONArray)root; else arr=null;
        if(arr==null) return 0;
        int count=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.getJSONObject(i);
            String sym = firstString(o,"symbol","ticker","code");
            if(sym==null||sym.isEmpty()) continue;
            sym=sym.toUpperCase(Locale.ROOT);
            Stock s=cache.get(sym);
            if(s==null){ s=new Stock(); s.symbol=sym; s.name=StockUniverse.nameOf(sym); s.sector=StockUniverse.sectorOf(sym); if(s.name.isEmpty())s.name=prettyName(sym); if(s.sector.isEmpty())s.sector="BIST"; cache.put(sym,s); }
            StockUniverse.merge(sym, firstString(o,"name","company"), firstString(o,"sector"));
            s.price=firstDouble(o,"price","last","close",s.price);
            s.previousClose=firstDouble(o,"previousClose","prevClose","previous_close",s.previousClose>0?s.previousClose:s.price);
            s.changePct=firstDouble(o,"changePct","changePercent","percent",safePct(s.price,s.previousClose));
            s.volume=firstDouble(o,"volume","turnover","qty",s.volume);
            s.avgVolume=firstDouble(o,"avgVolume","averageVolume","avg_volume",s.avgVolume);
            s.rsi=firstDouble(o,"rsi",s.rsi); s.macd=firstDouble(o,"macd",s.macd); s.ema20=firstDouble(o,"ema20",s.ema20); s.ema50=firstDouble(o,"ema50",s.ema50);
            s.atrPct=firstDouble(o,"atrPct","atr_percent",s.atrPct); s.score=firstDouble(o,"score","aiScore",s.score);
            s.newsScore=firstDouble(o,"newsScore","news_score",s.newsScore);
            s.signal=firstString(o,"signal","action"); if(s.signal==null) s.signal="BEKLE";
            s.risk=firstString(o,"risk","riskLevel"); if(s.risk==null) s.risk=riskFromScore(s.score,s.atrPct);
            s.support1=firstDouble(o,"support1","support",s.support1); s.support2=firstDouble(o,"support2",s.support2);
            s.resistance1=firstDouble(o,"resistance1","resistance",s.resistance1); s.resistance2=firstDouble(o,"resistance2",s.resistance2);
            String providerName=firstString(o,"name","company");
            String providerSector=firstString(o,"sector");
            if(providerName!=null) s.name=providerName;
            if(providerSector!=null) s.sector=providerSector;
            if(s.name==null||s.name.isEmpty())s.name=StockUniverse.nameOf(sym);
            if(s.sector==null||s.sector.isEmpty())s.sector=StockUniverse.sectorOf(sym);
            if(s.risk==null||s.risk.isEmpty()||s.risk.equals("Orta Risk")) s.risk=AnalysisEngine.liveRisk(s.changePct);
            s.updatedAt=System.currentTimeMillis(); s.live=true; count++;
        }
        if(count>0) StockUniverse.savePersisted(context);
        return count;
    }

    private void notifyData(boolean live,String msg){
        List<Stock> snapshot=current();
        if(live) predictions.observeQuotes(snapshot,System.currentTimeMillis());
        main.post(()->listener.onData(snapshot,live,msg));
    }
    private static String safeMessage(Exception e){ return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(); }
    private static double safePct(double p,double pc){ return pc==0?0:(p/pc-1)*100; }
    private static double firstDouble(JSONObject o,String k1,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,double def){ if(o.has(k1) && !o.isNull(k1)) return o.optDouble(k1,def); if(k2!=null&&o.has(k2)&&!o.isNull(k2)) return o.optDouble(k2,def); return def; }
    private static double firstDouble(JSONObject o,String k1,String k2,String k3,double def){ double v=firstDouble(o,k1,k2,Double.NaN); return Double.isNaN(v)?firstDouble(o,k3,null,def):v; }
    private static String firstString(JSONObject o,String... ks){ for(String k:ks){ if(o.has(k)&&!o.isNull(k)){ String v=o.optString(k,""); if(!v.isEmpty()) return v; } } return null; }
    private static String riskFromScore(double s,double atr){ if(atr<2.5 && s>=45) return "Düşük Risk"; if(atr<5.0) return "Orta Risk"; return "Yüksek Risk"; }

    static String prettyName(String s){
        String dynamic=StockUniverse.nameOf(s);
        if(dynamic!=null && !dynamic.isEmpty()) return dynamic;
        Map<String,String> m=new HashMap<>();
        m.put("THYAO","Türk Hava Yolları"); m.put("ASELS","Aselsan"); m.put("AKBNK","Akbank"); m.put("SAHOL","Sabancı Holding"); m.put("TUPRS","Tüpraş"); m.put("BIMAS","BİM Mağazalar");
        m.put("KCHOL","Koç Holding"); m.put("SISE","Şişecam"); m.put("EREGL","Ereğli Demir Çelik"); m.put("FROTO","Ford Otosan"); m.put("GARAN","Garanti BBVA"); m.put("YKBNK","Yapı Kredi");
        m.put("ISCTR","İş Bankası C"); m.put("TCELL","Turkcell"); m.put("PGSUS","Pegasus"); m.put("TOASO","Tofaş"); m.put("EKGYO","Emlak Konut"); m.put("TAVHL","TAV Havalimanları");
        return m.containsKey(s)?m.get(s):s;
    }
    static String guessSector(String s){
        if(Arrays.asList("AKBNK","GARAN","YKBNK","ISCTR","HALKB","VAKBN","TSKB","SKBNK","ALBRK").contains(s)) return "Bankacılık";
        if(Arrays.asList("THYAO","PGSUS","TAVHL").contains(s)) return "Ulaştırma";
        if(Arrays.asList("ASELS","ALTNY","SDTTR","PAPIL","FORTE").contains(s)) return "Savunma/Teknoloji";
        if(Arrays.asList("TUPRS","PETKM","AKSA","SASA","KMPUR").contains(s)) return "Kimya/Enerji";
        if(Arrays.asList("BIMAS","MGROS","SOKM","MAVI","ULKER").contains(s)) return "Perakende";
        if(s.endsWith("GYO")||s.contains("GYO")) return "GYO";
        return "BIST Hisse";
    }
}
