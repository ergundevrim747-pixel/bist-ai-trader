package com.bistaitrader;

import java.util.Locale;
import java.util.Random;

public final class AnalysisEngine {
    private static final Random R = new Random(20260919L);
    private AnalysisEngine() {}

    public static void enrichDemo(Stock s, int index) {
        if (s.price <= 0) {
            double base = 15 + ((Math.abs(s.symbol.hashCode()) % 900) / 10.0);
            if (s.symbol.equals("THYAO")) base = 312.50;
            if (s.symbol.equals("ASELS")) base = 184.30;
            if (s.symbol.equals("AKBNK")) base = 68.10;
            if (s.symbol.equals("SAHOL")) base = 121.40;
            if (s.symbol.equals("TUPRS")) base = 169.80;
            if (s.symbol.equals("BIMAS")) base = 574.20;
            s.price = base;
            s.previousClose = base * 0.995;
        }
        double wave = Math.sin((index + System.currentTimeMillis()/2500.0) / 8.0) * 0.08;
        double noise = (R.nextDouble() - 0.5) * 0.04;
        s.changePct = clamp(s.changePct + wave + noise, -9.95, 9.95);
        s.previousClose = s.price / (1.0 + s.changePct / 100.0);
        s.rsi = clamp(50 + s.changePct * 3.2 + Math.sin(index*0.7)*10, 18, 86);
        s.macd = (s.changePct * 0.16) + Math.sin(index*0.31)*0.4;
        s.ema20 = s.price * (1 + (s.changePct >= 0 ? -0.012 : 0.012));
        s.ema50 = s.price * (1 + (s.changePct >= 0 ? -0.032 : 0.032));
        s.atrPct = 1.2 + (Math.abs(s.changePct) * 0.8) + (index%7)*0.11;
        s.avgVolume = Math.max(100000, 4000000 - index*2700);
        s.volume = s.avgVolume * (0.65 + (Math.abs(Math.sin(index*0.41))*1.25));
        s.newsScore = Math.sin(index*0.22) * 0.7;
        double trend = ((s.price - s.ema20) / Math.max(0.01,s.price))*100.0;
        s.score = clamp(50 + trend*8 + (s.rsi-50)*0.55 + s.macd*9 + s.newsScore*7 + Math.signum(s.changePct)*4, 5, 95);
        if (s.score >= 72) s.signal = "AL";
        else if (s.score <= 33) s.signal = "SAT";
        else s.signal = "BEKLE";
        double volRisk = Math.min(1.0, s.atrPct / 8.0);
        if (volRisk < 0.32 && Math.abs(s.changePct) < 3.0) s.risk = "Düşük Risk";
        else if (volRisk < 0.62 && Math.abs(s.changePct) < 5.5) s.risk = "Orta Risk";
        else s.risk = "Yüksek Risk";
        double swing = s.price * (s.atrPct / 100.0) * 1.35;
        s.support1 = Math.max(0.01, s.price - swing);
        s.support2 = Math.max(0.01, s.price - swing*2.0);
        s.resistance1 = s.price + swing;
        s.resistance2 = s.price + swing*2.0;
        s.updatedAt = System.currentTimeMillis();
        s.live = false;
    }

    public static String reason(Stock s) {
        String trend = s.price > s.ema20 && s.ema20 > s.ema50 ? "kısa ve orta vadeli trend pozitif" :
                s.price < s.ema20 && s.ema20 < s.ema50 ? "kısa ve orta vadeli trend negatif" : "trend karışık";
        String momentum = s.rsi >= 60 ? "momentum güçlü" : s.rsi <= 40 ? "momentum zayıf" : "momentum nötr";
        String volume = s.volume > s.avgVolume*1.2 ? "hacim ortalamanın belirgin üzerinde" :
                s.volume < s.avgVolume*0.7 ? "hacim zayıf" : "hacim normal";
        return String.format(Locale.TR,"%s; %s; %s. RSI %.1f, MACD %.2f.", trend, momentum, volume, s.rsi, s.macd);
    }

    private static double clamp(double x, double a, double b) { return Math.max(a, Math.min(b, x)); }
}
